"use client";

import { Navbar } from "@/components/Navbar";
import { HeroSection } from "@/components/HeroSection";
import { FeaturesSection } from "@/components/FeaturesSection";
import { ModelComparisonSection } from "@/components/ModelComparisonSection";
import { ApiInstallSection } from "@/components/ApiInstallSection";
import { HuggingFaceIntegration } from "@/components/HuggingFaceIntegration";
import { AgentFlowBuilder } from "@/components/AgentFlowBuilder";
import { DeploymentSection } from "@/components/DeploymentSection";
import { PricingSection } from "@/components/PricingSection";
import { Footer } from "@/components/Footer";
import { useState } from "react";
import { AssistantButton } from "@/components/IntegratedAssistantProvider";

export default function Home() {
  const [lastAddedUrl, setLastAddedUrl] = useState<string | null>(null);

  const handleAddUrl = (url: string) => {
    console.log("Added URL:", url);
    setLastAddedUrl(url);
    // In a real implementation, this would dispatch an action to add the URL
    // to the appropriate section (API Install, Hugging Face, etc.)
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <HeroSection />
        <FeaturesSection />
        <ModelComparisonSection />
        <ApiInstallSection />
        <HuggingFaceIntegration />
        <AgentFlowBuilder />
        <DeploymentSection />
        <PricingSection />
      </main>
      <Footer />
      <AssistantButton />
    </div>
  );
}
