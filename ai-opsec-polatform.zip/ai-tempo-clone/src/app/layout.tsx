import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import ClientBody from "./ClientBody";
import { AssistantProvider } from "@/components/IntegratedAssistantProvider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AI Tempo - Build React Apps with AI Model Choice",
  description: "Build React Apps 10x Faster with AI - Choose your preferred AI model for better results",
  keywords: ["AI", "React", "Web Development", "GPT-4", "Claude", "Gemini", "Llama", "Mistral", "Code Generation"],
  authors: [{ name: "AI Tempo Team" }],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://aitempoexample.com",
    title: "AI Tempo - Build React Apps with AI Model Choice",
    description: "Build React Apps 10x Faster with AI - Choose your preferred AI model for better results",
    siteName: "AI Tempo",
  },
  twitter: {
    card: "summary_large_image",
    title: "AI Tempo - Build React Apps with AI Model Choice",
    description: "Build React Apps 10x Faster with AI - Choose your preferred AI model for better results",
    creator: "@aitempoapp",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#09090b" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${geistSans.variable} ${geistMono.variable}`} suppressHydrationWarning>
      <AssistantProvider>
        <ClientBody>
          {children}
        </ClientBody>
      </AssistantProvider>
    </html>
  );
}
