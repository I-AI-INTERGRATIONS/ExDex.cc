"use client";

import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface CodeNode {
  id: string;
  type: 'function' | 'variable' | 'condition' | 'loop' | 'component' | 'import' | 'api' | 'comment';
  label: string;
  content: string;
  position: { x: number; y: number };
  connections: string[];
  isExpanded: boolean;
  tags: string[];
  metadata: {
    complexity?: number;
    dependencies?: string[];
    importance?: number; // 1-10 scale
    category?: string;
    executionTime?: string;
    aiSuggested?: boolean;
  };
}

interface CodeConnection {
  id: string;
  source: string;
  target: string;
  type: 'calls' | 'imports' | 'depends' | 'modifies' | 'creates' | 'references';
  strength: number; // 1-10 scale of connection strength
}

interface CodeConcept {
  name: string;
  description: string;
  color: string;
}

// Color palette for different node types
const nodeColors = {
  function: "#8B5CF6", // Violet
  variable: "#22C55E", // Green
  condition: "#EAB308", // Yellow
  loop: "#F97316",     // Orange
  component: "#EC4899", // Pink
  import: "#3B82F6",   // Blue
  api: "#F43F5E",      // Red
  comment: "#6B7280"   // Gray
};

// Sample code structures translated to concept map
const sampleCode: CodeNode[] = [
  {
    id: "import-react",
    type: "import",
    label: "React Core",
    content: "import React, { useState, useEffect } from 'react';",
    position: { x: 200, y: 100 },
    connections: ["component-app", "function-fetchData"],
    isExpanded: false,
    tags: ["core", "react", "hooks"],
    metadata: {
      importance: 9,
      category: "framework",
      aiSuggested: false
    }
  },
  {
    id: "import-components",
    type: "import",
    label: "UI Components",
    content: "import { Button, Card, Input } from './components';",
    position: { x: 350, y: 100 },
    connections: ["component-app"],
    isExpanded: false,
    tags: ["ui", "components"],
    metadata: {
      importance: 7,
      category: "ui",
      aiSuggested: false
    }
  },
  {
    id: "component-app",
    type: "component",
    label: "App Component",
    content: "function App() { ... }",
    position: { x: 275, y: 200 },
    connections: ["function-fetchData", "function-handleSubmit", "variable-userData"],
    isExpanded: true,
    tags: ["component", "main"],
    metadata: {
      complexity: 7,
      dependencies: ["React", "useState", "useEffect"],
      importance: 10,
      category: "component",
      aiSuggested: false
    }
  },
  {
    id: "function-fetchData",
    type: "function",
    label: "fetchData()",
    content: "const fetchData = async () => { const response = await fetch('/api/data'); const data = await response.json(); setUserData(data); };",
    position: { x: 150, y: 300 },
    connections: ["variable-userData", "api-endpoint"],
    isExpanded: false,
    tags: ["async", "api", "fetch"],
    metadata: {
      complexity: 5,
      executionTime: "~300ms",
      importance: 8,
      category: "data",
      aiSuggested: false
    }
  },
  {
    id: "function-handleSubmit",
    type: "function",
    label: "handleSubmit()",
    content: "const handleSubmit = (e) => { e.preventDefault(); processUserData(userData); };",
    position: { x: 400, y: 300 },
    connections: ["variable-userData", "function-processUserData"],
    isExpanded: false,
    tags: ["event", "form"],
    metadata: {
      complexity: 3,
      importance: 6,
      category: "interaction",
      aiSuggested: false
    }
  },
  {
    id: "variable-userData",
    type: "variable",
    label: "userData State",
    content: "const [userData, setUserData] = useState(null);",
    position: { x: 275, y: 400 },
    connections: [],
    isExpanded: false,
    tags: ["state", "data"],
    metadata: {
      importance: 8,
      category: "state",
      aiSuggested: false
    }
  },
  {
    id: "function-processUserData",
    type: "function",
    label: "processUserData()",
    content: "function processUserData(data) { /* process logic */ }",
    position: { x: 500, y: 450 },
    connections: [],
    isExpanded: false,
    tags: ["utility", "data"],
    metadata: {
      complexity: 6,
      importance: 7,
      category: "utility",
      aiSuggested: true
    }
  },
  {
    id: "api-endpoint",
    type: "api",
    label: "API Endpoint",
    content: "GET /api/data",
    position: { x: 100, y: 450 },
    connections: [],
    isExpanded: false,
    tags: ["api", "external"],
    metadata: {
      importance: 8,
      category: "external",
      aiSuggested: false
    }
  },
];

const conceptCategories: CodeConcept[] = [
  { name: "Data Flow", description: "How data moves through the application", color: "#8B5CF6" },
  { name: "UI Components", description: "Visual elements and their interactions", color: "#EC4899" },
  { name: "State Management", description: "How application state is maintained", color: "#22C55E" },
  { name: "External Integration", description: "API calls and external dependencies", color: "#F43F5E" },
  { name: "Event Handling", description: "User interaction and event responses", color: "#EAB308" },
];

export function VisualCodeEditor() {
  const [nodes, setNodes] = useState<CodeNode[]>(sampleCode);
  const [selectedNode, setSelectedNode] = useState<CodeNode | null>(null);
  const [visualMode, setVisualMode] = useState<'concept' | 'flow' | 'dependency' | '3d'>('concept');
  const [showMetadata, setShowMetadata] = useState(true);
  const [highlightConnections, setHighlightConnections] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [editingContent, setEditingContent] = useState("");
  const [isPanning, setIsPanning] = useState(false);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [startPan, setStartPan] = useState({ x: 0, y: 0 });
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const canvasRef = useRef<HTMLDivElement>(null);

  // Handle node selection
  const handleNodeClick = (node: CodeNode) => {
    setSelectedNode(node);
    setEditingContent(node.content);
  };

  // Handle toggling node expansion
  const toggleNodeExpansion = (nodeId: string) => {
    setNodes(nodes.map(node =>
      node.id === nodeId ? { ...node, isExpanded: !node.isExpanded } : node
    ));
  };

  // Handle content editing
  const handleContentUpdate = () => {
    if (!selectedNode) return;

    setNodes(nodes.map(node =>
      node.id === selectedNode.id ? { ...node, content: editingContent } : node
    ));

    setSelectedNode(prev => prev ? { ...prev, content: editingContent } : null);
  };

  // Handle canvas panning
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 1 || e.button === 0 && e.altKey) { // Middle button or Alt+Left button
      setIsPanning(true);
      setStartPan({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
      setPan({
        x: e.clientX - startPan.x,
        y: e.clientY - startPan.y
      });
    }
  };

  const handleMouseUp = () => {
    setIsPanning(false);
  };

  // Handle zooming
  const handleZoom = (factor: number) => {
    setZoom(prevZoom => {
      const newZoom = prevZoom + factor;
      return Math.max(0.5, Math.min(2, newZoom));
    });
  };

  // Filter nodes based on search term and category
  const filteredNodes = nodes.filter(node => {
    const matchesSearch = searchTerm
      ? node.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
        node.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        node.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      : true;

    const matchesCategory = activeCategory
      ? node.metadata.category === activeCategory
      : true;

    return matchesSearch && matchesCategory;
  });

  // Get connections for visualization
  const getConnections = () => {
    const connections: CodeConnection[] = [];

    nodes.forEach(node => {
      node.connections.forEach(targetId => {
        const target = nodes.find(n => n.id === targetId);
        if (target) {
          // Determine connection type based on node types
          let type: CodeConnection['type'] = 'references';

          if (node.type === 'import' && target.type === 'component') {
            type = 'imports';
          } else if (node.type === 'function' && target.type === 'function') {
            type = 'calls';
          } else if (node.type === 'function' && target.type === 'variable') {
            type = 'modifies';
          } else if (node.type === 'component' && target.type === 'component') {
            type = 'creates';
          } else if (node.type === 'function' && target.type === 'api') {
            type = 'depends';
          }

          connections.push({
            id: `${node.id}-${targetId}`,
            source: node.id,
            target: targetId,
            type,
            strength: Math.floor(Math.random() * 10) + 1 // In a real app, this would be calculated
          });
        }
      });
    });

    return connections;
  };

  // Render connections between nodes
  const renderConnections = () => {
    const connections = getConnections();
    const highlighted = selectedNode ? new Set([selectedNode.id, ...selectedNode.connections]) : new Set();

    return connections.map(connection => {
      const source = nodes.find(n => n.id === connection.source);
      const target = nodes.find(n => n.id === connection.target);

      if (!source || !target) return null;

      // Calculate source and target positions
      const sourcePos = {
        x: source.position.x * zoom + pan.x,
        y: source.position.y * zoom + pan.y
      };

      const targetPos = {
        x: target.position.x * zoom + pan.x,
        y: target.position.y * zoom + pan.y
      };

      // Determine if this connection should be highlighted
      const isHighlighted = highlightConnections &&
        (highlighted.has(connection.source) &&
         highlighted.has(connection.target));

      // Determine line style based on connection type
      let strokeDasharray = "none";
      let strokeWidth = 2;

      switch (connection.type) {
        case 'calls':
          strokeDasharray = "none";
          break;
        case 'imports':
          strokeDasharray = "5,5";
          break;
        case 'depends':
          strokeDasharray = "10,5";
          break;
        case 'modifies':
          strokeDasharray = "3,3";
          break;
        case 'creates':
          strokeWidth = 3;
          break;
        default:
          strokeDasharray = "1,1";
      }

      return (
        <svg
          key={connection.id}
          className="absolute top-0 left-0 w-full h-full pointer-events-none"
          style={{ zIndex: 0 }}
        >
          <defs>
            <marker
              id={`arrow-${connection.id}`}
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto"
            >
              <path d="M 0 0 L 10 5 L 0 10 z" fill={isHighlighted ? "#F43F5E" : "#9CA3AF"} />
            </marker>
          </defs>
          <line
            x1={sourcePos.x + 50} // Adjust based on node size
            y1={sourcePos.y + 20}
            x2={targetPos.x + 50}
            y2={targetPos.y + 20}
            stroke={isHighlighted ? "#F43F5E" : "#9CA3AF"}
            strokeWidth={strokeWidth}
            strokeDasharray={strokeDasharray}
            markerEnd={`url(#arrow-${connection.id})`}
            className={`transition-colors duration-300 ${isHighlighted ? 'opacity-100' : 'opacity-40'}`}
          />
        </svg>
      );
    });
  };

  // Render nodes based on visual mode
  const renderNodes = () => {
    return filteredNodes.map(node => {
      const isSelected = selectedNode?.id === node.id;
      const isHighlighted = highlightConnections && selectedNode &&
        (selectedNode.id === node.id || selectedNode.connections.includes(node.id));

      const nodeStyle = {
        left: `${node.position.x * zoom + pan.x}px`,
        top: `${node.position.y * zoom + pan.y}px`,
        backgroundColor: nodeColors[node.type],
        transform: `scale(${node.isExpanded ? 1.1 : 1})`,
        zIndex: isSelected ? 10 : 1,
        boxShadow: isHighlighted
          ? `0 0 0 2px white, 0 0 0 4px ${nodeColors[node.type]}`
          : 'none'
      };

      return (
        <div
          key={node.id}
          className={`absolute rounded-lg transition-all duration-200 w-[150px] cursor-pointer
                     ${isSelected ? 'ring-2 ring-white ring-offset-2' : ''}
                     ${node.isExpanded ? 'min-h-[120px]' : 'h-[40px]'}`}
          style={nodeStyle}
          onClick={() => handleNodeClick(node)}
          onDoubleClick={() => toggleNodeExpansion(node.id)}
        >
          <div className="flex items-center justify-between p-2 text-white">
            <div className="text-sm font-medium truncate">{node.label}</div>
            <div className={`w-2 h-2 rounded-full ${node.metadata.aiSuggested ? 'bg-yellow-300' : 'bg-transparent'}`}
                 title={node.metadata.aiSuggested ? "AI Suggested" : ""}></div>
          </div>

          {node.isExpanded && (
            <div className="p-2 mt-1 rounded bg-black/20 text-white text-xs overflow-hidden">
              <div className="line-clamp-3 font-mono">{node.content}</div>

              {showMetadata && (
                <div className="mt-2 pt-2 border-t border-white/20 flex flex-wrap gap-1">
                  {node.tags.map(tag => (
                    <span key={tag} className="px-1 bg-white/20 rounded text-[10px]">
                      {tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      );
    });
  };

  return (
    <section id="visual-code" className="py-20 md:py-28 lg:py-36 border-t border-border/40">
      <div className="container px-4 md:px-6">
        <div className="mb-8 space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Cognitive Code Canvas</h2>
          <p className="mx-auto max-w-[700px] text-lg text-muted-foreground">
            Reimagining how we visualize and understand code - beyond traditional text representations
          </p>
        </div>

        <div className="flex flex-col space-y-6">
          <Card className="bg-card/50 backdrop-blur-sm border-border/50">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Visual Code Flow</CardTitle>
                  <CardDescription>Explore code as interconnected concepts rather than linear text</CardDescription>
                </div>
                <div className="flex space-x-2">
                  <div className="flex items-center border rounded-md overflow-hidden">
                    <button
                      className={`px-3 py-1 text-sm ${visualMode === 'concept' ? 'bg-primary text-white' : 'bg-transparent'}`}
                      onClick={() => setVisualMode('concept')}
                    >
                      Concept
                    </button>
                    <button
                      className={`px-3 py-1 text-sm ${visualMode === 'flow' ? 'bg-primary text-white' : 'bg-transparent'}`}
                      onClick={() => setVisualMode('flow')}
                    >
                      Flow
                    </button>
                    <button
                      className={`px-3 py-1 text-sm ${visualMode === 'dependency' ? 'bg-primary text-white' : 'bg-transparent'}`}
                      onClick={() => setVisualMode('dependency')}
                    >
                      Dependency
                    </button>
                    <button
                      className={`px-3 py-1 text-sm ${visualMode === '3d' ? 'bg-primary text-white' : 'bg-transparent'}`}
                      onClick={() => setVisualMode('3d')}
                    >
                      3D
                    </button>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <Input
                    placeholder="Search code concepts..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-60"
                  />
                  <button
                    className={`px-2 py-1 text-xs rounded ${highlightConnections ? 'bg-primary text-white' : 'bg-muted'}`}
                    onClick={() => setHighlightConnections(!highlightConnections)}
                  >
                    Highlight Connections
                  </button>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" onClick={() => handleZoom(-0.1)}>-</Button>
                  <span className="text-sm">{Math.round(zoom * 100)}%</span>
                  <Button variant="outline" size="sm" onClick={() => handleZoom(0.1)}>+</Button>
                </div>
              </div>

              <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
                {conceptCategories.map(category => (
                  <button
                    key={category.name}
                    className={`px-3 py-1 text-xs rounded-full whitespace-nowrap ${
                      activeCategory === category.name.toLowerCase()
                        ? 'bg-primary text-white'
                        : 'bg-muted hover:bg-muted/80'
                    }`}
                    style={{
                      borderColor: category.color,
                      borderWidth: '1px'
                    }}
                    onClick={() => setActiveCategory(
                      activeCategory === category.name.toLowerCase() ? null : category.name.toLowerCase()
                    )}
                  >
                    {category.name}
                  </button>
                ))}
              </div>

              <div
                ref={canvasRef}
                className="relative w-full h-[500px] bg-slate-900 rounded-lg overflow-hidden cursor-grab"
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
              >
                {renderConnections()}
                {renderNodes()}

                {visualMode === '3d' && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-lg text-muted-foreground">
                      3D visualization coming soon!
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {selectedNode && (
            <Card>
              <CardHeader>
                <CardTitle>Code Detail: {selectedNode.label}</CardTitle>
                <CardDescription>
                  Edit and understand this code in context
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2">
                  <div>
                    <h3 className="text-sm font-medium mb-2">Edit Code</h3>
                    <div className="relative">
                      <textarea
                        className="w-full h-40 p-3 bg-slate-900 text-white font-mono text-sm rounded-md border-border"
                        value={editingContent}
                        onChange={(e) => setEditingContent(e.target.value)}
                      />
                      <Button
                        className="absolute bottom-2 right-2"
                        size="sm"
                        onClick={handleContentUpdate}
                      >
                        Update
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium mb-2">Metadata</h3>
                      <ul className="space-y-2 text-sm">
                        <li className="flex justify-between">
                          <span className="text-muted-foreground">Type:</span>
                          <span className="px-2 rounded" style={{ backgroundColor: nodeColors[selectedNode.type] }}>
                            {selectedNode.type}
                          </span>
                        </li>
                        <li className="flex justify-between">
                          <span className="text-muted-foreground">Tags:</span>
                          <span>{selectedNode.tags.join(", ")}</span>
                        </li>
                        {selectedNode.metadata.complexity && (
                          <li className="flex justify-between">
                            <span className="text-muted-foreground">Complexity:</span>
                            <div className="w-32 bg-muted rounded-full h-2">
                              <div className="bg-yellow-500 h-2 rounded-full" style={{
                                width: `${(selectedNode.metadata.complexity / 10) * 100}%`
                              }}></div>
                            </div>
                          </li>
                        )}
                        {selectedNode.metadata.importance && (
                          <li className="flex justify-between">
                            <span className="text-muted-foreground">Importance:</span>
                            <div className="w-32 bg-muted rounded-full h-2">
                              <div className="bg-primary h-2 rounded-full" style={{
                                width: `${(selectedNode.metadata.importance / 10) * 100}%`
                              }}></div>
                            </div>
                          </li>
                        )}
                        {selectedNode.metadata.category && (
                          <li className="flex justify-between">
                            <span className="text-muted-foreground">Category:</span>
                            <span>{selectedNode.metadata.category}</span>
                          </li>
                        )}
                      </ul>
                    </div>

                    <div>
                      <h3 className="text-sm font-medium mb-2">Connected Nodes</h3>
                      <div className="space-y-1 max-h-40 overflow-y-auto">
                        {selectedNode.connections.map(connectionId => {
                          const node = nodes.find(n => n.id === connectionId);
                          if (!node) return null;

                          return (
                            <div
                              key={node.id}
                              className="flex items-center p-2 rounded hover:bg-muted cursor-pointer"
                              onClick={() => handleNodeClick(node)}
                            >
                              <div className="w-3 h-3 mr-2 rounded-full" style={{ backgroundColor: nodeColors[node.type] }}></div>
                              <span>{node.label}</span>
                            </div>
                          );
                        })}

                        {selectedNode.connections.length === 0 && (
                          <p className="text-sm text-muted-foreground">No connections</p>
                        )}
                      </div>
                    </div>

                    {selectedNode.type === 'function' && (
                      <div>
                        <h3 className="text-sm font-medium mb-2">AI Analysis</h3>
                        <div className="p-3 bg-slate-900/50 rounded-md">
                          <p className="text-sm">
                            This function has a {selectedNode.metadata.complexity && selectedNode.metadata.complexity > 5 ? "high" : "moderate"} complexity
                            score. It's used to {selectedNode.label.toLowerCase().includes('fetch') ? "retrieve data from an external source" : "process user input"}.
                          </p>
                          <div className="mt-2 flex justify-between">
                            <span className="text-xs text-muted-foreground">Performance impact: Medium</span>
                            <Button variant="outline" size="sm">Optimize</Button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Cognitive Code Features</CardTitle>
              <CardDescription>
                A revolutionary way to understand and manipulate code
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-3">
                <div className="space-y-2">
                  <h3 className="font-medium">Spatial Memory</h3>
                  <p className="text-sm text-muted-foreground">
                    Code is arranged in a spatial layout that leverages human spatial memory, making relationships easier to recall than in linear files.
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="font-medium">Concept-Based Navigation</h3>
                  <p className="text-sm text-muted-foreground">
                    Navigate code by concepts and relationships rather than files and folders. Think in terms of "what" not "where".
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="font-medium">Semantic Analysis</h3>
                  <p className="text-sm text-muted-foreground">
                    AI analyzes code to show complexity, importance, and relationships that wouldn't be visible in traditional IDEs.
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="font-medium">Visual Exploration</h3>
                  <p className="text-sm text-muted-foreground">
                    Zoom, pan, and visually explore your codebase to understand structures and patterns from different perspectives.
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="font-medium">Knowledge Graph</h3>
                  <p className="text-sm text-muted-foreground">
                    Code is treated as a knowledge graph where functions, variables, and components are nodes with meaningful connections.
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="font-medium">Cognitive Load Reduction</h3>
                  <p className="text-sm text-muted-foreground">
                    Instead of remembering implementation details, work with high-level concepts and drill down only when needed.
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-6 flex justify-between">
              <Button variant="outline">
                Learn More About Cognitive Code
              </Button>
              <Button>
                Start Building
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </section>
  );
}
