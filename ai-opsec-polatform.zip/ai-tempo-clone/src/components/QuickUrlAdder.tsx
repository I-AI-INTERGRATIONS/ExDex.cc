"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PlusIcon, XIcon } from "lucide-react";

interface QuickUrlAdderProps {
  onAddUrl?: (url: string) => void;
}

export function QuickUrlAdder({ onAddUrl }: QuickUrlAdderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [url, setUrl] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  const [recentUrls, setRecentUrls] = useState<string[]>([
    "huggingface.co/facebook/mms-1b-all",
    "huggingface.co/openai/whisper-large-v3",
    "github.com/api/v3/users"
  ]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;

    setIsAdding(true);

    // Simulate adding the URL
    setTimeout(() => {
      if (onAddUrl) {
        onAddUrl(url);
      }

      // Add to recent URLs if not already there
      if (!recentUrls.includes(url)) {
        setRecentUrls([url, ...recentUrls.slice(0, 4)]);
      }

      setUrl("");
      setIsAdding(false);
      setIsOpen(false);
    }, 800);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end space-y-2">
      {isOpen && (
        <div className="mb-2 w-80 rounded-lg border bg-card p-4 shadow-lg">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-sm font-medium">Quick Add URL</h3>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 w-7 p-0"
              onClick={() => setIsOpen(false)}
            >
              <XIcon className="h-4 w-4" />
            </Button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="flex space-x-2">
              <Input
                placeholder="Enter API or model URL"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="h-9"
              />
              <Button
                type="submit"
                className="h-9"
                disabled={!url.trim() || isAdding}
              >
                {isAdding ? "Adding..." : "Add"}
              </Button>
            </div>

            {recentUrls.length > 0 && (
              <div>
                <div className="mb-1 text-xs text-muted-foreground">Recent URLs</div>
                <div className="space-y-1.5">
                  {recentUrls.map((recentUrl, index) => (
                    <div
                      key={index}
                      className="flex cursor-pointer items-center rounded-md px-2 py-1 text-xs hover:bg-muted"
                      onClick={() => {
                        setUrl(recentUrl);
                      }}
                    >
                      <div className="mr-2 flex h-5 w-5 items-center justify-center rounded-full bg-primary/10">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="12"
                          height="12"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-primary"
                        >
                          <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                          <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
                        </svg>
                      </div>
                      <span className="truncate">{recentUrl}</span>
                    </div>
                  ))}
                </div>

                <Button
                  variant="ghost"
                  size="sm"
                  className="mt-2 h-7 w-full text-xs"
                  onClick={() => setRecentUrls([])}
                >
                  Clear History
                </Button>
              </div>
            )}
          </form>
        </div>
      )}

      <Button
        variant={isOpen ? "default" : "secondary"}
        size="icon"
        className="h-12 w-12 rounded-full shadow-lg"
        onClick={() => setIsOpen(!isOpen)}
      >
        <PlusIcon className="h-6 w-6" />
      </Button>
    </div>
  );
}
