"use client";

import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

// Node types for the flow diagram
type NodeType =
  | "input"
  | "output"
  | "process"
  | "decision"
  | "apiCall"
  | "model"
  | "repository";

interface Position {
  x: number;
  y: number;
}

interface FlowNode {
  id: string;
  type: NodeType;
  label: string;
  position: Position;
  data?: any;
  connectedTo?: string[];
}

interface Connection {
  id: string;
  sourceId: string;
  targetId: string;
  label?: string;
}

// Sample repositories
const repositories = [
  { id: "repo1", name: "Living Fabric Core", description: "Main repository with core logic and components" },
  { id: "repo2", name: "Agent Framework", description: "Framework for creating intelligent agents" },
  { id: "repo3", name: "NLP Components", description: "Natural language processing components and models" },
  { id: "repo4", name: "Decision Engine", description: "Logic for making autonomous decisions" },
];

// Sample models
const models = [
  { id: "model1", name: "Conversation Router", description: "Routes conversations to appropriate handlers" },
  { id: "model2", name: "Intent Classifier", description: "Identifies user intents from messages" },
  { id: "model3", name: "Response Generator", description: "Generates appropriate responses based on context" },
  { id: "model4", name: "Knowledge Retriever", description: "Retrieves relevant information from knowledge base" },
];

// Node templates
const nodeTemplates: Record<NodeType, { label: string, color: string }> = {
  input: { label: "User Input", color: "bg-blue-500" },
  output: { label: "Response", color: "bg-green-500" },
  process: { label: "Process", color: "bg-purple-500" },
  decision: { label: "Decision", color: "bg-yellow-500" },
  apiCall: { label: "API Call", color: "bg-red-500" },
  model: { label: "AI Model", color: "bg-indigo-500" },
  repository: { label: "Repository", color: "bg-pink-500" }
};

export function AgentFlowBuilder() {
  // States
  const [nodes, setNodes] = useState<FlowNode[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [selectedNode, setSelectedNode] = useState<FlowNode | null>(null);
  const [draggingNode, setDraggingNode] = useState<FlowNode | null>(null);
  const [startPosition, setStartPosition] = useState<Position | null>(null);
  const [dragOffset, setDragOffset] = useState<Position>({ x: 0, y: 0 });
  const [connectingNode, setConnectingNode] = useState<FlowNode | null>(null);
  const [conversationOpen, setConversationOpen] = useState(false);
  const [repositoryDialogOpen, setRepositoryDialogOpen] = useState(false);
  const [selectedRepository, setSelectedRepository] = useState<any>(null);
  const [isCreatingConnection, setIsCreatingConnection] = useState(false);
  const [messages, setMessages] = useState<any[]>([
    { role: "system", content: "I'm the Living Fabric agent. How can I assist you with your workflow?" },
    { role: "user", content: "I need to process user messages and connect to my repository" }
  ]);
  const [newMessage, setNewMessage] = useState("");
  const [agentStatus, setAgentStatus] = useState<"idle" | "thinking" | "error">("idle");

  const canvasRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll chat to bottom
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  // Generate a unique ID
  const generateId = () => `node-${Math.random().toString(36).substring(2, 9)}`;

  // Add a new node to the canvas
  const addNode = (type: NodeType, position: Position) => {
    const id = generateId();
    const newNode: FlowNode = {
      id,
      type,
      label: nodeTemplates[type].label,
      position,
      connectedTo: []
    };
    setNodes([...nodes, newNode]);
    return newNode;
  };

  // Handle starting dragging a node
  const handleNodeDragStart = (node: FlowNode, e: React.MouseEvent) => {
    e.stopPropagation();
    setDraggingNode(node);
    setStartPosition({ x: e.clientX, y: e.clientY });
    setDragOffset({ x: 0, y: 0 });
  };

  // Handle dragging a node
  const handleCanvasMouseMove = (e: React.MouseEvent) => {
    if (draggingNode && startPosition) {
      const offsetX = e.clientX - startPosition.x;
      const offsetY = e.clientY - startPosition.y;
      setDragOffset({ x: offsetX, y: offsetY });
    } else if (isCreatingConnection && connectingNode) {
      // Handle drawing connection line
    }
  };

  // Handle dropping a node or ending a connection
  const handleCanvasMouseUp = (e: React.MouseEvent) => {
    if (draggingNode) {
      // Update the node's position
      setNodes(nodes.map(node =>
        node.id === draggingNode.id
          ? {
              ...node,
              position: {
                x: node.position.x + dragOffset.x,
                y: node.position.y + dragOffset.y
              }
            }
          : node
      ));
      setDraggingNode(null);
      setStartPosition(null);
    } else if (isCreatingConnection) {
      // Check if we're over a node to create a connection
      // (simplified - in a real app you'd check node bounds)
      setIsCreatingConnection(false);
      setConnectingNode(null);
    }
  };

  // Handle clicking on the canvas to add a new node
  const handleCanvasClick = (e: React.MouseEvent) => {
    if (!canvasRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const position = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };

    // Check if we should add a new node
    if (!draggingNode && !isCreatingConnection) {
      // In a real implementation, you'd show a menu to select node type
      //addNode("process", position);
    }
  };

  // Start creating a connection from a node
  const startConnection = (node: FlowNode, e: React.MouseEvent) => {
    e.stopPropagation();
    setConnectingNode(node);
    setIsCreatingConnection(true);
  };

  // Add a connection between nodes
  const addConnection = (sourceId: string, targetId: string) => {
    if (sourceId === targetId) return;

    const id = `conn-${sourceId}-${targetId}`;

    // Check if connection already exists
    if (connections.some(conn => conn.sourceId === sourceId && conn.targetId === targetId)) {
      return;
    }

    setConnections([...connections, { id, sourceId, targetId }]);

    // Update the node's connectedTo list
    setNodes(nodes.map(node =>
      node.id === sourceId
        ? { ...node, connectedTo: [...(node.connectedTo || []), targetId] }
        : node
    ));
  };

  // Handle a node template drag start
  const handleTemplateDragStart = (e: React.DragEvent, type: NodeType) => {
    e.dataTransfer.setData("nodeType", type);
  };

  // Handle dropping a node template on the canvas
  const handleCanvasDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (!canvasRef.current) return;

    const nodeType = e.dataTransfer.getData("nodeType") as NodeType;
    if (!nodeType) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const position = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };

    addNode(nodeType, position);
  };

  // Delete a node and its connections
  const deleteNode = (nodeId: string) => {
    setNodes(nodes.filter(node => node.id !== nodeId));
    setConnections(connections.filter(conn =>
      conn.sourceId !== nodeId && conn.targetId !== nodeId
    ));
  };

  // Add a new message to the conversation
  const sendMessage = () => {
    if (!newMessage.trim()) return;

    // Add user message
    setMessages([...messages, { role: "user", content: newMessage }]);
    setNewMessage("");

    // Simulate agent thinking
    setAgentStatus("thinking");

    // Simulate agent response after delay
    setTimeout(() => {
      setAgentStatus("idle");
      setMessages(prev => [
        ...prev,
        {
          role: "assistant",
          content: `I can help with that. You can connect to repositories by dragging a repository node onto the canvas, then connecting it to your process flow. Would you like me to suggest a specific repository integration based on your needs?`
        }
      ]);
    }, 1500);
  };

  // Link a repository to a node
  const linkRepositoryToNode = (node: FlowNode, repository: any) => {
    setNodes(nodes.map(n =>
      n.id === node.id
        ? { ...n, data: { ...n.data, repository } }
        : n
    ));
    setRepositoryDialogOpen(false);
  };

  // Render a node on the canvas
  const renderNode = (node: FlowNode) => {
    const isDragging = draggingNode?.id === node.id;
    const position = isDragging
      ? {
          x: node.position.x + dragOffset.x,
          y: node.position.y + dragOffset.y
        }
      : node.position;

    return (
      <div
        key={node.id}
        className={`absolute rounded-lg shadow-md p-2 cursor-move ${nodeTemplates[node.type].color} text-white`}
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
          minWidth: "100px",
          zIndex: isDragging ? 10 : 1
        }}
        onMouseDown={(e) => handleNodeDragStart(node, e)}
      >
        <div className="flex justify-between items-center">
          <span>{node.label}</span>
          <div className="flex space-x-1">
            <button
              className="w-4 h-4 rounded-full bg-white/30 flex items-center justify-center text-xs"
              onClick={(e) => {
                e.stopPropagation();
                startConnection(node, e);
              }}
            >
              →
            </button>
            <button
              className="w-4 h-4 rounded-full bg-white/30 flex items-center justify-center text-xs"
              onClick={(e) => {
                e.stopPropagation();
                deleteNode(node.id);
              }}
            >
              ×
            </button>
          </div>
        </div>
        {node.type === "repository" && node.data?.repository && (
          <div className="text-xs mt-1 bg-black/20 p-1 rounded">
            {node.data.repository.name}
          </div>
        )}
      </div>
    );
  };

  // Render connections between nodes
  const renderConnections = () => {
    return connections.map(connection => {
      const sourceNode = nodes.find(node => node.id === connection.sourceId);
      const targetNode = nodes.find(node => node.id === connection.targetId);

      if (!sourceNode || !targetNode) return null;

      // Calculate source and target positions
      // This is a simplified version - in a real app you'd calculate from node edges
      const sourceX = sourceNode.position.x + 50; // Assuming node width is 100px
      const sourceY = sourceNode.position.y + 15; // Assuming node height is 30px
      const targetX = targetNode.position.x + 50;
      const targetY = targetNode.position.y + 15;

      return (
        <svg
          key={connection.id}
          className="absolute top-0 left-0 w-full h-full pointer-events-none z-0"
        >
          <line
            x1={sourceX}
            y1={sourceY}
            x2={targetX}
            y2={targetY}
            stroke="white"
            strokeWidth="2"
            strokeDasharray="4"
          />
          {/* Arrow head */}
          <circle cx={targetX} cy={targetY} r="3" fill="white" />
        </svg>
      );
    });
  };

  // Render node templates for dragging onto canvas
  const renderNodeTemplates = () => {
    return (
      <div className="flex flex-wrap gap-2 mb-4">
        {Object.entries(nodeTemplates).map(([type, template]) => (
          <div
            key={type}
            className={`p-2 rounded-md cursor-grab ${template.color} text-white text-sm`}
            draggable
            onDragStart={(e) => handleTemplateDragStart(e, type as NodeType)}
          >
            {template.label}
          </div>
        ))}
      </div>
    );
  };

  // Render the conversation interface
  const renderConversation = () => {
    return (
      <Dialog open={conversationOpen} onOpenChange={setConversationOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Living Fabric Agent</DialogTitle>
            <DialogDescription>
              Get help designing your agent workflow
            </DialogDescription>
          </DialogHeader>

          <div className="max-h-[400px] overflow-y-auto p-4 rounded-md bg-slate-900 space-y-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`
                    max-w-[80%] rounded-lg p-3
                    ${message.role === 'user'
                      ? 'bg-primary text-white rounded-tr-none'
                      : 'bg-muted rounded-tl-none'
                    }
                  `}
                >
                  {message.content}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="flex gap-2 mt-2">
            <Input
              placeholder="Ask about your workflow..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
              disabled={agentStatus === "thinking"}
              className="flex-1"
            />
            <Button
              onClick={sendMessage}
              disabled={agentStatus === "thinking" || !newMessage.trim()}
            >
              {agentStatus === "thinking" ? "Thinking..." : "Send"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  // Render repository selection dialog
  const renderRepositoryDialog = () => {
    return (
      <Dialog open={repositoryDialogOpen} onOpenChange={setRepositoryDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Select Repository</DialogTitle>
            <DialogDescription>
              Choose a repository to connect to this node
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            {repositories.map(repo => (
              <div
                key={repo.id}
                className="flex items-center space-x-3 p-3 rounded-lg border cursor-pointer hover:bg-muted"
                onClick={() => {
                  setSelectedRepository(repo);
                  if (selectedNode) {
                    linkRepositoryToNode(selectedNode, repo);
                  }
                }}
              >
                <div className="h-10 w-10 rounded-md bg-pink-500/20 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-pink-500">
                    <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                  </svg>
                </div>
                <div>
                  <h4 className="text-sm font-medium">{repo.name}</h4>
                  <p className="text-xs text-muted-foreground">{repo.description}</p>
                </div>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  return (
    <section id="agent-flow" className="py-20 md:py-28 lg:py-36 border-t border-border/40">
      <div className="container px-4 md:px-6">
        <div className="mb-8 space-y-4">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl text-center">Agent Flow Builder</h2>
          <p className="mx-auto max-w-[700px] text-lg text-muted-foreground text-center">
            Design your agent workflows with drag-and-drop ease
          </p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Living Fabric Integration</CardTitle>
            <CardDescription>
              Connect repositories and create agent flows with the power of Living Fabric
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4 flex justify-between items-center">
              <div className="text-sm text-muted-foreground">
                Drag node templates onto the canvas to create your flow
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={() => setConversationOpen(true)}>
                  Chat with Agent
                </Button>
                <Button variant="outline" size="sm" onClick={() => {
                  setNodes([]);
                  setConnections([]);
                }}>
                  Clear Canvas
                </Button>
              </div>
            </div>

            {/* Node templates */}
            {renderNodeTemplates()}

            {/* Canvas */}
            <div
              ref={canvasRef}
              className="w-full h-[500px] border border-border rounded-lg relative bg-slate-900 overflow-hidden"
              onClick={handleCanvasClick}
              onMouseMove={handleCanvasMouseMove}
              onMouseUp={handleCanvasMouseUp}
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleCanvasDrop}
            >
              {/* Connection lines */}
              {renderConnections()}

              {/* Nodes */}
              {nodes.map(node => renderNode(node))}

              {/* Connection being created */}
              {isCreatingConnection && connectingNode && (
                <div className="absolute inset-0 cursor-crosshair">
                  {/* This would show a line following the cursor */}
                </div>
              )}

              {/* Empty state */}
              {nodes.length === 0 && (
                <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
                  <div className="text-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="48"
                      height="48"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mx-auto mb-4 text-muted-foreground/50"
                    >
                      <path d="M20.42 4.58a5.4 5.4 0 0 0-7.65 0l-.77.78-.77-.78a5.4 5.4 0 0 0-7.65 0C1.46 6.7 1.33 10.28 4 13l8 8 8-8c2.67-2.72 2.54-6.3.42-8.42z"></path>
                      <path d="M12 5.36 8.87 8.5a2.13 2.13 0 0 0 0 3h0a2.13 2.13 0 0 0 3 0l2.26-2.21a3 3 0 0 1 4.22 0h0a3 3 0 0 1 0 4.25l-2.08 2.1"></path>
                    </svg>
                    <p>Drag elements here to build your agent flow</p>
                    <Button
                      variant="ghost"
                      className="mt-4"
                      onClick={() => setConversationOpen(true)}
                    >
                      Get help from the Living Fabric agent
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
          <CardFooter className="border-t p-4 bg-muted/40">
            <div className="text-xs text-muted-foreground">
              Tip: Double-click on repository nodes to configure repository connections
            </div>
          </CardFooter>
        </Card>

        {/* Sample workflows */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Sample Workflows</CardTitle>
              <CardDescription>
                Pre-built agent flows you can import
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center p-3 border rounded-md hover:bg-muted/50 cursor-pointer">
                <div>
                  <h4 className="font-medium">Conversation Router</h4>
                  <p className="text-sm text-muted-foreground">Route user queries to appropriate handlers</p>
                </div>
                <Button variant="outline" size="sm">Import</Button>
              </div>
              <div className="flex justify-between items-center p-3 border rounded-md hover:bg-muted/50 cursor-pointer">
                <div>
                  <h4 className="font-medium">Knowledge Assistant</h4>
                  <p className="text-sm text-muted-foreground">Query repositories and generate responses</p>
                </div>
                <Button variant="outline" size="sm">Import</Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Connected Repositories</CardTitle>
              <CardDescription>
                Living Fabric repositories you can use
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {repositories.slice(0, 2).map(repo => (
                <div key={repo.id} className="flex justify-between items-center p-3 border rounded-md">
                  <div className="flex items-center space-x-3">
                    <div className="h-8 w-8 rounded-md bg-pink-500/20 flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-pink-500">
                        <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                      </svg>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium">{repo.name}</h4>
                      <p className="text-xs text-muted-foreground">{repo.description}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">Add</Button>
                </div>
              ))}
              <Button variant="outline" className="w-full">
                View All Repositories
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Dialogs */}
      {renderConversation()}
      {renderRepositoryDialog()}
    </section>
  );
}
