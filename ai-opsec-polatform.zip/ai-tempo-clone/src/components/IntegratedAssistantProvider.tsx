"use client";

import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";

// Types for our context
interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
}

interface SuggestionAction {
  label: string;
  action: string;
  section?: string;
}

interface AssistantState {
  isOpen: boolean;
  messages: Message[];
  suggestions: SuggestionAction[];
  isTyping: boolean;
  currentSection: string | null;
  lastUserAction: string | null;
}

interface AssistantContextType {
  assistantState: AssistantState;
  openAssistant: () => void;
  closeAssistant: () => void;
  sendMessage: (message: string) => void;
  setCurrentSection: (section: string) => void;
  logUserAction: (action: string, section?: string) => void;
  executeSuggestion: (suggestion: SuggestionAction) => void;
  isMinimized: boolean;
  toggleMinimize: () => void;
}

// Create a context
const AssistantContext = createContext<AssistantContextType | undefined>(undefined);

// Generate unique IDs for messages
const generateId = () => Math.random().toString(36).substring(2, 9);

// Sample repositories for the assistant to reference
const repositories = [
  { id: "repo1", name: "Living Fabric Core", description: "Main repository with core components" },
  { id: "repo2", name: "Trading Bot Framework", description: "Framework for crypto and stock trading bots" },
  { id: "repo3", name: "NLP Pipeline", description: "Natural language processing workflow" },
  { id: "repo4", name: "Decision Engine", description: "Logic for making autonomous decisions" },
];

// Sample models
const aiModels = [
  { id: "model1", name: "GPT-4", provider: "OpenAI", category: "text-generation" },
  { id: "model2", name: "Claude 3", provider: "Anthropic", category: "text-generation" },
  { id: "model3", name: "Llama 3", provider: "Meta", category: "text-generation" },
  { id: "model4", name: "Gemini Pro", provider: "Google", category: "multimodal" },
  { id: "model5", name: "Whisper", provider: "OpenAI", category: "speech-to-text" },
  { id: "model6", name: "DALLE-3", provider: "OpenAI", category: "image-generation" }
];

// Provider component
export const AssistantProvider = ({ children }: { children: ReactNode }) => {
  const [assistantState, setAssistantState] = useState<AssistantState>({
    isOpen: false,
    messages: [
      {
        id: generateId(),
        role: "system",
        content: "I'm your integrated development assistant. I'll help you connect AI models, build workflows, and integrate repositories across the platform.",
        timestamp: new Date()
      }
    ],
    suggestions: [],
    isTyping: false,
    currentSection: null,
    lastUserAction: null
  });

  const [isMinimized, setIsMinimized] = useState(false);

  // Generate context-aware suggestions based on the current section
  useEffect(() => {
    if (assistantState.currentSection) {
      generateSuggestions(assistantState.currentSection);
    }
  }, [assistantState.currentSection, assistantState.lastUserAction]);

  // Open the assistant
  const openAssistant = () => {
    setAssistantState(prev => ({ ...prev, isOpen: true }));
  };

  // Close the assistant
  const closeAssistant = () => {
    setAssistantState(prev => ({ ...prev, isOpen: false }));
  };

  // Toggle minimize state
  const toggleMinimize = () => {
    setIsMinimized(prev => !prev);
  };

  // Send a message to the assistant
  const sendMessage = (message: string) => {
    if (!message.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: generateId(),
      role: "user",
      content: message,
      timestamp: new Date()
    };

    setAssistantState(prev => ({
      ...prev,
      messages: [...prev.messages, userMessage],
      isTyping: true
    }));

    // Simulate AI thinking
    setTimeout(() => {
      const response = generateResponse(message, assistantState.currentSection);
      const aiMessage: Message = {
        id: generateId(),
        role: "assistant",
        content: response.message,
        timestamp: new Date()
      };

      setAssistantState(prev => ({
        ...prev,
        messages: [...prev.messages, aiMessage],
        suggestions: response.suggestions,
        isTyping: false
      }));
    }, 1000);
  };

  // Set the current section the user is viewing
  const setCurrentSection = (section: string) => {
    setAssistantState(prev => ({ ...prev, currentSection: section }));
  };

  // Log user actions for better suggestions
  const logUserAction = (action: string, section?: string) => {
    setAssistantState(prev => ({
      ...prev,
      lastUserAction: action,
      currentSection: section || prev.currentSection
    }));
  };

  // Execute a suggestion action
  const executeSuggestion = (suggestion: SuggestionAction) => {
    // Add a message showing what the user clicked
    const userMessage: Message = {
      id: generateId(),
      role: "user",
      content: `I want to ${suggestion.label}`,
      timestamp: new Date()
    };

    setAssistantState(prev => ({
      ...prev,
      messages: [...prev.messages, userMessage],
      isTyping: true,
      currentSection: suggestion.section || prev.currentSection
    }));

    // Simulate executing the action and AI response
    setTimeout(() => {
      const response = handleSuggestionExecution(suggestion);
      const aiMessage: Message = {
        id: generateId(),
        role: "assistant",
        content: response.message,
        timestamp: new Date()
      };

      setAssistantState(prev => ({
        ...prev,
        messages: [...prev.messages, aiMessage],
        suggestions: response.suggestions,
        isTyping: false
      }));
    }, 800);
  };

  // Generate context-aware suggestions based on the section
  const generateSuggestions = (section: string) => {
    let suggestions: SuggestionAction[] = [];

    switch (section) {
      case "models":
        suggestions = [
          { label: "Find the best model for sentiment analysis", action: "recommend_model", section: "models" },
          { label: "Import a Hugging Face model", action: "import_model", section: "models" },
          { label: "Compare GPT-4 with Claude 3", action: "compare_models", section: "models" }
        ];
        break;
      case "api-install":
        suggestions = [
          { label: "Set up API for OpenAI", action: "setup_api", section: "api-install" },
          { label: "Configure local weights", action: "configure_weights", section: "api-install" },
          { label: "Toggle censorship settings", action: "toggle_censorship", section: "api-install" }
        ];
        break;
      case "huggingface":
        suggestions = [
          { label: "Find speech-to-speech models", action: "find_speech_models", section: "huggingface" },
          { label: "Set up a translation pipeline", action: "setup_pipeline", section: "huggingface" },
          { label: "Connect to my repository", action: "connect_repo", section: "huggingface" }
        ];
        break;
      case "agent-flow":
        suggestions = [
          { label: "Create a trading bot workflow", action: "create_trading_bot", section: "agent-flow" },
          { label: "Import Living Fabric repository", action: "import_repository", section: "agent-flow" },
          { label: "Design a sentiment analysis pipeline", action: "design_pipeline", section: "agent-flow" }
        ];
        break;
      case "deployment":
        suggestions = [
          { label: "Deploy my model to a SaaS environment", action: "deploy_saas", section: "deployment" },
          { label: "Set up self-hosted deployment", action: "setup_selfhosted", section: "deployment" },
          { label: "Configure multi-user access", action: "config_users", section: "deployment" }
        ];
        break;
      default:
        suggestions = [
          { label: "Explore AI models", action: "explore_models", section: "models" },
          { label: "Set up API integration", action: "setup_api", section: "api-install" },
          { label: "Build a workflow", action: "build_workflow", section: "agent-flow" }
        ];
    }

    setAssistantState(prev => ({ ...prev, suggestions }));
  };

  // Generate tailored responses based on user messages and context
  const generateResponse = (message: string, section: string | null) => {
    let response = {
      message: "",
      suggestions: [] as SuggestionAction[]
    };

    const messageLower = message.toLowerCase();

    // Handle different intents based on message and section
    if (messageLower.includes("trading bot") || messageLower.includes("trading algorithm")) {
      response.message = "I can help you build a trading bot workflow. Would you like to start with a cryptocurrency bot, stock trading bot, or a custom solution? I can help you connect to market data APIs and set up the decision logic.";
      response.suggestions = [
        { label: "Set up crypto trading bot", action: "setup_crypto_bot", section: "agent-flow" },
        { label: "Build stock market algorithm", action: "setup_stock_bot", section: "agent-flow" },
        { label: "Connect to market data API", action: "connect_market_api", section: "api-install" }
      ];
    }
    else if (messageLower.includes("connect") && messageLower.includes("repository")) {
      response.message = "I can help you connect to repositories like Living Fabric Core or integrate with external repositories. You can either drag a repository node onto the agent flow canvas or directly access repositories in the API integration section.";
      response.suggestions = [
        { label: "Connect to Living Fabric", action: "connect_living_fabric", section: "agent-flow" },
        { label: "Import external GitHub repo", action: "import_github", section: "api-install" },
        { label: "See available repositories", action: "list_repositories", section: "agent-flow" }
      ];
    }
    else if (messageLower.includes("speech") || messageLower.includes("audio")) {
      response.message = "For speech-related models and pipelines, I recommend exploring the Hugging Face integration section. You can find models like Whisper for speech recognition or create speech-to-speech pipelines.";
      response.suggestions = [
        { label: "Find speech recognition models", action: "find_speech_models", section: "huggingface" },
        { label: "Create speech pipeline", action: "create_speech_pipeline", section: "huggingface" },
        { label: "Connect speech model to workflow", action: "connect_speech_workflow", section: "agent-flow" }
      ];
    }
    else if (messageLower.includes("deploy") || messageLower.includes("hosting")) {
      response.message = "You have several options for deploying your AI solutions. Would you prefer self-hosting for complete control, managed SaaS for convenience, or a hybrid approach? Each has different considerations for cost, control, and scalability.";
      response.suggestions = [
        { label: "Set up self-hosted deployment", action: "setup_selfhosted", section: "deployment" },
        { label: "Configure SaaS deployment", action: "configure_saas", section: "deployment" },
        { label: "Compare deployment options", action: "compare_deployment", section: "deployment" }
      ];
    }
    else if (section === "models") {
      response.message = "I see you're looking at AI models. What kind of task are you trying to accomplish? I can recommend models for text generation, image creation, speech processing, or help you compare different options based on your requirements.";
      response.suggestions = [
        { label: "Find model by task type", action: "find_model_task", section: "models" },
        { label: "Compare model performance", action: "compare_models", section: "models" },
        { label: "Import custom model", action: "import_custom_model", section: "models" }
      ];
    }
    else if (section === "api-install") {
      response.message = "In the API installation section, you can connect to various AI providers. Which service are you trying to integrate? I can help with OpenAI, Anthropic, Hugging Face, or custom API setups.";
      response.suggestions = [
        { label: "Set up OpenAI integration", action: "setup_openai", section: "api-install" },
        { label: "Configure local weights", action: "setup_local_weights", section: "api-install" },
        { label: "Import custom API", action: "import_custom_api", section: "api-install" }
      ];
    }
    else if (section === "agent-flow") {
      response.message = "The Agent Flow Builder lets you create visual workflows connecting different components. What type of workflow are you trying to build? I can help with trading bots, content pipelines, or custom agent designs.";
      response.suggestions = [
        { label: "Create trading workflow", action: "create_trading_workflow", section: "agent-flow" },
        { label: "Build content generation pipeline", action: "build_content_pipeline", section: "agent-flow" },
        { label: "Connect to repository", action: "connect_repository", section: "agent-flow" }
      ];
    }
    else {
      response.message = "I'm here to help you build and connect AI models, workflows, and integrations. What specific task are you working on? I can guide you through setting up APIs, building agent workflows, or deploying your solutions.";
      response.suggestions = [
        { label: "Explore AI models", action: "explore_models", section: "models" },
        { label: "Start a new workflow", action: "new_workflow", section: "agent-flow" },
        { label: "Set up API connection", action: "setup_api", section: "api-install" }
      ];
    }

    return response;
  };

  // Handle the execution of a suggested action
  const handleSuggestionExecution = (suggestion: SuggestionAction) => {
    let response = {
      message: "",
      suggestions: [] as SuggestionAction[]
    };

    switch (suggestion.action) {
      case "create_trading_bot":
        response.message = "I've created a new trading bot workflow template for you. You can now see it in the canvas. This template includes market data input nodes, analysis nodes, decision nodes, and trade execution output nodes. You can customize it by adding specific technical indicators or fundamental analysis components.";
        response.suggestions = [
          { label: "Add technical analysis", action: "add_technical_analysis", section: "agent-flow" },
          { label: "Connect to market data", action: "connect_market_data", section: "api-install" },
          { label: "Set up backtesting", action: "setup_backtesting", section: "agent-flow" }
        ];
        break;
      case "import_repository":
        response.message = "I've imported the Living Fabric repository components. You now have access to all the core components and can drag them onto the canvas. Would you like to explore specific components or see a demonstration of how they can be connected?";
        response.suggestions = [
          { label: "Explore repository components", action: "explore_components", section: "agent-flow" },
          { label: "See connection demonstration", action: "demo_connections", section: "agent-flow" },
          { label: "Build a custom workflow", action: "custom_workflow", section: "agent-flow" }
        ];
        break;
      case "find_speech_models":
        response.message = "I've found several speech models for you. The most popular ones include Whisper for speech-to-text, SpeechT5 for text-to-speech, and Seamless-M4T for speech-to-speech translation. You can browse them in the Hugging Face section or directly integrate them into your workflow.";
        response.suggestions = [
          { label: "Integrate Whisper model", action: "integrate_whisper", section: "huggingface" },
          { label: "Create speech translation flow", action: "create_translation_flow", section: "agent-flow" },
          { label: "Compare speech model accuracy", action: "compare_speech_models", section: "models" }
        ];
        break;
      case "setup_selfhosted":
        response.message = "I've prepared the self-hosted deployment configuration for you. This setup will allow you to deploy your AI solutions on your own infrastructure with full control. You'll need to specify the server requirements, networking configuration, and security settings before deployment.";
        response.suggestions = [
          { label: "Configure server requirements", action: "config_server", section: "deployment" },
          { label: "Set up security settings", action: "setup_security", section: "deployment" },
          { label: "Prepare deployment script", action: "prepare_deployment", section: "deployment" }
        ];
        break;
      default:
        response.message = "I'll help you with that. Let me guide you through the process step by step. First, let's identify exactly what you're trying to accomplish, then I'll provide specific guidance for your needs.";
        response.suggestions = [
          { label: "Explore more options", action: "explore_options", section: suggestion.section },
          { label: "Get step-by-step guide", action: "get_guide", section: suggestion.section },
          { label: "See example solutions", action: "see_examples", section: suggestion.section }
        ];
    }

    return response;
  };

  // Format the timestamp for display
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // The Assistant Component
  const AssistantComponent = () => {
    const [newMessage, setNewMessage] = useState("");
    const messagesEndRef = useRef<HTMLDivElement>(null);

    // Scroll to bottom of messages
    useEffect(() => {
      if (messagesEndRef.current) {
        messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
      }
    }, [assistantState.messages]);

    // Handle sending a message
    const handleSendMessage = () => {
      if (newMessage.trim()) {
        sendMessage(newMessage);
        setNewMessage("");
      }
    };

    // Handle Enter key press
    const handleKeyPress = (e: React.KeyboardEvent) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSendMessage();
      }
    };

    return isMinimized ? (
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          className="rounded-full h-14 w-14 bg-primary shadow-lg flex items-center justify-center"
          onClick={toggleMinimize}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
          </svg>
        </Button>
      </div>
    ) : (
      <div className="fixed bottom-4 right-4 z-50 w-96 rounded-lg shadow-xl bg-card border">
        <div className="flex items-center justify-between p-3 border-b">
          <h3 className="font-medium">AI Assistant</h3>
          <div className="flex space-x-1">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={toggleMinimize}>
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 12H6"></path>
              </svg>
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={closeAssistant}>
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 6 6 18"></path>
                <path d="m6 6 12 12"></path>
              </svg>
            </Button>
          </div>
        </div>

        <div className="h-[350px] overflow-y-auto p-3 flex flex-col space-y-3 bg-muted/30">
          {assistantState.messages.filter(m => m.role !== "system").map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`
                  max-w-[85%] rounded-lg p-3
                  ${message.role === "user"
                    ? "bg-primary text-primary-foreground ml-auto"
                    : "bg-card border"
                  }
                `}
              >
                <div className="text-sm">{message.content}</div>
                <div className="text-xs opacity-70 mt-1 text-right">
                  {formatTime(message.timestamp)}
                </div>
              </div>
            </div>
          ))}

          {assistantState.isTyping && (
            <div className="flex justify-start">
              <div className="max-w-[85%] rounded-lg p-3 bg-card border">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 rounded-full bg-muted-foreground/30 animate-bounce"
                       style={{ animationDelay: "0ms" }}></div>
                  <div className="w-2 h-2 rounded-full bg-muted-foreground/30 animate-bounce"
                       style={{ animationDelay: "150ms" }}></div>
                  <div className="w-2 h-2 rounded-full bg-muted-foreground/30 animate-bounce"
                       style={{ animationDelay: "300ms" }}></div>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {assistantState.suggestions.length > 0 && (
          <div className="p-2 border-t overflow-x-auto">
            <div className="flex space-x-2">
              {assistantState.suggestions.map((suggestion, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="whitespace-nowrap"
                  onClick={() => executeSuggestion(suggestion)}
                >
                  {suggestion.label}
                </Button>
              ))}
            </div>
          </div>
        )}

        <div className="p-3 border-t flex space-x-2">
          <Input
            placeholder="Ask me anything..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={handleKeyPress}
          />
          <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
              <path d="m22 2-7 20-4-9-9-4Z"></path>
              <path d="M22 2 11 13"></path>
            </svg>
            Send
          </Button>
        </div>
      </div>
    );
  };

  return (
    <AssistantContext.Provider
      value={{
        assistantState,
        openAssistant,
        closeAssistant,
        sendMessage,
        setCurrentSection,
        logUserAction,
        executeSuggestion,
        isMinimized,
        toggleMinimize
      }}
    >
      {children}
      {assistantState.isOpen && <AssistantComponent />}
    </AssistantContext.Provider>
  );
};

// Hook to use the assistant context
export const useAssistant = () => {
  const context = useContext(AssistantContext);
  if (context === undefined) {
    throw new Error("useAssistant must be used within an AssistantProvider");
  }
  return context;
};

// Helper component for floating assistant button
export const AssistantButton = () => {
  const { openAssistant, assistantState } = useAssistant();

  return !assistantState.isOpen ? (
    <div className="fixed bottom-4 right-4 z-50">
      <Button
        className="rounded-full h-14 w-14 bg-primary shadow-lg flex items-center justify-center"
        onClick={openAssistant}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 12a9 9 0 0 1-9 9m9-9a9 9 0 0 0-9-9m9 9H3m9 9a9 9 0 0 1-9-9m9 9c-2.08 0-4.06-.32-5.87-.88A9 9 0 0 1 3 12m9-9c2.08 0 4.06.32 5.87.88A9 9 0 0 1 21 12"></path>
        </svg>
      </Button>
    </div>
  ) : null;
};

// Section-specific assistant helper
export const SectionAssistant = ({ section, title }: { section: string, title: string }) => {
  const { setCurrentSection, openAssistant, assistantState, executeSuggestion } = useAssistant();
  const [localSuggestions, setLocalSuggestions] = useState<SuggestionAction[]>([]);

  useEffect(() => {
    // Set the current section when component mounts
    setCurrentSection(section);

    // Generate section-specific suggestions
    const suggestions = generateSectionSuggestions(section);
    setLocalSuggestions(suggestions);
  }, [section]);

  // Generate suggestions specific to this section
  const generateSectionSuggestions = (section: string): SuggestionAction[] => {
    switch (section) {
      case "models":
        return [
          { label: "Find optimal model", action: "find_model", section },
          { label: "Compare models", action: "compare_models", section }
        ];
      case "api-install":
        return [
          { label: "Configure API", action: "configure_api", section },
          { label: "Set up weights", action: "setup_weights", section }
        ];
      case "agent-flow":
        return [
          { label: "New workflow", action: "new_workflow", section },
          { label: "Import template", action: "import_template", section }
        ];
      default:
        return [
          { label: "Get help", action: "get_help", section },
          { label: "See examples", action: "see_examples", section }
        ];
    }
  };

  return (
    <Card className="mb-4">
      <div className="p-4 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-medium">{title} Assistant</h3>
          <p className="text-xs text-muted-foreground">
            Get AI guidance for this section
          </p>
        </div>
        <div className="flex items-center space-x-2">
          {localSuggestions.map((suggestion, i) => (
            <Button
              key={i}
              variant="outline"
              size="sm"
              onClick={() => {
                setCurrentSection(section);
                executeSuggestion(suggestion);
                openAssistant();
              }}
            >
              {suggestion.label}
            </Button>
          ))}
          <Button
            variant="default"
            size="sm"
            onClick={() => {
              setCurrentSection(section);
              openAssistant();
            }}
          >
            Ask AI
          </Button>
        </div>
      </div>
    </Card>
  );
};
