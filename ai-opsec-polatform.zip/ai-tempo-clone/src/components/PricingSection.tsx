"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { CheckIcon } from "lucide-react";

const plans = [
  {
    name: "Free",
    description: "For individual developers who want to try AI assistance",
    price: "$0",
    billing: "/ month",
    features: [
      "30 prompts (max 5 per day)",
      "Access to GPT-4 model only",
      "Error fixes are free",
      "Basic component library",
      "Community support"
    ],
    buttonText: "Start for Free",
    buttonVariant: "outline",
    popular: false
  },
  {
    name: "Pro",
    description: "For professional developers who need more AI power",
    price: "$30",
    billing: "/ month",
    features: [
      "Full access to all AI models",
      "Unlimited prompts",
      "Priority response times",
      "Model comparison tool",
      "Add 250 bonus prompts for $50 anytime",
      "Error fixes are free",
      "Advanced component library",
      "Email support"
    ],
    buttonText: "Get Started",
    buttonVariant: "default",
    popular: true
  },
  {
    name: "Agent+",
    description: "For teams that need dedicated AI assistance",
    price: "$4,000",
    billing: "/ month",
    features: [
      "Custom AI model fine-tuning",
      "Our agents design and build 1-3 features for you per week",
      "Quality guaranteed by Human Engineers and Designers",
      "48-72hr turnaround time",
      "Unlimited design revisions",
      "Code review improvements",
      "Priority support",
      "Dedicated account manager"
    ],
    buttonText: "Book a Call",
    buttonVariant: "outline",
    popular: false
  }
];

export function PricingSection() {
  return (
    <section id="pricing" className="py-20 md:py-28 lg:py-36 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="mb-12 space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Plans & pricing</h2>
          <p className="mx-auto max-w-[700px] text-lg text-muted-foreground">
            Choose the plan that best fits your needs with access to different AI models
          </p>
        </div>

        <div className="mx-auto grid max-w-5xl gap-6 md:grid-cols-1 lg:grid-cols-3">
          {plans.map((plan, index) => (
            <Card key={index} className={`flex flex-col overflow-hidden border ${plan.popular ? 'border-primary shadow-lg' : 'border-border'}`}>
              {plan.popular && (
                <div className="bg-primary py-1 text-center text-xs font-medium text-primary-foreground">
                  MOST POPULAR
                </div>
              )}

              <CardHeader>
                <CardTitle>{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>

              <CardContent className="flex-1">
                <div className="mb-6">
                  <div className="flex items-end">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className="text-sm text-muted-foreground">{plan.billing}</span>
                  </div>
                </div>

                <ul className="space-y-2">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <CheckIcon className="h-5 w-5 text-primary shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>

              <CardFooter>
                <Link href="#" className="w-full">
                  <Button variant={plan.buttonVariant as "outline" | "default"} className="w-full">
                    {plan.buttonText}
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <div className="inline-flex items-center justify-center rounded-full border border-border/40 bg-background/80 px-6 py-3 text-sm font-medium shadow-sm">
            <span className="mr-2">Need more AI power?</span>
            <Link href="#">
              <Button variant="outline" size="sm">
                Get 250 bonus prompts for $50
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
