"use client";

import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "@/components/ui/select";

const aiModels = [
  { id: "gpt-4", name: "GPT-4", provider: "OpenAI", description: "Advanced reasoning and coding" },
  { id: "claude-3", name: "Claude 3", provider: "Anthropic", description: "Excellent for creative tasks" },
  { id: "gemini-pro", name: "Gemini Pro", provider: "Google", description: "Strong at technical analysis" },
  { id: "llama-3", name: "Llama 3", provider: "Meta", description: "Open-source performance" },
  { id: "mistral", name: "Mistral", provider: "Mistral AI", description: "Efficient and accurate" },
];

export function HeroSection() {
  const [selectedModel, setSelectedModel] = useState(aiModels[0]);

  return (
    <section className="relative py-20 md:py-28 lg:py-36 overflow-hidden bg-background dark:bg-slate-950">
      {/* Background pattern/dots similar to Tempo's site */}
      <div className="absolute inset-0 z-0 opacity-20 pointer-events-none bg-[url('https://ext.same-assets.com/1231115373/494669423.webp')] bg-repeat"></div>

      <div className="container relative z-10 px-4 md:px-6">
        <div className="mx-auto max-w-4xl text-center">
          <div className="space-y-4">
            <div className="inline-flex items-center rounded-full border border-border/40 bg-background/80 px-3 py-1 text-sm font-medium shadow-sm">
              <span className="mr-1 h-2 w-2 rounded-full bg-green-500"></span>
              <span className="text-muted-foreground">Build React Apps 10x Faster</span>
            </div>

            <h1 className="text-4xl font-bold tracking-tight md:text-5xl lg:text-6xl">
              Build React Apps <span className="text-primary">10x Faster</span> with
              <span className="relative ml-2">
                Your AI
                <span className="absolute -bottom-1 left-0 h-1 w-full bg-primary"></span>
              </span>
            </h1>

            <p className="text-xl text-muted-foreground md:text-2xl">
              Choose your preferred AI model and accelerate your development
            </p>
          </div>

          {/* AI Model Selection Feature */}
          <div className="mt-8 md:mt-12">
            <Card className="mx-auto max-w-md bg-card/50 backdrop-blur-sm border-border/50">
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-muted-foreground">Select your AI assistant</h3>
                    <Select defaultValue={selectedModel.id} onValueChange={(value) =>
                      setSelectedModel(aiModels.find(model => model.id === value) || aiModels[0])
                    }>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select an AI model" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectGroup>
                          <SelectLabel>AI Models</SelectLabel>
                          {aiModels.map((model) => (
                            <SelectItem key={model.id} value={model.id}>
                              {model.name} - {model.provider}
                            </SelectItem>
                          ))}
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="rounded-md bg-muted p-3">
                    <div className="font-medium">{selectedModel.name}</div>
                    <div className="text-sm text-muted-foreground">{selectedModel.description}</div>
                  </div>

                  <Button className="w-full">
                    Get Started with {selectedModel.name}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <Link href="https://www.ycombinator.com/" className="inline-flex items-center rounded-md border border-border bg-background px-4 py-2 text-sm font-medium shadow-sm">
              <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect width="24" height="24" rx="4" fill="#FF6600" />
                <path d="M6 6H18V18H6V6Z" fill="#FF6600" />
                <path d="M12 8L14.5 12.5H9.5L12 8Z" fill="white" />
                <path d="M12 16V13.5" stroke="white" strokeWidth="1.5" />
              </svg>
              Backed by Combinator
            </Link>
            <Link href="https://www.producthunt.com/" className="inline-flex items-center rounded-md border border-border bg-background px-4 py-2 text-sm font-medium shadow-sm">
              <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect width="24" height="24" rx="4" fill="#DA552F" />
                <path d="M13 8H16V12H13V8Z" fill="white" />
                <path d="M8 8H12V16H8V8Z" fill="white" />
              </svg>
              #1 Product of the Day
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
