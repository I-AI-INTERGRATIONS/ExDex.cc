"use client";

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { PlusIcon, XIcon } from "lucide-react"; // Added import
import { SectionAssistant } from "@/components/IntegratedAssistantProvider"; // Update import list at the top

type Api = {
  id: string;
  name: string;
  description: string;
  logoUrl: string;
  supportsCensorship?: boolean;
  localizedWeights?: boolean;
  size: string;
};

const apiOptions: Api[] = [
  {
    id: "openai",
    name: "OpenAI API",
    description: "Access GPT-4 and other OpenAI models",
    logoUrl: "/openai-logo.svg",
    size: "~350MB"
  },
  {
    id: "anthropic",
    name: "Anthropic API",
    description: "Access Claude 3 and other Anthropic models",
    logoUrl: "/anthropic-logo.svg",
    size: "~400MB"
  },
  {
    id: "gemini",
    name: "Google Gemini API",
    description: "Access Gemini Pro models from Google",
    logoUrl: "/gemini-logo.svg",
    size: "~380MB"
  },
  {
    id: "qwen",
    name: "Qwen API",
    description: "Access Qwen models with localized weights",
    logoUrl: "/qwen-logo.svg",
    supportsCensorship: true,
    localizedWeights: true,
    size: "~7GB"
  },
  {
    id: "whiterabbitneo",
    name: "WhiteRabbitNeo API",
    description: "Custom models with censorship toggle options",
    logoUrl: "/whiterabbitneo-logo.svg",
    supportsCensorship: true,
    size: "~5GB"
  },
  {
    id: "meta-llama",
    name: "Meta Llama 3 API",
    description: "Access Llama 3 models with full weights",
    logoUrl: "/meta-logo.svg",
    localizedWeights: true,
    size: "~8GB"
  },
  {
    id: "mistral",
    name: "Mistral API",
    description: "Access efficient Mistral AI models",
    logoUrl: "/mistral-logo.svg",
    localizedWeights: true,
    size: "~4GB"
  }
];

export function ApiInstallSection() {
  const [installedApis, setInstalledApis] = useState<string[]>([]);
  const [uncensoredModels, setUncensoredModels] = useState<string[]>([]);
  const [localWeightsEnabled, setLocalWeightsEnabled] = useState<string[]>([]);
  const [isDragging, setIsDragging] = useState<string | null>(null);
  const [selectedApi, setSelectedApi] = useState<Api | null>(null);

  // New state variables for quick URL adder
  const [isQuickAdderOpen, setIsQuickAdderOpen] = useState(false);
  const [quickUrl, setQuickUrl] = useState("");
  const [isAddingUrl, setIsAddingUrl] = useState(false);
  const [recentUrls, setRecentUrls] = useState<string[]>([
    "huggingface.co/facebook/mms-1b-all",
    "github.com/api/v3/users"
  ]);

  const handleDragStart = (e: React.DragEvent, apiId: string) => {
    e.dataTransfer.setData("apiId", apiId);
    setIsDragging(apiId);
  };

  const handleDragEnd = () => {
    setIsDragging(null);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const apiId = e.dataTransfer.getData("apiId");
    if (!installedApis.includes(apiId)) {
      setInstalledApis([...installedApis, apiId]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const toggleCensorship = (apiId: string) => {
    if (uncensoredModels.includes(apiId)) {
      setUncensoredModels(uncensoredModels.filter(id => id !== apiId));
    } else {
      setUncensoredModels([...uncensoredModels, apiId]);
    }
  };

  const toggleLocalWeights = (apiId: string) => {
    if (localWeightsEnabled.includes(apiId)) {
      setLocalWeightsEnabled(localWeightsEnabled.filter(id => id !== apiId));
    } else {
      setLocalWeightsEnabled([...localWeightsEnabled, apiId]);
    }
  };

  const removeApi = (apiId: string) => {
    setInstalledApis(installedApis.filter(id => id !== apiId));
    setUncensoredModels(uncensoredModels.filter(id => id !== apiId));
    setLocalWeightsEnabled(localWeightsEnabled.filter(id => id !== apiId));
  };

  // New function to handle quick URL submission
  const handleQuickUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickUrl.trim()) return;

    setIsAddingUrl(true);

    // Simulate API call to validate and process the URL
    setTimeout(() => {
      // Create a mock API from the URL
      const urlParts = quickUrl.split('/');
      const apiId = urlParts[urlParts.length - 2] && urlParts[urlParts.length - 1]
        ? `${urlParts[urlParts.length - 2]}/${urlParts[urlParts.length - 1]}`
        : quickUrl;

      const newApi = {
        id: apiId,
        name: urlParts[urlParts.length - 1] || "API",
        author: urlParts[urlParts.length - 2] || "Unknown",
        connectedAt: new Date().toISOString(),
        status: "active",
        type: quickUrl.toLowerCase().includes('speech') ? 'speech' :
              quickUrl.toLowerCase().includes('audio') ? 'audio' : 'model'
      };

      // Add to installed APIs
      if (!installedApis.includes(apiId)) {
        setInstalledApis([...installedApis, apiId]);
      }

      // Add to recent URLs if not already there
      if (!recentUrls.includes(quickUrl)) {
        setRecentUrls([quickUrl, ...recentUrls.slice(0, 4)]);
      }

      setQuickUrl("");
      setIsAddingUrl(false);
      setIsQuickAdderOpen(false);
    }, 800);
  };

  return (
    <section id="api-install" className="py-20 md:py-28 lg:py-36 border-t border-border/40">
      <div className="container px-4 md:px-6">
        <div className="mb-12 space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Install API & SDK Libraries</h2>
          <p className="mx-auto max-w-[700px] text-lg text-muted-foreground">
            Drag and drop APIs to install complete model libraries with customizable options
          </p>
        </div>

        <SectionAssistant section="api-install" title="API Installation" /> {/* Added SectionAssistant */}

        {/* Rest of the component remains the same */}
        <div className="grid gap-8 md:grid-cols-2">
          {/* Available APIs */}
          <Card className="bg-card/50 backdrop-blur-sm border-border/50">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-4">Available APIs</h3>
              <p className="text-sm text-muted-foreground mb-6">Drag APIs to the installation area to add them to your project</p>

              <div className="grid gap-4">
                {apiOptions.map((api) => (
                  <div
                    key={api.id}
                    draggable
                    onDragStart={(e) => handleDragStart(e, api.id)}
                    onDragEnd={handleDragEnd}
                    className={`flex items-center p-3 rounded-md border ${
                      isDragging === api.id
                        ? "border-primary bg-primary/10 opacity-50"
                        : installedApis.includes(api.id)
                          ? "border-green-500/30 bg-green-500/5"
                          : "border-border hover:border-border/80"
                    } cursor-grab transition-all`}
                    onClick={() => setSelectedApi(api)}
                  >
                    <div className="mr-3 w-10 h-10 flex items-center justify-center bg-muted rounded">
                      <div className="text-primary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                          <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
                          <line x1="12" y1="22.08" x2="12" y2="12"></line>
                        </svg>
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">{api.name}</h4>
                      <div className="text-xs text-muted-foreground flex items-center gap-2">
                        <span>{api.size}</span>
                        {api.localizedWeights && (
                          <span className="inline-flex items-center rounded-full border border-indigo-400/30 bg-indigo-500/10 px-2 py-0.5 text-xs font-medium text-indigo-400">
                            Local Weights
                          </span>
                        )}
                        {api.supportsCensorship && (
                          <span className="inline-flex items-center rounded-full border border-amber-400/30 bg-amber-500/10 px-2 py-0.5 text-xs font-medium text-amber-400">
                            Censorship Toggle
                          </span>
                        )}
                      </div>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="ghost" size="icon" className="ml-2 h-8 w-8">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="12" y1="8" x2="12" y2="16"></line>
                            <line x1="8" y1="12" x2="16" y2="12"></line>
                          </svg>
                          <span className="sr-only">Info</span>
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>{api.name}</DialogTitle>
                          <DialogDescription>{api.description}</DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div>
                            <h4 className="font-medium mb-2">Size</h4>
                            <p className="text-sm text-muted-foreground">{api.size}</p>
                          </div>
                          {api.localizedWeights && (
                            <div>
                              <h4 className="font-medium mb-2">Localized Weights Support</h4>
                              <p className="text-sm text-muted-foreground">This API supports downloading localized weights for offline use.</p>
                            </div>
                          )}
                          {api.supportsCensorship && (
                            <div>
                              <h4 className="font-medium mb-2">Censorship Options</h4>
                              <p className="text-sm text-muted-foreground">This API allows toggling between censored and uncensored modes.</p>
                            </div>
                          )}
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Installation Area */}
          <div>
            <Card
              className="bg-muted/30 backdrop-blur-sm border-border/50 border-dashed mb-6"
              onDrop={handleDrop}
              onDragOver={handleDragOver}
            >
              <CardContent className="p-6 min-h-[300px] flex flex-col items-center justify-center">
                {installedApis.length === 0 ? (
                  <div className="text-center">
                    <div className="mx-auto w-16 h-16 mb-4 text-muted-foreground flex items-center justify-center rounded-full border-2 border-dashed">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="17 8 12 3 7 8"></polyline>
                        <line x1="12" y1="3" x2="12" y2="15"></line>
                      </svg>
                    </div>
                    <h3 className="text-lg font-medium">Drag APIs Here</h3>
                    <p className="text-sm text-muted-foreground mt-2 max-w-md">
                      Drag an API from the left panel to install it. Configure local weights and censorship options after installation.
                    </p>
                  </div>
                ) : (
                  <div className="w-full">
                    <h3 className="text-lg font-medium mb-4">Installed APIs</h3>
                    <div className="space-y-4 w-full">
                      {installedApis.map(apiId => {
                        const api = apiOptions.find(a => a.id === apiId);
                        if (!api) return null;

                        return (
                          <div key={api.id} className="border border-border rounded-md p-4">
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center">
                                <div className="mr-3 w-8 h-8 flex items-center justify-center bg-primary/10 rounded text-primary">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                                    <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                                  </svg>
                                </div>
                                <div>
                                  <h4 className="font-medium">{api.name}</h4>
                                  <p className="text-xs text-muted-foreground">{api.size}</p>
                                </div>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 text-destructive hover:text-destructive/80"
                                onClick={() => removeApi(api.id)}
                              >
                                Remove
                              </Button>
                            </div>

                            {/* Configuration Options */}
                            {(api.localizedWeights || api.supportsCensorship) && (
                              <div className="border-t border-border/60 mt-3 pt-3 space-y-3">
                                {api.localizedWeights && (
                                  <div className="flex items-center justify-between">
                                    <div>
                                      <Label htmlFor={`local-weights-${api.id}`} className="font-medium">Download Local Weights</Label>
                                      <p className="text-xs text-muted-foreground">
                                        Enable for 100% localized model weights
                                      </p>
                                    </div>
                                    <Switch
                                      id={`local-weights-${api.id}`}
                                      checked={localWeightsEnabled.includes(api.id)}
                                      onCheckedChange={() => toggleLocalWeights(api.id)}
                                    />
                                  </div>
                                )}

                                {api.supportsCensorship && (
                                  <div className="flex items-center justify-between">
                                    <div>
                                      <Label htmlFor={`uncensored-${api.id}`} className="font-medium">Uncensored Mode</Label>
                                      <p className="text-xs text-muted-foreground">
                                        Toggle between censored and uncensored output
                                      </p>
                                    </div>
                                    <Switch
                                      id={`uncensored-${api.id}`}
                                      checked={uncensoredModels.includes(api.id)}
                                      onCheckedChange={() => toggleCensorship(api.id)}
                                    />
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {installedApis.length > 0 && (
              <div className="text-center">
                <Button className="w-full md:w-auto">
                  Install Selected APIs ({installedApis.length})
                </Button>
                <p className="text-xs text-muted-foreground mt-2">
                  Total download size: {apiOptions
                    .filter(api => installedApis.includes(api.id))
                    .reduce((total, api) => total + parseInt(api.size.replace(/[^0-9]/g, '')), 0)}MB+
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick URL Adder */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end space-y-2">
        {isQuickAdderOpen && (
          <div className="mb-2 w-80 rounded-lg border bg-card p-4 shadow-lg">
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-sm font-medium">Quick Add API URL</h3>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 w-7 p-0"
                onClick={() => setIsQuickAdderOpen(false)}
              >
                <XIcon className="h-4 w-4" />
              </Button>
            </div>

            <form onSubmit={handleQuickUrlSubmit} className="space-y-3">
              <div className="flex space-x-2">
                <Input
                  placeholder="Enter API or model URL"
                  value={quickUrl}
                  onChange={(e) => setQuickUrl(e.target.value)}
                  className="h-9"
                />
                <Button
                  type="submit"
                  className="h-9"
                  disabled={!quickUrl.trim() || isAddingUrl}
                >
                  {isAddingUrl ? "Adding..." : "Add"}
                </Button>
              </div>

              {recentUrls.length > 0 && (
                <div>
                  <div className="mb-1 text-xs text-muted-foreground">Recent URLs</div>
                  <div className="space-y-1.5">
                    {recentUrls.map((recentUrl, index) => (
                      <div
                        key={index}
                        className="flex cursor-pointer items-center rounded-md px-2 py-1 text-xs hover:bg-muted"
                        onClick={() => {
                          setQuickUrl(recentUrl);
                        }}
                      >
                        <div className="mr-2 flex h-5 w-5 items-center justify-center rounded-full bg-primary/10">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="12"
                            height="12"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="text-primary"
                          >
                            <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                            <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
                          </svg>
                        </div>
                        <span className="truncate">{recentUrl}</span>
                      </div>
                    ))}
                  </div>

                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-2 h-7 w-full text-xs"
                    onClick={() => setRecentUrls([])}
                  >
                    Clear History
                  </Button>
                </div>
              )}
            </form>
          </div>
        )}

        <Button
          variant={isQuickAdderOpen ? "default" : "secondary"}
          size="icon"
          className="h-12 w-12 rounded-full shadow-lg"
          onClick={() => setIsQuickAdderOpen(!isQuickAdderOpen)}
        >
          <PlusIcon className="h-6 w-6" />
        </Button>
      </div>
    </section>
  );
}
