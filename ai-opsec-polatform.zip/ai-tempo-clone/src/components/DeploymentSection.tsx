"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

type DeploymentStats = {
  projects: number;
  activeDeployments: number;
  users: number;
  apiCalls: string;
};

const mockStats: DeploymentStats = {
  projects: 12,
  activeDeployments: 8,
  users: 37,
  apiCalls: "1.2M"
};

export function DeploymentSection() {
  const [selectedTab, setSelectedTab] = useState("dashboard");

  return (
    <section id="deployment" className="py-20 md:py-28 lg:py-36 border-t border-border/40">
      <div className="container px-4 md:px-6">
        <div className="mb-12 space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Deploy Your Own AI Platform</h2>
          <p className="mx-auto max-w-[700px] text-lg text-muted-foreground">
            Host your own AI Tempo instance with full control over users, projects, and applications
          </p>
        </div>

        <Tabs defaultValue="dashboard" className="mx-auto max-w-4xl" onValueChange={setSelectedTab}>
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="deployment">Deployment</TabsTrigger>
            <TabsTrigger value="projects">Projects</TabsTrigger>
          </TabsList>

          {/* Dashboard View */}
          <TabsContent value="dashboard" className="space-y-8">
            <div className="grid gap-6 md:grid-cols-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Projects</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{mockStats.projects}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Deployments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{mockStats.activeDeployments}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Users</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{mockStats.users}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">API Calls</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{mockStats.apiCalls}</div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Overview of recent activities across your platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-4 rounded-md border p-4">
                    <div className="h-10 w-10 flex-shrink-0 rounded-full bg-primary/10 flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                        <polyline points="14 2 14 8 20 8" />
                      </svg>
                    </div>
                    <div>
                      <p className="font-medium">New Project Created</p>
                      <p className="text-sm text-muted-foreground">User created a new AI dashboard project</p>
                    </div>
                    <div className="ml-auto text-sm text-muted-foreground">2h ago</div>
                  </div>
                  <div className="flex items-center gap-4 rounded-md border p-4">
                    <div className="h-10 w-10 flex-shrink-0 rounded-full bg-primary/10 flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
                      </svg>
                    </div>
                    <div>
                      <p className="font-medium">API Usage Spike</p>
                      <p className="text-sm text-muted-foreground">Unusual activity detected on the Analytics project</p>
                    </div>
                    <div className="ml-auto text-sm text-muted-foreground">5h ago</div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">View All Activity</Button>
              </CardFooter>
            </Card>
          </TabsContent>

          {/* Deployment Options */}
          <TabsContent value="deployment" className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Deployment Options</CardTitle>
                <CardDescription>Choose how to deploy your AI platform</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-md border p-4">
                  <div className="flex justify-between items-center mb-2">
                    <div>
                      <h3 className="font-medium">Self-Hosted</h3>
                      <p className="text-sm text-muted-foreground">Deploy on your own infrastructure</p>
                    </div>
                    <Button variant="outline">Select</Button>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Full control over your data</li>
                      <li>Customizable configuration</li>
                      <li>No monthly fees</li>
                    </ul>
                  </div>
                </div>

                <div className="rounded-md border p-4 bg-primary/5 border-primary/20">
                  <div className="flex justify-between items-center mb-2">
                    <div>
                      <h3 className="font-medium">Managed SaaS</h3>
                      <p className="text-sm text-muted-foreground">We handle hosting for you</p>
                    </div>
                    <Button>Selected</Button>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    <ul className="list-disc pl-5 space-y-1">
                      <li>99.9% uptime guarantee</li>
                      <li>Automatic updates and backups</li>
                      <li>Technical support included</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Projects View */}
          <TabsContent value="projects" className="space-y-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold">Project Templates</h3>
              <Button variant="outline" size="sm">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                  <path d="M5 12h14" />
                  <path d="M12 5v14" />
                </svg>
                New Project
              </Button>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              <Card className="overflow-hidden">
                <div className="aspect-video w-full bg-muted flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-muted-foreground">
                    <rect width="18" height="18" x="3" y="3" rx="2" />
                    <path d="M3 9h18" />
                    <path d="M9 21V9" />
                  </svg>
                </div>
                <CardHeader>
                  <CardTitle>E-commerce Dashboard</CardTitle>
                  <CardDescription>Complete dashboard for managing products</CardDescription>
                </CardHeader>
                <CardFooter className="flex gap-2">
                  <Button variant="outline" className="w-full">Preview</Button>
                  <Button className="w-full">Use Template</Button>
                </CardFooter>
              </Card>

              <Card className="overflow-hidden">
                <div className="aspect-video w-full bg-muted flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-muted-foreground">
                    <path d="M3 3v18h18" />
                    <path d="m19 9-5 5-4-4-3 3" />
                  </svg>
                </div>
                <CardHeader>
                  <CardTitle>Analytics Platform</CardTitle>
                  <CardDescription>Data visualization and reporting suite</CardDescription>
                </CardHeader>
                <CardFooter className="flex gap-2">
                  <Button variant="outline" className="w-full">Preview</Button>
                  <Button className="w-full">Use Template</Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}
