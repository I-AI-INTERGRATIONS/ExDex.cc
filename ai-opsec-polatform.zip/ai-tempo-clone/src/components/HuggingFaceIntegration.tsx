"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

// Mock data for speech-to-speech models
const popularSpeechModels = [
  {
    id: "facebook/s2st-small-mustc-en-fr-st",
    name: "S2ST Small MUST-C EN-FR",
    author: "facebook",
    stars: 245,
    downloads: "89.5K",
    tags: ["speech-to-speech", "translation"],
    languages: ["en", "fr"],
    description: "Small speech-to-speech translation model for English to French"
  },
  {
    id: "facebook/s2st-medium-mustc-en-es-st",
    name: "S2ST Medium MUST-C EN-ES",
    author: "facebook",
    stars: 187,
    downloads: "62.3K",
    tags: ["speech-to-speech", "translation"],
    languages: ["en", "es"],
    description: "Medium speech-to-speech translation model for English to Spanish"
  },
  {
    id: "speechbrain/sepformer-wham",
    name: "SepFormer WHAM",
    author: "speechbrain",
    stars: 312,
    downloads: "124.1K",
    tags: ["speech-separation", "audio-processing"],
    languages: ["en"],
    description: "Speech separation model for noisy environments"
  },
  {
    id: "microsoft/speecht5_tts",
    name: "SpeechT5 TTS",
    author: "microsoft",
    stars: 502,
    downloads: "256.3K",
    tags: ["text-to-speech", "voice-synthesis"],
    languages: ["en"],
    description: "High-quality text-to-speech synthesis model"
  },
  {
    id: "espnet/kan-bayashi_ljspeech_vits",
    name: "LJSpeech VITS",
    author: "espnet",
    stars: 178,
    downloads: "43.2K",
    tags: ["text-to-speech", "voice-synthesis"],
    languages: ["en"],
    description: "VITS model trained on LJSpeech dataset"
  }
];

const recentlyUsed = [
  {
    id: "facebook/mms-1b-all",
    name: "MMS-1B-all",
    author: "facebook",
    lastUsed: "2 hours ago",
    type: "speech recognition"
  },
  {
    id: "openai/whisper-large-v3",
    name: "Whisper Large v3",
    author: "openai",
    lastUsed: "yesterday",
    type: "speech recognition"
  }
];

interface Repository {
  id: string;
  name: string;
  author: string;
  connectedAt: string;
  status: string;
  type: string;
}

export function HuggingFaceIntegration() {
  const [searchQuery, setSearchQuery] = useState("");
  const [urlInput, setUrlInput] = useState("");
  const [selectedModels, setSelectedModels] = useState<string[]>([]);
  const [connectedRepositories, setConnectedRepositories] = useState<Repository[]>([]);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<null | "success" | "error">(null);

  const handleConnect = () => {
    // Simulate connection process
    if (!urlInput) return;

    setIsConnecting(true);

    // Simulate API call
    setTimeout(() => {
      // Extract repo name from URL
      const repoName = urlInput.split('/').slice(-2).join('/');
      if (repoName && repoName.includes('/')) {
        setConnectedRepositories([...connectedRepositories, {
          id: repoName,
          name: repoName.split('/')[1],
          author: repoName.split('/')[0],
          connectedAt: new Date().toISOString(),
          status: "active",
          type: urlInput.toLowerCase().includes('speech') ? 'speech' :
                 urlInput.toLowerCase().includes('audio') ? 'audio' : 'model'
        }]);
        setConnectionStatus("success");
      } else {
        setConnectionStatus("error");
      }

      setIsConnecting(false);
      // Reset after 3 seconds
      setTimeout(() => {
        setConnectionStatus(null);
        setUrlInput("");
      }, 3000);
    }, 1500);
  };

  const toggleModelSelection = (modelId: string) => {
    if (selectedModels.includes(modelId)) {
      setSelectedModels(selectedModels.filter(id => id !== modelId));
    } else {
      setSelectedModels([...selectedModels, modelId]);
    }
  };

  const handleImportSelected = () => {
    // Here you would implement the actual import logic
    alert(`Importing ${selectedModels.length} models`);
  };

  const filteredModels = popularSpeechModels.filter(model =>
    model.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    model.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    model.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <section id="huggingface" className="py-20 md:py-28 lg:py-36 border-t border-border/40">
      <div className="container px-4 md:px-6">
        <div className="mb-12 space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Hugging Face Integration</h2>
          <p className="mx-auto max-w-[700px] text-lg text-muted-foreground">
            Connect to any Hugging Face repository for speech-to-speech models and pipelines
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-1 lg:grid-cols-3">
          {/* Connect Repository Panel */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Connect Repository</CardTitle>
              <CardDescription>
                Link any Hugging Face model, space, or pipeline
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="repository-url">Repository URL or ID</Label>
                <div className="flex space-x-2">
                  <Input
                    id="repository-url"
                    placeholder="facebook/mms-1b-all"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                  />
                  <Button
                    onClick={handleConnect}
                    disabled={isConnecting || !urlInput}
                  >
                    {isConnecting ? "Connecting..." : "Connect"}
                  </Button>
                </div>
                {connectionStatus === "success" && (
                  <p className="text-sm text-green-500">Successfully connected to repository!</p>
                )}
                {connectionStatus === "error" && (
                  <p className="text-sm text-red-500">Failed to connect. Please check the URL and try again.</p>
                )}
              </div>

              <div className="pt-4">
                <h3 className="mb-3 text-sm font-medium">Recently Used</h3>
                <div className="space-y-3">
                  {recentlyUsed.map((item) => (
                    <div key={item.id} className="flex items-center justify-between rounded-md border p-3">
                      <div className="flex items-center space-x-3">
                        <div className="h-9 w-9 rounded-md bg-primary/10 flex items-center justify-center">
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                            <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
                          </svg>
                        </div>
                        <div className="space-y-1">
                          <p className="font-medium leading-none">{item.name}</p>
                          <p className="text-xs text-muted-foreground">{item.author}</p>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setUrlInput(item.id)}
                      >
                        Use
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Connected Repositories & Models */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Speech Models & Pipelines</CardTitle>
              <div className="flex items-center justify-between">
                <CardDescription>
                  Discover and import speech-to-speech models
                </CardDescription>
                <div className="flex items-center space-x-2">
                  <Input
                    placeholder="Search models..."
                    className="w-[200px]"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  {selectedModels.length > 0 && (
                    <Button size="sm" onClick={handleImportSelected}>
                      Import ({selectedModels.length})
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="browse">
                <TabsList className="mb-4">
                  <TabsTrigger value="browse">Browse</TabsTrigger>
                  <TabsTrigger value="connected">
                    Connected
                    {connectedRepositories.length > 0 && (
                      <span className="ml-2 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium">
                        {connectedRepositories.length}
                      </span>
                    )}
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="browse" className="space-y-4">
                  {filteredModels.map((model) => (
                    <div key={model.id} className="flex items-start space-x-4 rounded-md border p-4">
                      <input
                        type="checkbox"
                        checked={selectedModels.includes(model.id)}
                        onChange={() => toggleModelSelection(model.id)}
                        className="h-5 w-5 rounded border-gray-300"
                      />
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium">{model.name}</h4>
                            <p className="text-sm text-muted-foreground">{model.id}</p>
                          </div>
                          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                            <span className="flex items-center">
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                              </svg>
                              {model.stars}
                            </span>
                            <span className="flex items-center">
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                                <polyline points="7 10 12 15 17 10" />
                                <line x1="12" y1="15" x2="12" y2="3" />
                              </svg>
                              {model.downloads}
                            </span>
                          </div>
                        </div>
                        <p className="text-sm">{model.description}</p>
                        <div className="flex flex-wrap gap-2">
                          {model.tags.map((tag, i) => (
                            <span key={i} className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium">
                              {tag}
                            </span>
                          ))}
                          {model.languages.map((lang, i) => (
                            <span key={i} className="inline-flex items-center rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
                              {lang}
                            </span>
                          ))}
                        </div>
                      </div>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm">
                            Details
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>{model.name}</DialogTitle>
                            <DialogDescription>
                              {model.id} by {model.author}
                            </DialogDescription>
                          </DialogHeader>
                          <div className="grid gap-4 py-4">
                            <div className="space-y-2">
                              <h4 className="font-medium">Description</h4>
                              <p className="text-sm">{model.description}</p>
                            </div>
                            <div className="space-y-2">
                              <h4 className="font-medium">Supported Languages</h4>
                              <div className="flex flex-wrap gap-2">
                                {model.languages.map((lang, i) => (
                                  <span key={i} className="inline-flex items-center rounded-full bg-primary/10 px-2.5 py-0.5 text-sm font-medium text-primary">
                                    {lang === 'en' ? 'English' :
                                     lang === 'fr' ? 'French' :
                                     lang === 'es' ? 'Spanish' : lang}
                                  </span>
                                ))}
                              </div>
                            </div>
                            <div className="space-y-2">
                              <h4 className="font-medium">Usage</h4>
                              <pre className="rounded-md bg-muted p-4 text-xs font-mono overflow-x-auto">
{`from transformers import pipeline

model_id = "${model.id}"
pipe = pipeline("${model.tags[0]}", model=model_id)

# For speech-to-speech translation
output = pipe("input_audio.wav", target_lang="fr")
`}
                              </pre>
                            </div>
                          </div>
                          <div className="flex justify-end">
                            <Button onClick={() => toggleModelSelection(model.id)}>
                              {selectedModels.includes(model.id) ? "Deselect" : "Select"}
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="connected">
                  {connectedRepositories.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-12">
                      <div className="rounded-full bg-muted p-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-muted-foreground">
                          <rect width="8" height="14" x="8" y="5" rx="1" />
                          <path d="M4 5v14" />
                          <path d="M20 5v14" />
                        </svg>
                      </div>
                      <h3 className="mt-4 text-lg font-medium">No Connected Repositories</h3>
                      <p className="mt-2 text-center text-sm text-muted-foreground">
                        Connect to Hugging Face repositories to access speech-to-speech models and pipelines.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {connectedRepositories.map((repo) => (
                        <div key={repo.id} className="flex items-start space-x-4 rounded-md border p-4">
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center justify-between">
                              <div>
                                <h4 className="font-medium">{repo.name}</h4>
                                <p className="text-sm text-muted-foreground">{repo.id}</p>
                              </div>
                              <div className="flex items-center space-x-2 text-sm">
                                <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                                  repo.status === 'active' ? 'bg-green-100 text-green-800 dark:bg-green-800/20 dark:text-green-500' : 'bg-amber-100 text-amber-800 dark:bg-amber-800/20 dark:text-amber-500'
                                }`}>
                                  {repo.status}
                                </span>
                              </div>
                            </div>
                            <div className="flex flex-wrap gap-2">
                              <span className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium">
                                {repo.type}
                              </span>
                              <span className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium">
                                {new Date(repo.connectedAt).toLocaleString()}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button variant="outline" size="sm">
                              Configure
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => setConnectedRepositories(
                                connectedRepositories.filter(r => r.id !== repo.id)
                              )}
                            >
                              Disconnect
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
            <CardFooter className="border-t pt-6 flex justify-between">
              <Button variant="outline" onClick={() => setSearchQuery("")}>
                Reset Filters
              </Button>
              <a
                href="https://huggingface.co/models?pipeline_tag=text-to-speech&sort=downloads"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center"
              >
                Browse on Hugging Face
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1">
                  <path d="M7 7h10v10" />
                  <path d="M7 17 17 7" />
                </svg>
              </a>
            </CardFooter>
          </Card>
        </div>

        {/* Speech Pipeline Configuration */}
        <div className="mt-12">
          <Card>
            <CardHeader>
              <CardTitle>Speech-to-Speech Pipeline Configuration</CardTitle>
              <CardDescription>
                Configure and deploy speech transformation pipelines
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="source-model">Source Speech Recognition</Label>
                    <select id="source-model" className="w-full p-2 rounded-md border border-input bg-background">
                      <option value="">Select a model</option>
                      <option value="openai/whisper-large-v3">Whisper Large v3</option>
                      <option value="facebook/mms-1b-all">Facebook MMS-1B</option>
                      <option value="facebook/wav2vec2-large-robust-ft-swbd-300h">Wav2Vec2 Large Robust</option>
                    </select>
                    <p className="text-xs text-muted-foreground">Speech recognition model to transcribe input audio</p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="target-model">Speech Synthesis</Label>
                    <select id="target-model" className="w-full p-2 rounded-md border border-input bg-background">
                      <option value="">Select a model</option>
                      <option value="microsoft/speecht5_tts">Microsoft SpeechT5 TTS</option>
                      <option value="espnet/kan-bayashi_ljspeech_vits">LJSpeech VITS</option>
                      <option value="facebook/seamless-m4t-large">Facebook Seamless M4T</option>
                    </select>
                    <p className="text-xs text-muted-foreground">Text-to-speech model to synthesize output audio</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pipeline-type">Pipeline Type</Label>
                  <select id="pipeline-type" className="w-full p-2 rounded-md border border-input bg-background">
                    <option value="translation">Speech Translation</option>
                    <option value="conversion">Voice Conversion</option>
                    <option value="enhancement">Speech Enhancement</option>
                    <option value="custom">Custom Pipeline</option>
                  </select>
                  <p className="text-xs text-muted-foreground">Type of speech processing pipeline to create</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pipeline-config">Pipeline Configuration (JSON)</Label>
                  <textarea
                    id="pipeline-config"
                    rows={6}
                    className="w-full p-2 font-mono text-sm rounded-md border border-input bg-background resize-none"
                    defaultValue={`{
  "input_sampling_rate": 16000,
  "output_sampling_rate": 24000,
  "source_lang": "en",
  "target_lang": "fr",
  "use_cuda": true,
  "batch_size": 16,
  "speakers": ["speaker_1", "speaker_2"],
  "vocoder": "hifigan"
}`}
                  ></textarea>
                </div>

                <div className="pt-4 flex justify-end space-x-2">
                  <Button variant="outline">Save Configuration</Button>
                  <Button>Deploy Pipeline</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
