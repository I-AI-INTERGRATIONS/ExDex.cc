"use client";

import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";

const models = [
  {
    id: "gpt-4",
    name: "GPT-4",
    provider: "OpenAI",
    logo: (
      <svg viewBox="0 0 24 24" className="h-8 w-8" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729zm-9.022 12.6081a4.4755 4.4755 0 0 1-2.8764-1.0408l.1419-.0804 4.7783-2.7582a.7948.7948 0 0 0 .3927-.6813v-6.7369l2.02 1.1686a.071.071 0 0 1 .038.052v5.5826a4.504 4.504 0 0 1-4.4945 4.4944zm-9.6607-4.1254a4.4708 4.4708 0 0 1-.5346-3.0137l.142.0852 4.783 2.7582a.7712.7712 0 0 0 .7806 0l5.8428-3.3685v2.3324a.0804.0804 0 0 1-.0332.0615L9.74 19.9502a4.4992 4.4992 0 0 1-6.1408-1.6464zM2.3408 7.8956a4.485 4.485 0 0 1 2.3655-1.9728V11.6a.7664.7664 0 0 0 .3879.6765l5.8144 3.3543-2.0201 1.1685a.0757.0757 0 0 1-.071 0l-4.8303-2.7865A4.504 4.504 0 0 1 2.3408 7.872zm16.5963 3.8558L13.1038 8.364 15.1192 7.2a.0757.0757 0 0 1 .071 0l4.8303 2.7913a4.4944 4.4944 0 0 1-.6765 8.1042v-5.6772a.79.79 0 0 0-.407-.667zm2.0107-3.0231l-.142-.0852-4.7735-2.7818a.7759.7759 0 0 0-.7854 0L9.409 9.2297V6.8974a.0662.0662 0 0 1 .0284-.0615l4.8303-2.7866a4.4992 4.4992 0 0 1 6.6802 4.66zM8.3065 12.863l-2.02-1.1638a.0804.0804 0 0 1-.038-.0567V6.0742a4.4992 4.4992 0 0 1 7.3757-3.4537l-.142.0805L8.704 5.459a.7948.7948 0 0 0-.3927.6813zm1.0976-2.3654l2.602-1.4998 2.6069 1.4998v2.9994l-2.5974 1.4997-2.6067-1.4997z" fill="currentColor" />
      </svg>
    ),
    strengths: ["Advanced reasoning", "Complex code generation", "Follow instructions accurately", "Excellent documentation", "Can use external APIs"],
    example: `// Creating a responsive navbar with accessibility features
import { useState, useEffect, useRef } from 'react';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const navRef = useRef(null);

  // Handle keyboard navigation and accessibility
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen]);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (navRef.current && !navRef.current.contains(e.target) && isOpen) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  return (
    <nav ref={navRef} className="bg-white shadow-sm">
      {/* Navbar implementation */}
    </nav>
  );
}`
  },
  {
    id: "claude-3",
    name: "Claude 3",
    provider: "Anthropic",
    logo: (
      <svg viewBox="0 0 24 24" className="h-8 w-8" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2.25c-5.376 0-9.75 4.374-9.75 9.75s4.374 9.75 9.75 9.75 9.75-4.374 9.75-9.75S17.376 2.25 12 2.25Zm-5.604 6.75c0-.414.168-.779.5-1.1.32-.332.684-.5 1.091-.5.407 0 .772.168 1.093.5.32.321.488.686.488 1.1 0 .414-.168.775-.488 1.096-.32.32-.686.48-1.093.48-.407 0-.77-.16-1.091-.48-.332-.32-.5-.682-.5-1.096Zm3.173 7.54c-1.22 0-2.202-.38-2.947-1.138-.745-.77-1.118-1.776-1.118-3.019 0-.236.09-.433.27-.591.192-.158.42-.237.686-.237.266 0 .489.079.669.237.18.158.27.355.27.591 0 .718.21 1.292.63 1.724.431.42.994.63 1.69.63.695 0 1.251-.21 1.671-.63.42-.432.63-1.006.63-1.725 0-.236.09-.433.27-.59.192-.159.409-.238.65-.238s.456.08.637.237c.192.158.288.355.288.591 0 1.243-.366 2.249-1.1 3.019-.733.758-1.709 1.138-2.927 1.138h-.269Zm6.035-7.54c0 .414-.168.775-.488 1.095-.32.321-.686.481-1.093.481-.407 0-.77-.16-1.091-.48-.332-.321-.5-.682-.5-1.096 0-.414.168-.779.5-1.1.32-.332.684-.5 1.091-.5.407 0 .772.168 1.093.5.32.321.488.686.488 1.1Z" fill="currentColor"/>
      </svg>
    ),
    strengths: ["Excellent UI design generation", "Creative writing", "Detailed explanations", "Nuanced reasoning", "Safe content generation"],
    example: `// Creating a theme switcher with smooth transitions
import { useState, useEffect } from 'react';

export function ThemeSwitcher() {
  // Use system preference as initial value
  const [theme, setTheme] = useState('system');

  useEffect(() => {
    // Check for system preference
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const savedTheme = localStorage.getItem('theme');

    // Apply saved theme or use system preference
    if (savedTheme) {
      applyTheme(savedTheme);
    } else if (systemPrefersDark) {
      applyTheme('dark');
    } else {
      applyTheme('light');
    }
  }, []);

  const applyTheme = (newTheme) => {
    // Handle 'system' theme
    if (newTheme === 'system') {
      const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      document.documentElement.classList.toggle('dark', systemPrefersDark);
      setTheme('system');
    } else {
      document.documentElement.classList.toggle('dark', newTheme === 'dark');
      setTheme(newTheme);
    }

    // Save preference
    localStorage.setItem('theme', newTheme);
  };

  return (
    <div className="relative inline-flex">
      {/* Theme switcher UI implementation */}
    </div>
  );
}`
  },
  {
    id: "gemini-pro",
    name: "Gemini Pro",
    provider: "Google",
    logo: (
      <svg viewBox="0 0 24 24" className="h-8 w-8" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M22 12c0 5.523-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2s10 4.477 10 10z" fill="currentColor" />
        <path d="M8 15.32h2.18v-6.6H8v6.6zm5.82-6.6v6.59h2V9.73h1.01c.57 0 1.04.46 1.04 1.03v4.56h2v-4.56c0-1.32-.91-2.4-2.13-2.7.46-.34.74-.88.73-1.47.01-1.02-.83-1.86-1.85-1.86H13.8v.66h1.02c.66 0 1.19.54 1.19 1.2 0 .66-.53 1.2-1.19 1.2H13.8v-.02H8v-1.18h2.18v-.66H8V5.3h5.82v3.42z" fill="white" />
      </svg>
    ),
    strengths: ["Technical analysis", "Data visualization", "Integrated with Google services", "Performance optimization", "Comprehensive research"],
    example: `// Creating an optimized data visualization chart
import { useEffect, useRef } from 'react';
import * as d3 from 'd3';

export function PerformanceChart({ data }) {
  const chartRef = useRef(null);

  useEffect(() => {
    if (!data || !chartRef.current) return;

    // Clear previous chart
    d3.select(chartRef.current).selectAll('*').remove();

    // Set up dimensions and margins
    const margin = { top: 20, right: 30, bottom: 40, left: 50 };
    const width = chartRef.current.clientWidth - margin.left - margin.right;
    const height = 400 - margin.top - margin.bottom;

    // Create SVG container
    const svg = d3.select(chartRef.current)
      .append('svg')
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom)
      .append('g')
      .attr('transform', \`translate(\${margin.left},\${margin.top})\`);

    // Add scales
    const x = d3.scaleTime()
      .domain(d3.extent(data, d => new Date(d.date)))
      .range([0, width]);

    const y = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.value) * 1.1])
      .range([height, 0]);

    // Add axes and line generator
    // ...additional chart implementation
  }, [data]);

  return <div ref={chartRef} className="w-full h-[400px]" />;
}`
  },
  {
    id: "llama-3",
    name: "Llama 3",
    provider: "Meta",
    logo: (
      <svg viewBox="0 0 24 24" className="h-8 w-8" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 1.875C6.417 1.875 1.875 6.417 1.875 12S6.417 22.125 12 22.125 22.125 17.583 22.125 12 17.583 1.875 12 1.875zm0 7.5a2.625 2.625 0 100 5.25 2.625 2.625 0 000-5.25zM6.75 12a5.25 5.25 0 1110.5 0 5.25 5.25 0 01-10.5 0z" fill="currentColor" />
      </svg>
    ),
    strengths: ["Open-source friendly", "Performant code", "Efficient memory usage", "Great with React", "Community-driven features"],
    example: `// Creating an efficient memo hook
import { useState, useEffect, useRef, useCallback } from 'react';

export function useMemoizedCallback(callback, dependencies) {
  // Use refs to store the callback
  const callbackRef = useRef(callback);

  // Update the callback ref when dependencies change
  useEffect(() => {
    callbackRef.current = callback;
  }, [callback, ...dependencies]);

  // Return a memoized version of the callback
  return useCallback(
    (...args) => callbackRef.current(...args),
    [callbackRef, ...dependencies]
  );
}

// Usage example
export function DataFetcher({ url, onData }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  // Memoize the fetch function
  const fetchData = useMemoizedCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(url);
      const result = await response.json();
      setData(result);
      if (onData) onData(result);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  }, [url]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, refetch: fetchData };
}`
  },
  {
    id: "mistral",
    name: "Mistral",
    provider: "Mistral AI",
    logo: (
      <svg viewBox="0 0 24 24" className="h-8 w-8" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" fill="currentColor" />
        <path d="M15.5 7.5L12.5 14L13.5 17.5L11 13L9 17L10 12L7.5 14.5L8.5 9L11.5 11L14.5 7L11.5 8.5L15.5 7.5Z" fill="white" />
      </svg>
    ),
    strengths: ["Efficient", "Fast responses", "Lightweight solutions", "Accurate problem-solving", "Scalable architectures"],
    example: `// Creating a lightweight state management hook
import { useState, useCallback } from 'react';

export function createStore(initialState = {}) {
  // Create a Map to store all subscribers
  const subscribers = new Map();
  // Store the current state
  let state = { ...initialState };

  // Function to get current state
  const getState = () => state;

  // Function to update state
  const setState = (newState) => {
    // Update state
    state = typeof newState === 'function'
      ? newState(state)
      : { ...state, ...newState };

    // Notify all subscribers
    subscribers.forEach(callback => callback(state));
  };

  // Subscribe to state changes
  const subscribe = (id, callback) => {
    subscribers.set(id, callback);
    return () => subscribers.delete(id);
  };

  // React hook to use the store
  const useStore = () => {
    const [localState, setLocalState] = useState(state);

    // Subscribe component to store updates
    useState(() => {
      const id = Math.random().toString(36).substring(2);
      const unsubscribe = subscribe(id, setLocalState);
      return unsubscribe;
    }, []);

    const updateState = useCallback(setState, []);

    return [localState, updateState];
  };

  return { getState, setState, subscribe, useStore };
}`
  }
];

export function ModelComparisonSection() {
  const [activeTab, setActiveTab] = useState("gpt-4");
  const activeModel = models.find(model => model.id === activeTab) || models[0];

  return (
    <section id="models" className="py-20 md:py-28 lg:py-36 border-t border-border/40">
      <div className="container px-4 md:px-6">
        <div className="mb-12 space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Compare AI models for your needs</h2>
          <p className="mx-auto max-w-[700px] text-lg text-muted-foreground">
            See how different AI models handle React code generation and choose the one that best fits your project
          </p>
        </div>

        <Tabs defaultValue="gpt-4" className="mx-auto max-w-4xl" onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 mb-8">
            {models.map(model => (
              <TabsTrigger key={model.id} value={model.id} className="flex items-center gap-2">
                <span className="hidden md:inline">{model.name}</span>
                <span className="md:hidden">{model.provider}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {models.map(model => (
            <TabsContent key={model.id} value={model.id}>
              <div className="grid gap-8 md:grid-cols-2">
                <Card className="bg-card/50 backdrop-blur-sm border-border/50">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="text-primary">{model.logo}</div>
                      <div>
                        <h3 className="text-xl font-bold">{model.name}</h3>
                        <p className="text-sm text-muted-foreground">by {model.provider}</p>
                      </div>
                    </div>

                    <h4 className="text-sm font-medium text-muted-foreground mb-2">Key strengths</h4>
                    <ul className="space-y-2">
                      {model.strengths.map((strength, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-primary shrink-0">
                            <path d="M5 12l5 5l10 -10"></path>
                          </svg>
                          <span>{strength}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                <Card className="bg-card/50 backdrop-blur-sm border-border/50">
                  <CardContent className="p-6">
                    <h4 className="text-sm font-medium text-muted-foreground mb-2">Sample code generated</h4>
                    <div className="rounded-md bg-black/90 p-4 text-xs font-mono text-gray-300 overflow-auto max-h-[340px]">
                      <pre>{model.example}</pre>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  );
}
