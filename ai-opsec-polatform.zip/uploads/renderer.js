const { ipcRenderer } = require('electron');
require('monaco-editor');
const { Terminal } = require('xterm');
const os = require('os');
const pty = require('node-pty');
const WelcomeDialog = require('./src/components/WelcomeDialog');
const SpeechManager = require('./src/speech/SpeechManager');

// Initialize Monaco Editor
let editor = monaco.editor.create(document.getElementById('editor'), {
    value: '// Start coding here',
    language: 'javascript',
    theme: 'vs-dark',
    automaticLayout: true
});

// Initialize Terminal
const terminal = new Terminal();
terminal.open(document.getElementById('terminal'));

// Initialize PTY
const shell = os.platform() === 'win32' ? 'powershell.exe' : 'bash';
const ptyProcess = pty.spawn(shell, [], {
    name: 'xterm-color',
    cwd: process.cwd(),
    env: process.env
});

// Terminal <-> PTY binding
terminal.onData(data => ptyProcess.write(data));
ptyProcess.on('data', function(data) {
    terminal.write(data);
});

// Settings Management
const localModelToggle = document.getElementById('localModelToggle');
const censorshipToggle = document.getElementById('censorshipToggle');

// Load initial settings
async function loadSettings() {
    const settings = await ipcRenderer.invoke('get-settings');
    localModelToggle.checked = settings.localModelPersistence;
    censorshipToggle.checked = settings.censorshipEnabled;
}

// Save settings when changed
function updateSettings() {
    const settings = {
        localModelPersistence: localModelToggle.checked,
        censorshipEnabled: censorshipToggle.checked
    };
    ipcRenderer.send('update-settings', settings);
}

localModelToggle.addEventListener('change', updateSettings);
censorshipToggle.addEventListener('change', updateSettings);

// Initialize speech manager
let speechManager;
document.addEventListener('DOMContentLoaded', () => {
    speechManager = new SpeechManager();
    
    // Setup microphone button
    const micButton = document.getElementById('microphone-button');
    const helpPanel = document.querySelector('.voice-commands-help');
    
    micButton.addEventListener('click', () => {
        speechManager.toggleListening();
    });

    // Show/hide help panel on hover
    micButton.addEventListener('mouseenter', () => {
        helpPanel.classList.add('visible');
    });

    micButton.addEventListener('mouseleave', () => {
        helpPanel.classList.remove('visible');
    });

    // Keyboard shortcut for voice commands (Ctrl+Shift+M)
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.shiftKey && e.key === 'M') {
            speechManager.toggleListening();
        }
    });

    // Check if we should show the welcome dialog
    const showWelcomeDialog = localStorage.getItem('showWelcomeDialog') !== 'false';
    if (showWelcomeDialog) {
        const welcomeDialog = new WelcomeDialog();
        welcomeDialog.show();
        
        // Introduce voice commands after a short delay
        setTimeout(() => {
            speechManager.speak(
                'Welcome to your AI-powered IDE. You can activate voice commands by clicking the microphone button or pressing Control Shift M. Try saying "Help with code" to get started.'
            );
        }, 1000);
    }
});

// Initialize
loadSettings();
