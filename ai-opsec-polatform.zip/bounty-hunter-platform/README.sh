#!/bin/bash

# NEXUS/Ready Player One Terminal Effects
BLUE='\033[0;34m'
CYAN='\033[0;36m'
RED='\033[0;31m'
PURPLE='\033[0;35m'
YELLOW='\033[1;33m'
WHITE='\033[1;37m'
BOLD='\033[1m'
BLINK='\033[5m'
RESET='\033[0m'

# Digital data stream animation effect
digital_stream() {
  clear
  chars="01αβγδεζηθλμνξπρστabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%^&*()"
  lines=$(tput lines)
  cols=$(tput cols)

  # Creates array of column positions and speeds
  declare -a positions
  declare -a speeds
  for (( i=0; i<cols; i++ )); do
    positions[$i]=-1
    speeds[$i]=$(( RANDOM % 3 + 1 ))
  done

  for (( t=0; t<30; t++ )); do  # More iterations for longer effect
    for (( i=0; i<cols; i++ )); do
      if (( i % 2 == 0 )); do  # Only use half the columns for better appearance
        pos=${positions[$i]}
        if (( pos > lines )); then
          positions[$i]=-1
        elif (( pos >= 0 )); then
          # Print character with fading intensity
          if (( pos < 5 )); then
            echo -ne "\033[0;34m"  # Bright blue for recent chars
          else
            echo -ne "\033[2;34m"  # Dim blue for old chars
          fi

          # Move cursor to position and print a random character
          tput cup $pos $i
          echo -n "${chars:RANDOM%${#chars}:1}"

          # Move the position down based on speed
          (( positions[$i] += speeds[$i] ))
        fi
      fi
    done

    # Start a new column at random
    if (( RANDOM % 5 == 0 )); then
      positions[$(( RANDOM % cols ))]=-0
    fi

    sleep 0.05
  done
  clear
}

# Typewriter effect for text output
typewriter() {
  local message="$1"
  local delay=${2:-0.03}
  for (( i=0; i<${#message}; i++ )); do
    echo -n "${message:$i:1}"
    sleep $delay
  done
  echo
}

# Hologram text effect
hologram() {
  local message="$1"
  local times=${2:-4}
  local delay=${3:-0.08}

  for (( i=0; i<times; i++ )); do
    clear
    echo -ne "${BLUE}${message}${RESET}"
    sleep $delay
    clear

    # Create glitched version
    local glitched=""
    for (( j=0; j<${#message}; j++ )); do
      if (( RANDOM % 3 == 0 )); then
        glitched+="$(echo "${chars:RANDOM%${#chars}:1}")"
      else
        glitched+="${message:$j:1}"
      fi
    done

    echo -ne "${CYAN}${glitched}${RESET}"
    sleep $delay
  done

  clear
  echo -ne "${BLUE}${message}${RESET}"
  echo
}

# Display ASCII art logo
show_logo() {
  echo -e "${BLUE}"
  cat << "EOF"
 _   _ _______   ___   _ ____
| \ | | ____\ \ / / | | / ___|
|  \| |  _|  \ V /| | | \___ \
| |\  | |___  | || |_| |___) |
|_| \_|_____| |_| \___/|____/

    ╔═══════════════════════════════════════════╗
    ║  THE ULTIMATE VIRTUAL BUG HUNTING ARENA   ║
    ╚═══════════════════════════════════════════╝
EOF
  echo -e "${RESET}"
}

# Show AI-generated security analysis animation
show_ai_analysis() {
  echo -e "${BLUE}"
  echo "╔════════════════════ AI VULNERABILITY ANALYSIS ═════════════════════╗"
  echo "║                                                                    ║"

  local vulns=("SQL Injection - CRITICAL" "XSS Vulnerability - HIGH" "API Key Exposure - CRITICAL"
               "Outdated Dependencies - MEDIUM" "Path Traversal - HIGH" "JWT Token Weakness - MEDIUM"
               "CSRF Vulnerability - LOW" "Prototype Pollution - MEDIUM" "Server Misconfiguration - HIGH")

  for vuln in "${vulns[@]}"; do
    echo -ne "║  [+] Scanning: "
    for ((i=0; i<40; i++)); do
      echo -ne "▓"
      sleep 0.01
    done
    echo -ne " COMPLETE!  ║\n"
    echo -ne "║  [!] Found: ${vuln}"
    printf "%$((45 - ${#vuln}))s ║\n" " "
    sleep 0.3
  done

  echo "║                                                                    ║"
  echo "╚════════════════════════════════════════════════════════════════════╝"
  echo -e "${RESET}"
  sleep 1
}

# Display the welcome message and system information
welcome_message() {
  echo -e "${BLUE}${BOLD}"
  clear
  typewriter "Initializing NEXUS virtual environment..." 0.05
  sleep 0.5
  typewriter "Building secure interface..." 0.03
  sleep 0.5
  typewriter "Connecting to vulnerability databases..." 0.03
  sleep 1
  clear

  # Show the logo with hologram effect
  hologram "$(show_logo)" 3 0.1

  echo -e "${RESET}"
  echo -e "${YELLOW}╔═══════════════════════════════════════════════════════════════════╗${RESET}"
  echo -e "${BOLD} THE FIRST PLATFORM THAT FULLY INTEGRATES AI + SECURITY + DEV TOOLS ${RESET}"
  echo -e "${YELLOW}╚═══════════════════════════════════════════════════════════════════╝${RESET}"
  echo
  typewriter "${WHITE}${BOLD}// WELCOME TO THE NEXUS. READY PLAYER ONE?${RESET}" 0.01
  echo

  # Brief AI analysis demo
  show_ai_analysis

  # Platform features
  echo -e "${PURPLE}${BOLD}⚡ REVOLUTIONARY SECURITY FEATURES:${RESET}"
  echo -e "  ✓ ${CYAN}Advanced AI OpSec Awareness${RESET} - Real-time security scanning"
  echo -e "  ✓ ${CYAN}Vulnerability Assessment Engine${RESET} - Integration with exploit.db & breach dumps"
  echo -e "  ✓ ${CYAN}Bug Bounty Automation${RESET} - Direct integration with bounty platforms"
  echo -e "  ✓ ${CYAN}Closed AI.DB Security Analysis${RESET} - AI audits your code for vulnerabilities"
  echo -e "  ✓ ${CYAN}Real-time CVE Monitoring${RESET} - First-alert system for new vulnerabilities"
  echo
  echo -e "${BLUE}${BOLD}🛠️ DEVELOPER POWERHOUSE:${RESET}"
  echo -e "  ✓ ${CYAN}Complete GitHub Integration${RESET} - Connect repos for immediate security analysis"
  echo -e "  ✓ ${CYAN}Advanced SDK & IDE Support${RESET} - Works with your existing development tools"
  echo -e "  ✓ ${CYAN}Code Clone & Analysis${RESET} - Copy any website with automatic security hardening"
  echo -e "  ✓ ${CYAN}AI-Powered Peer Reviews${RESET} - Get instant feedback on your code quality"
  echo
  echo -e "${CYAN}${BOLD}🚀 FREELANCER PROGRAM:${RESET}"
  echo -e "  ✓ ${CYAN}Freelancer Sponsorship Program${RESET} - Get your projects fully security tested"
  echo -e "  ✓ ${CYAN}Peer Review System${RESET} - Network with top security professionals"
  echo -e "  ✓ ${CYAN}Bounty Hunting Platform${RESET} - Find and report vulnerabilities for rewards"
  echo -e "  ✓ ${CYAN}Client-Developer Matching${RESET} - Connect with projects that need security work"
  echo
  echo -e "${RED}${BOLD}⚠️ ELITE VULNERABILITY DATABASE:${RESET}"
  echo -e "  ✓ ${CYAN}First-Alert Vulnerability System${RESET} - Know about exploits before they go public"
  echo -e "  ✓ ${CYAN}Breach Dump Integration${RESET} - Check if your credentials are compromised"
  echo -e "  ✓ ${CYAN}Exploit.db Connection${RESET} - Direct access to latest security exploits"
  echo -e "  ✓ ${CYAN}Zero-Day Monitoring${RESET} - Be alerted to emerging threats immediately"
  echo
  echo -e "${YELLOW}═════════════════════════════════════════════════════════════════════${RESET}"
}

# Installation and requirement instructions
show_system_info() {
  echo -e "${BOLD}SYSTEM REQUIREMENTS:${RESET}"
  echo -e "• Node.js 18+ or Bun runtime"
  echo -e "• 4GB RAM minimum (8GB recommended)"
  echo -e "• 5GB free disk space for full vulnerability database"
  echo -e "• GitHub API access for repository integration"
  echo -e "• Modern browser with WebAssembly support"

  echo
  echo -e "${YELLOW}═════════════════════════════════════════════════════════════════════${RESET}"

  echo -e "${BOLD}LAUNCH OPTIONS:${RESET}"
  echo -e "1. ${BLUE}Enter the NEXUS${RESET}"
  echo -e "2. ${CYAN}Start Vulnerability Assessment Engine${RESET}"
  echo -e "3. ${PURPLE}Connect GitHub Repository for Scanning${RESET}"
  echo -e "4. ${RED}Apply for Freelancer Security Sponsorship${RESET}"
  echo -e "5. ${YELLOW}Exit${RESET}"
  echo
  echo -e "${YELLOW}═════════════════════════════════════════════════════════════════════${RESET}"
}

# Launch application based on user choice
launch_system() {
  local choice
  read -p "Enter option [1-5]: " choice

  case $choice in
    1)
      echo -e "${BLUE}${BOLD}Entering the NEXUS...${RESET}"
      cd $(dirname $0)
      npm install || bun install
      npm run dev || bun run dev
      ;;
    2)
      echo -e "${CYAN}${BOLD}Starting vulnerability assessment engine...${RESET}"
      # Simulate a vulnerability scan with animation
      echo -e "Scanning system for vulnerabilities..."
      local progress=0
      while [ $progress -le 100 ]; do
        echo -ne "\r[${BLUE}"
        for ((i=0; i<progress/2; i++)); do echo -ne "▓"; done
        for ((i=progress/2; i<50; i++)); do echo -ne " "; done
        echo -ne "${RESET}] $progress%"
        progress=$((progress+2))
        sleep 0.05
      done
      echo -e "\n${BLUE}Scan complete! View results in the NEXUS dashboard.${RESET}"
      sleep 2
      $0
      ;;
    3)
      echo -e "${PURPLE}${BOLD}GitHub repository connector${RESET}"
      read -p "Enter repository URL: " repo_url
      echo -e "Connecting to ${repo_url}..."
      sleep 1
      echo -e "${BLUE}Repository connected! Starting initial security scan...${RESET}"
      sleep 2
      # Show fake scan progress
      for i in {1..10}; do
        echo -e "Analyzing file $i of 10: ${CYAN}package.json${RESET}"
        sleep 0.3
      done
      echo -e "${RED}Warning: 3 potential vulnerabilities found!${RESET}"
      sleep 2
      $0
      ;;
    4)
      echo -e "${RED}${BOLD}Freelancer Security Sponsorship Application${RESET}"
      echo -e "Our sponsorship program provides full security assessments for qualified freelance projects."
      read -p "Enter your email to receive application details: " email
      echo -e "${BLUE}Thank you! Application instructions sent to $email${RESET}"
      sleep 2
      $0
      ;;
    5)
      echo -e "${YELLOW}${BOLD}Exiting NEXUS...${RESET}"
      sleep 1
      clear
      exit 0
      ;;
    *)
      echo -e "${RED}${BOLD}Invalid option. Please try again.${RESET}"
      sleep 1
      clear
      welcome_message
      show_system_info
      launch_system
      ;;
  esac
}

# Main program
digital_stream
welcome_message
show_system_info
launch_system

exit 0
