"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import MatrixCode from "@/components/matrix-code"

export default function ChoicePage() {
  const router = useRouter()

  // Mark that the user has seen the intro
  useEffect(() => {
    try {
      localStorage.setItem('introSeen', 'true')
    } catch (error) {
      console.error("Could not access localStorage:", error)
    }
  }, [])

  const handleChoice = (path: 'blue' | 'red') => {
    try {
      localStorage.setItem('matrixPath', path)
      router.push('/')
    } catch (error) {
      console.error("Could not access localStorage:", error)
    }
  }

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center text-white overflow-hidden relative">
      {/* Background data streams */}
      <div className="absolute inset-0 z-0 opacity-20">
        <MatrixCode density={30} speed={1.0} />
      </div>

      <div className="z-10 text-center">
        <h1 className="text-5xl md:text-7xl font-bold mb-12">
          <span className="gradient-text">Choose Your Avatar</span>
        </h1>

        <p className="text-xl max-w-3xl mx-auto mb-16">
          Welcome to the NEXUS. Choose your avatar to determine your path.
        </p>

        <div className="flex flex-col md:flex-row gap-12 mt-12">
          <div
            onClick={() => handleChoice('red')}
            className="group cursor-pointer"
          >
            <div className="relative">
              <div className="absolute -inset-0.5 bg-primary/30 opacity-75 blur-xl rounded-lg transition-all duration-500 group-hover:opacity-100"></div>
              <div className="relative flex flex-col items-center p-10 bg-black/80 border border-primary/50 rounded-lg transition-all duration-300 group-hover:border-primary">
                <div className="w-32 h-32 rounded-full bg-black border-2 border-primary flex items-center justify-center mb-6">
                  <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <path d="M19 7v A1 1 0 0 0 20 8 1 1 0 0 0 19 7 Z" />
                    <path d="M4 8a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
                    <path d="M11.5 2a9.5 9.5 0 0 1 9.5 9.5v2a3 3 0 0 1 -3 3h-.5a3 3 0 0 1 -3 -3v-1.5a2 2 0 0 1 2 -2h4a2 2 0 0 0 -2 -2h-1.5a.5 .5 0 0 1 -.5 -.5v-.5a2 2 0 0 0 -2 -2h-7a2 2 0 0 0 -2 2v.5a.5 .5 0 0 1 -.5 .5h-1.5a2 2 0 0 0 -2 2h4a2 2 0 0 1 2 2v1.5a3 3 0 0 1 -3 3h-.5a3 3 0 0 1 -3 -3v-2a9.5 9.5 0 0 1 9.5 -9.5z" />
                    <path d="M9.5 15a3.5 3.5 0 0 0 5 0" />
                    <path d="M7 16.5c0 .828 .672 1.5 1.5 1.5h7c.828 0 1.5 -.672 1.5 -1.5" />
                  </svg>
                </div>
                <h2 className="text-3xl font-bold text-primary mb-2">HUNTER</h2>
                <p className="text-muted-foreground max-w-xs text-center">
                  Join the elite vulnerability hunters in the NEXUS. Discover exploits, claim bounties, and climb the leaderboard.
                </p>
                <div className="mt-6">
                  <Button className="vr-button">
                    Select Hunter
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <div
            onClick={() => handleChoice('blue')}
            className="group cursor-pointer"
          >
            <div className="relative">
              <div className="absolute -inset-0.5 bg-blue-500/30 opacity-75 blur-xl rounded-lg transition-all duration-500 group-hover:opacity-100"></div>
              <div className="relative flex flex-col items-center p-10 bg-black/80 border border-blue-500/50 rounded-lg transition-all duration-300 group-hover:border-blue-500">
                <div className="w-32 h-32 rounded-full bg-black border-2 border-blue-500 flex items-center justify-center mb-6">
                  <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-blue-400">
                    <path d="M2 21v-6a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v6"></path>
                    <path d="M12 11v-8l3 3m-6 0l3 -3"></path>
                    <path d="M9 11l0 .01"></path>
                    <path d="M15 11l0 .01"></path>
                    <path d="M9 15l.01 -.01"></path>
                    <path d="M15 15l.01 -.01"></path>
                    <path d="M9 19l.01 -.01"></path>
                    <path d="M15 19l.01 -.01"></path>
                  </svg>
                </div>
                <h2 className="text-3xl font-bold text-blue-400 mb-2">GUARDIAN</h2>
                <p className="text-muted-foreground max-w-xs text-center">
                  Protect your digital assets in the NEXUS. Create security missions, reward successful hunters, and secure your systems.
                </p>
                <div className="mt-6">
                  <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                    Select Guardian
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
