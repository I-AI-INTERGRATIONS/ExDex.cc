"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Navbar from "@/components/navbar"
import HeroSection from "@/components/hero-section"
import FeaturesSection from "@/components/features-section"
import AutomationSection from "@/components/automation-section"
import TokenizationSection from "@/components/tokenization-section"
import BountyMarketplace from "@/components/bounty-marketplace"
import FreelanceSpecialists from "@/components/freelance-specialists"
import PricingSection from "@/components/pricing-section"
import Footer from "@/components/footer"
import MatrixCode from "@/components/matrix-code"

export default function Home() {
  const router = useRouter()
  const [userPath, setUserPath] = useState<'blue' | 'red' | null>(null)
  const [loading, setLoading] = useState(true)
  const [hasSeenIntro, setHasSeenIntro] = useState(false)

  useEffect(() => {
    // Check if user has seen the intro
    const checkIntro = () => {
      try {
        const introSeen = localStorage.getItem('introSeen')

        if (!introSeen) {
          // If they haven't seen the intro, redirect to it
          router.push('/intro')
          return
        }

        setHasSeenIntro(true)
        checkPath()
      } catch (error) {
        // Handle case where localStorage is not available (SSR)
        console.error("Could not access localStorage:", error)
        setLoading(false)
      }
    }

    // Check if user has chosen a path
    const checkPath = () => {
      try {
        const path = localStorage.getItem('matrixPath') as 'blue' | 'red' | null

        // If no choice was made, redirect to the choice page
        if (!path) {
          router.push('/choice')
          return
        }

        setUserPath(path)
        setLoading(false)
      } catch (error) {
        // Handle case where localStorage is not available (SSR)
        console.error("Could not access localStorage:", error)
        setLoading(false)
      }
    }

    // First check if they've seen the intro
    checkIntro()
  }, [router])

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black flex items-center justify-center">
        <div className="text-primary text-3xl font-mono">Loading NEXUS...</div>
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-background relative overflow-hidden">
      <div className="fixed inset-0 z-0 pointer-events-none">
        <MatrixCode density={50} speed={1.2} opacity={0.5} />
      </div>
      <div className="relative z-10">
        <Navbar userPath={userPath} />
        <HeroSection userPath={userPath} />
        <FeaturesSection userPath={userPath} />
        <AutomationSection userPath={userPath} />
        <div id="tokenization">
          <TokenizationSection userPath={userPath} />
        </div>
        <div id="bounties">
          <BountyMarketplace userPath={userPath} />
        </div>
        {userPath === 'red' && (
          <div id="specialists">
            <FreelanceSpecialists />
          </div>
        )}
        <div id="pricing">
          <PricingSection userPath={userPath} />
        </div>
        <Footer userPath={userPath} />
      </div>
    </main>
  )
}
