"use client"

import { useEffect } from 'react'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function About() {
  // Add animation effect on load
  useEffect(() => {
    const paths = document.querySelectorAll('.flow-path');
    const nodes = document.querySelectorAll('.system-node');

    // Animate paths
    paths.forEach((path, index) => {
      setTimeout(() => {
        path.classList.add('active');
      }, index * 100);
    });

    // Animate nodes
    nodes.forEach((node, index) => {
      setTimeout(() => {
        node.classList.add('active');
      }, index * 150 + 500);
    });
  }, []);

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="container mx-auto">
        <div className="flex items-center mb-8">
          <Link href="/">
            <Button variant="outline" className="border-primary/50 text-primary hover:bg-primary/10">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
            </Button>
          </Link>
          <h1 className="text-3xl font-bold gradient-text ml-4">NEXUS_AI.DE System Architecture</h1>
        </div>

        <div className="mb-10">
          <p className="text-lg text-muted-foreground max-w-3xl">
            NEXUS_AI.DE is the first platform that fully integrates AI OpSec awareness,
            bug bounty vulnerability assessments, and secure code scanning with GitHub
            integration and freelancer sponsorship programs.
          </p>
        </div>

        {/* SVG System Architecture Diagram */}
        <div className="relative w-full h-[800px] border border-primary/20 rounded-lg bg-black/50 p-4 mb-12 overflow-hidden">
          <svg className="w-full h-full" viewBox="0 0 1000 800" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* Core System Center Box */}
            <rect
              x="400"
              y="350"
              width="200"
              height="100"
              rx="10"
              className="system-node"
              fill="rgba(138, 43, 226, 0.2)"
              stroke="#8a2be2"
              strokeWidth="2"
            />
            <text x="500" y="395" textAnchor="middle" className="text-base font-bold" fill="#8a2be2">NEXUS_AI.DE</text>
            <text x="500" y="415" textAnchor="middle" className="text-xs" fill="#8a2be2">AI Security Core</text>

            {/* Red Pill Path (Top) */}
            <rect
              x="400"
              y="150"
              width="200"
              height="80"
              rx="10"
              className="system-node"
              fill="rgba(220, 20, 60, 0.1)"
              stroke="#dc143c"
              strokeWidth="2"
            />
            <text x="500" y="190" textAnchor="middle" className="text-base font-bold" fill="#dc143c">RED PILL</text>
            <text x="500" y="210" textAnchor="middle" className="text-xs" fill="#dc143c">Developer Path</text>

            {/* Blue Pill Path (Bottom) */}
            <rect
              x="400"
              y="570"
              width="200"
              height="80"
              rx="10"
              className="system-node"
              fill="rgba(30, 144, 255, 0.1)"
              stroke="#1e90ff"
              strokeWidth="2"
            />
            <text x="500" y="610" textAnchor="middle" className="text-base font-bold" fill="#1e90ff">BLUE PILL</text>
            <text x="500" y="630" textAnchor="middle" className="text-xs" fill="#1e90ff">Client Path</text>

            {/* Paths connecting Red Pill to Core */}
            <path
              d="M500 230 L500 350"
              className="flow-path"
              stroke="#dc143c"
              strokeWidth="2"
              strokeDasharray="5,5"
            />

            {/* Paths connecting Blue Pill to Core */}
            <path
              d="M500 570 L500 450"
              className="flow-path"
              stroke="#1e90ff"
              strokeWidth="2"
              strokeDasharray="5,5"
            />

            {/* Vulnerability Database (Left) */}
            <circle
              cx="200"
              cy="400"
              r="60"
              className="system-node"
              fill="rgba(50, 205, 50, 0.1)"
              stroke="#32cd32"
              strokeWidth="2"
            />
            <text x="200" y="395" textAnchor="middle" className="text-sm font-bold" fill="#32cd32">Vulnerability</text>
            <text x="200" y="415" textAnchor="middle" className="text-sm font-bold" fill="#32cd32">Database</text>

            {/* Path from Vulnerability DB to Core */}
            <path
              d="M260 400 L400 400"
              className="flow-path"
              stroke="#32cd32"
              strokeWidth="2"
            />

            {/* GitHub Integration (Right) */}
            <circle
              cx="800"
              cy="400"
              r="60"
              className="system-node"
              fill="rgba(255, 165, 0, 0.1)"
              stroke="#ffa500"
              strokeWidth="2"
            />
            <text x="800" y="395" textAnchor="middle" className="text-sm font-bold" fill="#ffa500">GitHub</text>
            <text x="800" y="415" textAnchor="middle" className="text-sm font-bold" fill="#ffa500">Integration</text>

            {/* Path from GitHub to Core */}
            <path
              d="M740 400 L600 400"
              className="flow-path"
              stroke="#ffa500"
              strokeWidth="2"
            />

            {/* Exploit.db (Top Left) */}
            <rect
              x="100"
              y="200"
              width="140"
              height="70"
              rx="10"
              className="system-node"
              fill="rgba(255, 0, 0, 0.1)"
              stroke="#ff0000"
              strokeWidth="2"
            />
            <text x="170" y="235" textAnchor="middle" className="text-sm font-bold" fill="#ff0000">Exploit.db</text>
            <text x="170" y="255" textAnchor="middle" className="text-xs" fill="#ff0000">Vulnerability Source</text>

            {/* Path from Exploit.db to Vuln DB */}
            <path
              d="M170 270 L200 340"
              className="flow-path"
              stroke="#ff0000"
              strokeWidth="2"
              strokeDasharray="5,5"
            />

            {/* Breach Dumps (Bottom Left) */}
            <rect
              x="100"
              y="530"
              width="140"
              height="70"
              rx="10"
              className="system-node"
              fill="rgba(255, 69, 0, 0.1)"
              stroke="#ff4500"
              strokeWidth="2"
            />
            <text x="170" y="565" textAnchor="middle" className="text-sm font-bold" fill="#ff4500">Breach Dumps</text>
            <text x="170" y="585" textAnchor="middle" className="text-xs" fill="#ff4500">Credential Monitoring</text>

            {/* Path from Breach Dumps to Vuln DB */}
            <path
              d="M170 530 L200 460"
              className="flow-path"
              stroke="#ff4500"
              strokeWidth="2"
              strokeDasharray="5,5"
            />

            {/* Developer Tools (Top Right) */}
            <rect
              x="760"
              y="200"
              width="140"
              height="70"
              rx="10"
              className="system-node"
              fill="rgba(75, 0, 130, 0.1)"
              stroke="#4b0082"
              strokeWidth="2"
            />
            <text x="830" y="235" textAnchor="middle" className="text-sm font-bold" fill="#4b0082">Developer Tools</text>
            <text x="830" y="255" textAnchor="middle" className="text-xs" fill="#4b0082">Code Analysis</text>

            {/* Path from Dev Tools to GitHub */}
            <path
              d="M830 270 L800 340"
              className="flow-path"
              stroke="#4b0082"
              strokeWidth="2"
              strokeDasharray="5,5"
            />

            {/* Client Services (Bottom Right) */}
            <rect
              x="760"
              y="530"
              width="140"
              height="70"
              rx="10"
              className="system-node"
              fill="rgba(0, 191, 255, 0.1)"
              stroke="#00bfff"
              strokeWidth="2"
            />
            <text x="830" y="565" textAnchor="middle" className="text-sm font-bold" fill="#00bfff">Client Services</text>
            <text x="830" y="585" textAnchor="middle" className="text-xs" fill="#00bfff">Security Testing</text>

            {/* Path from Client Services to GitHub */}
            <path
              d="M830 530 L800 460"
              className="flow-path"
              stroke="#00bfff"
              strokeWidth="2"
              strokeDasharray="5,5"
            />

            {/* Freelancer Program (Center Top) */}
            <polygon
              points="500,50 550,100 500,150 450,100"
              className="system-node"
              fill="rgba(138, 43, 226, 0.1)"
              stroke="#8a2be2"
              strokeWidth="2"
            />
            <text x="500" y="105" textAnchor="middle" className="text-xs font-bold" fill="#8a2be2">Freelancer</text>
            <text x="500" y="120" textAnchor="middle" className="text-xs font-bold" fill="#8a2be2">Program</text>

            {/* Path from Freelancer to Red Pill */}
            <path
              d="M500 150 L500 150"
              className="flow-path"
              stroke="#8a2be2"
              strokeWidth="2"
            />

            {/* Tokenization Protocol (Center Bottom) */}
            <polygon
              points="500,650 550,700 500,750 450,700"
              className="system-node"
              fill="rgba(255, 215, 0, 0.1)"
              stroke="#ffd700"
              strokeWidth="2"
            />
            <text x="500" y="690" textAnchor="middle" className="text-xs font-bold" fill="#ffd700">Tokenization</text>
            <text x="500" y="705" textAnchor="middle" className="text-xs font-bold" fill="#ffd700">Protocol</text>

            {/* Path from Tokenization to Blue Pill */}
            <path
              d="M500 650 L500 650"
              className="flow-path"
              stroke="#ffd700"
              strokeWidth="2"
            />

            {/* Data Flow Arrows */}
            <defs>
              <marker
                id="arrowhead"
                markerWidth="10"
                markerHeight="7"
                refX="9"
                refY="3.5"
                orient="auto"
              >
                <polygon points="0 0, 10 3.5, 0 7" fill="#8a2be2" />
              </marker>
            </defs>

            {/* Circular Data Flow */}
            <path
              d="M400 380 C 350 350, 350 450, 400 420"
              className="flow-path"
              stroke="#8a2be2"
              strokeWidth="2"
              markerEnd="url(#arrowhead)"
              fillOpacity="0"
            />

            <path
              d="M600 380 C 650 350, 650 450, 600 420"
              className="flow-path"
              stroke="#8a2be2"
              strokeWidth="2"
              markerEnd="url(#arrowhead)"
              fillOpacity="0"
            />

            {/* Key Performance Metrics */}
            <g className="system-node">
              <rect x="50" y="650" width="250" height="130" rx="5" fill="rgba(0,0,0,0.5)" stroke="#32cd32" strokeWidth="1" />
              <text x="175" y="670" textAnchor="middle" className="text-sm font-bold" fill="#32cd32">PERFORMANCE METRICS</text>
              <text x="60" y="695" className="text-xs" fill="#ffffff">• Vulnerability Detection: 85% (vs 73% avg)</text>
              <text x="60" y="715" className="text-xs" fill="#ffffff">• False Positive Rate: 3% (vs 18% avg)</text>
              <text x="60" y="735" className="text-xs" fill="#ffffff">• Auto-Remediation: 76% (vs 40% avg)</text>
              <text x="60" y="755" className="text-xs" fill="#ffffff">• Platform Fee: 2% (vs 15-30% avg)</text>
            </g>

            <g className="system-node">
              <rect x="700" y="650" width="250" height="130" rx="5" fill="rgba(0,0,0,0.5)" stroke="#ffa500" strokeWidth="1" />
              <text x="825" y="670" textAnchor="middle" className="text-sm font-bold" fill="#ffa500">INTEGRATION CAPABILITIES</text>
              <text x="710" y="695" className="text-xs" fill="#ffffff">• GitHub Repository: 97% compatibility</text>
              <text x="710" y="715" className="text-xs" fill="#ffffff">• IDE Support: VSCode, JetBrains, Eclipse</text>
              <text x="710" y="735" className="text-xs" fill="#ffffff">• CI/CD Pipeline: GitHub Actions, Jenkins</text>
              <text x="710" y="755" className="text-xs" fill="#ffffff">• SDK Integration: Node.js, Python, Java, Go</text>
            </g>
          </svg>
        </div>

        {/* System Component Descriptions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <div className="border border-primary/20 rounded-lg bg-black/30 p-6">
            <h3 className="text-xl font-bold mb-4 text-primary">RED PILL PATH (Developers)</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-primary mr-2">→</span>
                <span>Access to vulnerability databases and exploit repositories</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">→</span>
                <span>Bug bounty hunting tools and automation scripts</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">→</span>
                <span>GitHub repository scanning for security issues</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">→</span>
                <span>Freelancer sponsorship program for security testing</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">→</span>
                <span>AI-powered code review and remediation suggestions</span>
              </li>
            </ul>
          </div>

          <div className="border border-blue-500/20 rounded-lg bg-black/30 p-6">
            <h3 className="text-xl font-bold mb-4 text-blue-400">BLUE PILL PATH (Clients)</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-blue-400 mr-2">→</span>
                <span>Security testing services for applications</span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-400 mr-2">→</span>
                <span>Vulnerability assessment and reporting</span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-400 mr-2">→</span>
                <span>Secure tokenization for sensitive data</span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-400 mr-2">→</span>
                <span>Post security jobs with 2% platform fee</span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-400 mr-2">→</span>
                <span>Real-time threat monitoring and alerts</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Core System Features */}
        <div className="border border-primary/20 rounded-lg bg-black/30 p-6 mb-12">
          <h3 className="text-xl font-bold mb-4 gradient-text">NEXUS_AI.DE CORE SYSTEM</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h4 className="font-bold text-primary mb-2">Security Engine</h4>
              <p className="text-sm text-muted-foreground">
                The AI-powered security engine connects to multiple vulnerability
                databases and analyzes code patterns to identify security risks and
                propose remediations with 76% auto-fix capability.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-primary mb-2">Integration Hub</h4>
              <p className="text-sm text-muted-foreground">
                Central connector for GitHub repositories, IDE plugins, and CI/CD
                pipelines. Scans code directly from repositories and integrates
                with existing development workflows.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-primary mb-2">Data Protection</h4>
              <p className="text-sm text-muted-foreground">
                The tokenization protocol ensures secure handling of sensitive data,
                API keys, and authentication tokens across all connected systems with
                industry-leading encryption standards.
              </p>
            </div>
          </div>
        </div>

        <div className="text-center">
          <Link href="/">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              Back to Dashboard
            </Button>
          </Link>
        </div>
      </div>

      {/* Styles for animations */}
      <style jsx>{`
        .flow-path {
          opacity: 0;
          stroke-dasharray: 1000;
          stroke-dashoffset: 1000;
          transition: all 2s ease;
        }

        .flow-path.active {
          opacity: 1;
          stroke-dashoffset: 0;
        }

        .system-node {
          opacity: 0;
          transform: scale(0.8);
          transition: all 0.5s ease;
        }

        .system-node.active {
          opacity: 1;
          transform: scale(1);
        }
      `}</style>
    </div>
  )
}
