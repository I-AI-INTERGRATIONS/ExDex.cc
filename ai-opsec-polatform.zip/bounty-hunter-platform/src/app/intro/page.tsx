"use client"

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'

// Define the scene types
type SceneType = 'ready' | 'race-intro' | 'choice' | 'lose-race' | 'win-race' | 'architect' | 'final'

export default function IntroPage() {
  const router = useRouter()
  const [scene, setScene] = useState<SceneType>('ready')
  const [typedText, setTypedText] = useState('')
  const [showButtons, setShowButtons] = useState(false)
  const [raceProgress, setRaceProgress] = useState(0)
  const [countdown, setCountdown] = useState(3)
  const [userChoice, setUserChoice] = useState<string | null>(null)

  // Text typing effect
  useEffect(() => {
    let textToType = ''
    let typingSpeed = 30

    switch(scene) {
      case 'ready':
        textToType = "ARE YOU READY, PLAYER?"
        typingSpeed = 80
        break
      case 'race-intro':
        textToType = "The NEXUS race is about to begin. You're at the starting line, sitting in your virtual supercar. Competitors surround you. The crowd roars in anticipation. This race is legendary - only the most skilled hunters have conquered it."
        break
      case 'choice':
        textToType = "The race has started. You're approaching the first major obstacle - a massive gap in the track. Beyond it, you see a shortcut that could give you the lead."
        break
      case 'lose-race':
        textToType = "You took the safe path and followed the track as designed. While you navigate carefully, other racers zoom past taking risks. You finish the race in 5th place. Not bad, but not enough to unlock the highest security clearance."
        break
      case 'win-race':
        textToType = "You launch forward, pushing your virtual car to its limits! The jump is risky, but you make it across the gap, landing on the hidden shortcut. You surge ahead of the competition, crossing the finish line in 1st place!"
        break
      case 'architect':
        textToType = "As you exit your vehicle, a figure appears before you - The Architect, creator of the NEXUS security protocols. \"Congratulations, hunter. You've proven your willingness to take risks - a valuable trait in vulnerability discovery. Now, I have two questions to determine your path in the NEXUS.\""
        break
      case 'final':
        textToType = "\"First question: Do you seek to HUNT vulnerabilities or SECURE systems? Second question: Do you prefer to work SOLO or as part of a TEAM?\""
        break
    }

    let i = 0
    setTypedText('')

    const typingInterval = setInterval(() => {
      if (i < textToType.length) {
        setTypedText(prev => prev + textToType.charAt(i))
        i++
      } else {
        clearInterval(typingInterval)

        // Show buttons after text is done typing
        if (['ready', 'choice', 'architect', 'final'].includes(scene)) {
          setTimeout(() => setShowButtons(true), 500)
        }

        // Start countdown for race
        if (scene === 'race-intro') {
          setTimeout(() => {
            const countdownInterval = setInterval(() => {
              setCountdown(prev => {
                if (prev <= 1) {
                  clearInterval(countdownInterval)
                  setScene('choice')
                  return 0
                }
                return prev - 1
              })
            }, 1000)
          }, 1000)
        }

        // Animate race progress
        if (['lose-race', 'win-race'].includes(scene)) {
          const interval = setInterval(() => {
            setRaceProgress(prev => {
              if (prev >= 100) {
                clearInterval(interval)
                setTimeout(() => {
                  if (scene === 'win-race') setScene('architect')
                  else setScene('final')
                }, 1000)
                return 100
              }
              return prev + 1
            })
          }, 30)
        }
      }
    }, typingSpeed)

    return () => clearInterval(typingInterval)
  }, [scene])

  // Handle user choices
  const handleChoice = (choice: string) => {
    setShowButtons(false)

    switch(scene) {
      case 'ready':
        if (choice === 'yes') {
          setScene('race-intro')
        } else {
          // If they're not ready, we'll send them to the choice page anyway
          router.push('/choice')
        }
        break
      case 'choice':
        setUserChoice(choice)
        if (choice === 'forward') {
          setScene('win-race')
        } else {
          setScene('lose-race')
        }
        break
      case 'architect':
        setScene('final')
        break
      case 'final':
        // Store user choices
        const [huntOrSecure, soloOrTeam] = choice.split('-')
        localStorage.setItem('userRole', huntOrSecure)
        localStorage.setItem('userPreference', soloOrTeam)

        // Determine path based on choices
        const path = huntOrSecure === 'hunt' ? 'red' : 'blue'
        localStorage.setItem('matrixPath', path)

        // Redirect to main app
        router.push('/')
        break
    }
  }

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center text-white overflow-hidden relative">
      {/* Background data streams */}
      <div className="absolute inset-0 z-0 opacity-20 data-stream"></div>

      {/* Ready scene */}
      {scene === 'ready' && (
        <div className="z-10 text-center">
          <h1 className="text-5xl md:text-7xl font-bold mb-12 gradient-text">{typedText}</h1>

          {showButtons && (
            <div className="space-x-6 mt-8">
              <Button onClick={() => handleChoice('yes')} className="vr-button text-2xl py-6 px-12">
                Y
              </Button>
              <Button onClick={() => handleChoice('no')} variant="outline" className="border-primary/40 text-primary text-2xl py-6 px-12">
                N
              </Button>
            </div>
          )}
        </div>
      )}

      {/* Race intro scene */}
      {scene === 'race-intro' && (
        <div className="z-10 text-center max-w-4xl mx-auto">
          <p className="text-xl mb-12">{typedText}</p>

          {typedText.length === "The NEXUS race is about to begin. You're at the starting line, sitting in your virtual supercar. Competitors surround you. The crowd roars in anticipation. This race is legendary - only the most skilled hunters have conquered it.".length && (
            <div className="text-6xl font-bold gradient-text animate-pulse">
              {countdown}
            </div>
          )}

          <div className="w-full mt-8 h-64 vr-panel border-primary p-4 flex items-center justify-center relative overflow-hidden">
            <div className="w-24 h-12 bg-primary/80 rounded-md absolute bottom-8 left-1/2 transform -translate-x-1/2 shadow-lg shadow-primary/30"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-full h-2 bg-primary/20 relative">
                <div className="absolute top-0 left-0 bottom-0 w-0 bg-primary transition-all duration-1000"></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Choice scene */}
      {scene === 'choice' && (
        <div className="z-10 text-center max-w-4xl mx-auto">
          <p className="text-xl mb-12">{typedText}</p>

          {showButtons && (
            <div className="space-x-12 mt-8">
              <Button onClick={() => handleChoice('forward')} className="vr-button text-xl py-4 px-8">
                FORWARD - Take the jump
              </Button>
              <Button onClick={() => handleChoice('backward')} variant="outline" className="border-primary/40 text-primary text-xl py-4 px-8">
                BACKWARD - Find another way
              </Button>
            </div>
          )}

          <div className="w-full mt-12 h-64 vr-panel border-primary p-4 flex items-center justify-center relative overflow-hidden">
            <div className="w-24 h-12 bg-primary/80 rounded-md absolute bottom-8 left-1/3 transform -translate-x-1/2 shadow-lg shadow-primary/30"></div>
            <div className="absolute top-1/4 left-2/3 right-8 h-2 bg-gradient-to-r from-primary to-transparent"></div>
            <div className="absolute top-1/3 left-1/3 w-1/3 h-16 border-2 border-dashed border-red-500/70 flex items-center justify-center">
              <span className="text-red-400 font-bold">DANGER GAP</span>
            </div>
          </div>
        </div>
      )}

      {/* Lose race scene */}
      {scene === 'lose-race' && (
        <div className="z-10 text-center max-w-4xl mx-auto">
          <p className="text-xl mb-12">{typedText}</p>

          <div className="w-full mt-8">
            <div className="w-full bg-gray-700 rounded-full h-4">
              <div
                className="bg-primary h-4 rounded-full transition-all duration-1000"
                style={{ width: `${raceProgress}%` }}
              ></div>
            </div>
            <div className="flex justify-between mt-2">
              <span>Start</span>
              <span>Finish - 5th Place</span>
            </div>
          </div>

          <div className="w-full mt-8 h-64 vr-panel border-primary p-4 flex items-center justify-center relative overflow-hidden">
            <div className="w-24 h-12 bg-gray-500/80 rounded-md absolute bottom-8 left-3/4 transform -translate-x-1/2 shadow-lg shadow-gray-500/30"></div>
            <div className="absolute inset-0 flex items-end justify-end pr-12 pb-24">
              <div className="text-4xl text-gray-400 font-bold">5th</div>
            </div>
          </div>
        </div>
      )}

      {/* Win race scene */}
      {scene === 'win-race' && (
        <div className="z-10 text-center max-w-4xl mx-auto">
          <p className="text-xl mb-12">{typedText}</p>

          <div className="w-full mt-8">
            <div className="w-full bg-gray-700 rounded-full h-4">
              <div
                className="bg-primary h-4 rounded-full transition-all duration-1000"
                style={{ width: `${raceProgress}%` }}
              ></div>
            </div>
            <div className="flex justify-between mt-2">
              <span>Start</span>
              <span>Finish - 1st Place!</span>
            </div>
          </div>

          <div className="w-full mt-8 h-64 vr-panel border-primary p-4 flex items-center justify-center relative overflow-hidden">
            <div className="w-24 h-12 bg-primary/80 rounded-md absolute bottom-8 left-3/4 transform -translate-x-1/2 shadow-lg shadow-primary/30 animate-pulse"></div>
            <div className="absolute inset-0 flex items-end justify-end pr-12 pb-24">
              <div className="text-4xl text-primary font-bold animate-bounce">1st</div>
            </div>
          </div>
        </div>
      )}

      {/* Architect scene */}
      {scene === 'architect' && (
        <div className="z-10 text-center max-w-4xl mx-auto">
          <p className="text-xl mb-12">{typedText}</p>

          {showButtons && (
            <div className="mt-8">
              <Button onClick={() => handleChoice('continue')} className="vr-button text-xl py-4 px-8">
                Continue to questions
              </Button>
            </div>
          )}

          <div className="w-full mt-8 h-64 vr-panel border-primary/70 p-4 flex items-center justify-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/10 to-transparent animate-pulse"></div>
            <div className="rounded-full w-32 h-32 border-2 border-primary/70 overflow-hidden flex items-center justify-center">
              <div className="text-6xl">👤</div>
            </div>
            <div className="absolute bottom-4 w-full text-center text-primary/90 font-mono">
              THE ARCHITECT
            </div>
          </div>
        </div>
      )}

      {/* Final questions scene */}
      {scene === 'final' && (
        <div className="z-10 text-center max-w-4xl mx-auto">
          <p className="text-xl mb-12">{typedText}</p>

          {showButtons && (
            <div className="space-y-6 mt-8">
              <h3 className="vr-heading text-xl">Choose your path:</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Button
                  onClick={() => handleChoice('hunt-solo')}
                  className="vr-button h-auto py-6"
                >
                  <div className="text-left">
                    <div className="font-bold text-lg">Hunt Vulnerabilities - Solo</div>
                    <div className="text-sm text-primary/70">Lone wolf security researcher seeking bounties</div>
                  </div>
                </Button>

                <Button
                  onClick={() => handleChoice('hunt-team')}
                  className="vr-button h-auto py-6"
                >
                  <div className="text-left">
                    <div className="font-bold text-lg">Hunt Vulnerabilities - Team</div>
                    <div className="text-sm text-primary/70">Join forces with other hunters</div>
                  </div>
                </Button>

                <Button
                  onClick={() => handleChoice('secure-solo')}
                  className="vr-button h-auto py-6"
                >
                  <div className="text-left">
                    <div className="font-bold text-lg">Secure Systems - Solo</div>
                    <div className="text-sm text-primary/70">Individual seeking to protect assets</div>
                  </div>
                </Button>

                <Button
                  onClick={() => handleChoice('secure-team')}
                  className="vr-button h-auto py-6"
                >
                  <div className="text-left">
                    <div className="font-bold text-lg">Secure Systems - Team</div>
                    <div className="text-sm text-primary/70">Organization with security needs</div>
                  </div>
                </Button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Skip button for testing */}
      <div className="absolute bottom-4 right-4 z-20">
        <Button
          variant="ghost"
          size="sm"
          className="text-xs opacity-50 hover:opacity-100"
          onClick={() => router.push('/choice')}
        >
          Skip Intro
        </Button>
      </div>
    </div>
  )
}
