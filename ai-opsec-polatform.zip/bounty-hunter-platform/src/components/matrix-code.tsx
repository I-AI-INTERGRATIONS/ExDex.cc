"use client"

import { useEffect, useRef } from "react"

interface MatrixCodeProps {
  density?: number
  speed?: number
  opacity?: number
}

export default function MatrixCode({
  density = 25,
  speed = 1.5,
  opacity = 0.8
}: MatrixCodeProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    // Set canvas size to match parent
    const resizeCanvas = () => {
      const parent = canvas.parentElement
      if (parent) {
        canvas.width = parent.offsetWidth
        canvas.height = parent.offsetHeight
      }
    }

    resizeCanvas()
    window.addEventListener('resize', resizeCanvas)

    // Matrix code characters (using binary and some special chars)
    const chars = "01αβγδεζηθ10λμνξπρστ"

    // Calculate columns
    const fontSize = 14
    const columns = Math.floor(canvas.width / fontSize) * (density / 100)

    // Array to track y position of each column
    const drops: number[] = []

    // Initialize all columns
    for (let i = 0; i < columns; i++) {
      drops[i] = Math.random() * -100
    }

    // Drawing function
    const draw = () => {
      // Add semi-transparent black background to create fade effect
      ctx.fillStyle = `rgba(0, 0, 0, ${0.05 * speed})`
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Set text color and font
      ctx.fillStyle = `rgba(0, 255, 0, ${opacity})`
      ctx.font = `${fontSize}px monospace`

      // Draw characters
      for (let i = 0; i < drops.length; i++) {
        // Random character
        const char = chars[Math.floor(Math.random() * chars.length)]

        // x coordinate = column * font size
        const x = i * fontSize * (100 / density)

        // y coordinate = current drop position
        const y = drops[i] * fontSize

        // Draw the character
        ctx.fillText(char, x, y)

        // Increment y coordinate
        drops[i] += speed * 0.2

        // Reset drop when it's off screen with some randomness
        if (drops[i] * fontSize > canvas.height && Math.random() > 0.98) {
          drops[i] = -1
        }
      }
    }

    // Animation loop
    const interval = setInterval(draw, 33) // ~30 fps

    return () => {
      window.removeEventListener('resize', resizeCanvas)
      clearInterval(interval)
    }
  }, [density, speed, opacity])

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full z-0 opacity-40"
    />
  )
}
