"use client"

import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"
import { Terminal } from "lucide-react"

export default function Footer() {
  return (
    <footer className="border-t border-primary/30 bg-black/80 py-12 backdrop-blur-md relative overflow-hidden">
      <div className="container relative z-10">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div className="flex flex-col">
            <Link href="/" className="inline-block">
              <div className="flex items-center space-x-2">
                <Terminal className="h-6 w-6 text-primary" />
                <span className="text-2xl font-bold gradient-text">Matrix</span>
              </div>
            </Link>
            <p className="mt-4 text-sm text-muted-foreground">
              <span className="font-mono text-primary">&gt; </span>The digital frontier of bug bounty hunting. Choose the red pill to see how deep the rabbit hole goes.
            </p>
            <div className="mt-4 flex items-center space-x-4">
              <Link
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                </svg>
                <span className="sr-only">Twitter</span>
              </Link>
              <Link
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"></path>
                  <path d="M9 18c-4.51 2-5-2-7-2"></path>
                </svg>
                <span className="sr-only">GitHub</span>
              </Link>
              <Link
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                  <rect width="4" height="12" x="2" y="9"></rect>
                  <circle cx="4" cy="4" r="2"></circle>
                </svg>
                <span className="sr-only">LinkedIn</span>
              </Link>
              <ThemeToggle />
            </div>
          </div>
          <div>
            <h3 className="text-sm font-medium text-foreground font-mono">System Access</h3>
            <nav className="mt-4 flex flex-col space-y-2">
              <Link href="#features" className="text-sm text-muted-foreground hover:text-primary">
                <span className="font-mono text-primary">01</span> Modules
              </Link>
              <Link href="#cloud-native" className="text-sm text-muted-foreground hover:text-primary">
                <span className="font-mono text-primary">10</span> System
              </Link>
              <Link href="#bounties" className="text-sm text-muted-foreground hover:text-primary">
                <span className="font-mono text-primary">11</span> Missions
              </Link>
              <Link href="#pricing" className="text-sm text-muted-foreground hover:text-primary">
                <span className="font-mono text-primary">00</span> Credits
              </Link>
            </nav>
          </div>
          <div>
            <h3 className="text-sm font-medium text-foreground font-mono">Training Programs</h3>
            <nav className="mt-4 flex flex-col space-y-2">
              <Link href="#" className="text-sm text-muted-foreground hover:text-primary">
                <span className="font-mono text-primary">&gt;</span> Operator Manual
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-primary">
                <span className="font-mono text-primary">&gt;</span> Combat Training
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-primary">
                <span className="font-mono text-primary">&gt;</span> Archives
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-primary">
                <span className="font-mono text-primary">&gt;</span> Neural Interface
              </Link>
            </nav>
          </div>
          <div>
            <h3 className="text-sm font-medium text-foreground font-mono">The Real World</h3>
            <nav className="mt-4 flex flex-col space-y-2">
              <Link href="#" className="text-sm text-muted-foreground hover:text-primary">
                <span className="font-mono text-primary">//</span> About Zion
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-primary">
                <span className="font-mono text-primary">//</span> Recruitment
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-primary">
                <span className="font-mono text-primary">//</span> Security Protocol
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-primary">
                <span className="font-mono text-primary">//</span> Terms of Freedom
              </Link>
            </nav>
          </div>
        </div>
        <div className="mt-12 border-t border-primary/30 pt-8 text-center text-sm text-muted-foreground">
          <p className="font-mono">/* Remember, all I'm offering is the truth. Nothing more. */</p>
          <p className="mt-2">© {new Date().getFullYear()} The Matrix Bug Bounty. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
