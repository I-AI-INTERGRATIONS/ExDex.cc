"use client"

import { Button } from "@/components/ui/button"
import { Check, AlertTriangle, Terminal, Database, GitBranch, BrainCircuit, Shield, Lock } from "lucide-react"
import MatrixCode from "@/components/matrix-code"

export default function FreelanceSpecialists() {
  const specializations = [
    {
      title: "Advanced OpSec Specialist",
      icon: <Shield className="h-6 w-6 text-primary" />,
      description: "Elite operational security measures for high-risk systems and networks",
      skills: [
        "Endpoint threat detection and response",
        "Zero-trust architecture implementation",
        "Dark web monitoring and preemptive defense"
      ],
      projects: 42,
      rating: 4.9
    },
    {
      title: "AI Penetration Tester",
      icon: <BrainCircuit className="h-6 w-6 text-primary" />,
      description: "Specialized in exploiting vulnerabilities in machine learning systems and AI infrastructures",
      skills: [
        "Model extraction attacks",
        "Adversarial machine learning",
        "Prompt injection vulnerabilities"
      ],
      projects: 27,
      rating: 4.8
    },
    {
      title: "GitHub Security Auditor",
      icon: <GitBranch className="h-6 w-6 text-primary" />,
      description: "Deep analysis of repositories for sensitive data exposure and security flaws",
      skills: [
        "Secret scanning and credential leakage",
        "Supply chain compromise detection",
        "Code signing verification"
      ],
      projects: 63,
      rating: 4.7
    },
    {
      title: "Database Infiltration Expert",
      icon: <Database className="h-6 w-6 text-primary" />,
      description: "Specialized in identifying and exploiting database vulnerabilities",
      skills: [
        "NoSQL injection techniques",
        "Database privilege escalation",
        "Data exfiltration prevention"
      ],
      projects: 36,
      rating: 4.6
    }
  ]

  return (
    <section className="py-16 relative overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-10">
        <MatrixCode density={20} speed={0.8} />
      </div>
      <div className="container relative z-10">
        <div className="mb-12">
          <div className="inline-block mb-2 px-3 py-1 border border-primary/30 rounded-full bg-black/40 text-xs font-mono text-primary">
            RED PILL ACCESS ONLY
          </div>
          <h2 className="text-3xl md:text-4xl font-bold">
            <span className="gradient-text">Specialized</span> Operatives
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-3xl">
            Not all operators are created equal, Neo. Some have specialized in the deepest aspects of the Matrix.
            These elite specialists can be contracted for the most challenging missions.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {specializations.map((spec, index) => (
            <div
              key={index}
              className="border border-primary/30 bg-black/70 backdrop-blur-sm rounded-lg overflow-hidden hover:border-primary/70 transition-all p-6"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  {spec.icon}
                </div>
                <div>
                  <h3 className="text-xl font-semibold font-mono">{spec.title}</h3>
                  <p className="text-muted-foreground text-sm mt-2">{spec.description}</p>

                  <div className="mt-4">
                    <h4 className="text-xs uppercase tracking-wider text-primary/70 font-mono mb-2">Specialist Skills</h4>
                    <ul className="space-y-1">
                      {spec.skills.map((skill, i) => (
                        <li key={i} className="text-sm flex items-start">
                          <Check className="mr-2 h-3 w-3 text-primary mt-1" />
                          <span>{skill}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex justify-between items-center mt-6 border-t border-primary/20 pt-4">
                    <div className="flex items-center gap-4">
                      <div className="text-sm">
                        <span className="text-muted-foreground">Projects: </span>
                        <span className="font-mono text-primary">{spec.projects}</span>
                      </div>
                      <div className="text-sm">
                        <span className="text-muted-foreground">Rating: </span>
                        <span className="font-mono text-primary">{spec.rating}/5</span>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="border-primary/50 text-primary hover:bg-primary/20">
                      Contact
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 border border-primary/30 bg-black/70 backdrop-blur-sm p-6 rounded-lg">
          <div className="flex gap-4 items-start">
            <div className="w-10 h-10 rounded-full bg-red-900/30 flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="h-5 w-5 text-red-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2 text-red-400 font-mono">ACCESS RESTRICTION NOTICE</h3>
              <p className="text-muted-foreground mb-4">
                The following services require additional clearance and verification. All specialized operatives have access to our complete CVE database and zero-day vulnerability repositories. These resources are only available to validated red pill operatives.
              </p>

              <div className="bg-black/50 border border-primary/20 p-4 rounded-md font-mono text-sm">
                <div className="flex items-center mb-2">
                  <Terminal className="h-4 w-4 mr-2 text-primary" />
                  <span className="text-primary">root@zion:~# </span>
                  <span className="text-muted-foreground ml-2">access --vault vulnerability_library --clearance=red_pill</span>
                </div>
                <div className="text-muted-foreground">
                  $ Accessing Zion central repository...
                  <br />
                  $ Verifying red pill credentials...
                  <br />
                  $ Access granted. Decrypting vulnerability database...
                  <br />
                  $ <span className="text-primary">21,458</span> vulnerabilities available including <span className="text-primary">342</span> zero-day exploits.
                </div>
              </div>

              <div className="flex justify-end mt-4">
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                  <Lock className="mr-2 h-4 w-4" />
                  Request Vault Access
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
