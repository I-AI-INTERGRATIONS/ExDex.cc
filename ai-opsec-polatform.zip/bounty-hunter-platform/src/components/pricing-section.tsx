"use client"

import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"
import MatrixCode from "@/components/matrix-code"

interface PricingSectionProps {
  userPath?: 'blue' | 'red' | null
}

export default function PricingSection({ userPath = 'red' }: PricingSectionProps) {
  const isClient = userPath === 'blue';

  const plans = [
    {
      name: isClient ? "Basic" : "Blue Pill",
      description: isClient ? "For small businesses and startups" : "For those who wish to remain blind",
      price: 0,
      features: [
        "Basic system scanning capabilities",
        "Limited to 100 targets",
        "Access to resistance code templates",
        "Manual resource allocation",
        "Access to Zion mission network"
      ],
      cta: isClient ? "Get Started" : "Stay Ignorant",
      popular: false,
      color: "blue"
    },
    {
      name: isClient ? "Professional" : "Red Pill",
      description: isClient ? "For growing organizations" : "For those who seek the truth",
      price: 49,
      features: [
        "Advanced vulnerability detection systems",
        "Unlimited targets and training simulations",
        "Custom hacking templates library",
        "Auto-scaling (up to 10 nodes)",
        "Priority mission access",
        "Neural API integrations",
        "Sentinel notification system"
      ],
      cta: isClient ? "Upgrade Now" : "Wake Up",
      popular: true,
      color: "primary"
    },
    {
      name: isClient ? "Enterprise" : "The One",
      description: isClient ? "For large organizations" : "For Zion's elite operators",
      price: "Custom",
      features: [
        `Everything in ${isClient ? 'Professional' : 'Red Pill'}`,
        "Custom Matrix bypass protocols",
        "Unlimited processing nodes",
        isClient ? "Dedicated security team" : "Agent Smith detection avoidance",
        "Team collaboration modules",
        isClient ? "24/7 priority support" : "Direct link to the Architect",
        "Custom neural interfaces"
      ],
      cta: isClient ? "Contact Sales" : "Bend Reality",
      popular: false,
      color: "primary"
    }
  ]

  return (
    <section className="py-16 relative overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-10">
        <MatrixCode density={15} speed={0.8} />
      </div>

      <div className="container relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold">
            {isClient ? (
              <>Security <span className="text-blue-400">Plans</span></>
            ) : (
              <><span className="gradient-text">Free</span> your mind</>
            )}
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto font-mono">
            {isClient ?
              "Choose the security plan that fits your organization's needs. All plans include access to our security testing marketplace with a 2% fee." :
              "/* Choose the path that defines your reality. All access levels include the Zion mission network with 2% fee. */"
            }
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`border ${plan.popular ? (plan.color === 'blue' ? 'border-blue-500' : 'border-primary') : (plan.color === 'blue' ? 'border-blue-500/30' : 'border-primary/30')} bg-black/70 backdrop-blur-sm relative overflow-hidden rounded-lg`}
            >
              {plan.popular && (
                <div className="absolute top-0 right-0">
                  <div className={`${plan.color === 'blue' ? 'bg-blue-500 text-white' : 'bg-primary text-black'} text-xs font-mono px-3 py-1 font-bold rounded-bl-md`}>
                    {isClient ? 'RECOMMENDED' : 'RECOMMENDED PATH'}
                  </div>
                </div>
              )}
              <div className="p-6">
                <h3 className={`text-2xl font-bold font-mono ${plan.color === 'blue' ? 'text-blue-400' : ''}`}>{plan.name}</h3>
                <p className="text-muted-foreground">{plan.description}</p>

                <div className="my-6">
                  {typeof plan.price === 'number' ? (
                    <div className="flex items-baseline">
                      <span className={`text-4xl font-bold font-mono ${plan.color === 'blue' ? 'text-blue-400' : ''}`}>${plan.price}</span>
                      {plan.price > 0 && <span className="text-muted-foreground ml-2 font-mono">{isClient ? '/month' : '/cycle'}</span>}
                    </div>
                  ) : (
                    <div className={`text-4xl font-bold font-mono ${plan.color === 'blue' ? 'text-blue-400' : ''}`}>{plan.price}</div>
                  )}
                </div>

                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                      <Check className={`mr-2 h-5 w-5 ${plan.color === 'blue' ? 'text-blue-400' : 'text-primary'}`} />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  className={`w-full ${
                    plan.color === 'blue'
                      ? (plan.popular ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-black border border-blue-500/50 text-blue-400 hover:bg-blue-500/20')
                      : (plan.popular ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'bg-black border border-primary/50 text-primary hover:bg-primary/20')
                  }`}
                >
                  {plan.cta}
                </Button>
              </div>
            </div>
          ))}
        </div>

        <div className={`mt-16 max-w-3xl mx-auto p-6 border ${isClient ? 'border-blue-500/30' : 'border-primary/30'} bg-black/70 backdrop-blur-sm rounded-lg`}>
          <h3 className="text-xl font-semibold mb-4 font-mono">{isClient ? '/* Security_Marketplace_Fee */' : '/* Zion_Network_Protocol */'}</h3>
          <p className="mb-4">
            All {isClient ? 'security plans' : 'access levels'} include {isClient ? 'access to our security testing marketplace' : 'membership in the Zion Network'} with a <span className={`${isClient ? 'text-blue-400' : 'text-primary'} font-semibold font-mono`}>2%</span> {isClient ? 'platform' : 'transmission'} fee on {isClient ? 'completed security tests' : 'completed missions'}.
            {isClient ? ' Other security firms' : ' The Matrix agents'} typically charge 15-30% for similar services.
          </p>
          <div className={`flex items-center justify-between p-4 border ${isClient ? 'border-blue-500/30' : 'border-primary/30'} rounded-md bg-black/70`}>
            <div className="font-semibold font-mono">{isClient ? 'Security Platform Fee' : 'Resistance Operation Fee'}</div>
            <div className={`text-xl font-bold ${isClient ? 'text-blue-400' : 'text-primary'} font-mono`}>2%</div>
          </div>
        </div>
      </div>
    </section>
  )
}
