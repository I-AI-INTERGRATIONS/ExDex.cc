"use client"

import {
  Shield,
  Code,
  Bot,
  Cpu,
  Cloud,
  BarChart3,
  DollarSign,
  Search
} from "lucide-react"
import { useRouter } from "next/navigation"

export default function FeaturesSection() {
  const features = [
    {
      icon: <Shield className="h-10 w-10 text-primary" />,
      title: "Smart Vulnerability Scanning",
      description: "Automatically detect vulnerabilities across your target scope with intelligent scanning algorithms.",
      section: "vulnerability-scanning"
    },
    {
      icon: <Code className="h-10 w-10 text-primary" />,
      title: "AI-Powered Testing",
      description: "Leverage machine learning to identify potential vulnerabilities and security flaws in applications.",
      section: "ai-testing"
    },
    {
      icon: <Bot className="h-10 w-10 text-primary" />,
      title: "Custom Workflows",
      description: "Build your own recon and testing workflows with our intuitive drag-and-drop interface.",
      section: "custom-workflows"
    },
    {
      icon: <Cpu className="h-10 w-10 text-primary" />,
      title: "Efficient Resource Use",
      description: "Scale your testing infrastructure automatically based on workload demands.",
      section: "resource-use"
    },
    {
      icon: <Cloud className="h-10 w-10 text-primary" />,
      title: "Cloud Native Architecture",
      description: "Deploy your automation in AWS, GCP, or Azure with our optimized cloud templates.",
      section: "cloud-native"
    },
    {
      icon: <BarChart3 className="h-10 w-10 text-primary" />,
      title: "Comprehensive Analytics",
      description: "Track your bug bounty performance with detailed metrics and visualizations.",
      section: "analytics"
    },
    {
      icon: <DollarSign className="h-10 w-10 text-primary" />,
      title: "Freelance Bounty Marketplace",
      description: "Post and claim bounties with only a 2% platform fee - much lower than competitors.",
      section: "bounties"
    },
    {
      icon: <Search className="h-10 w-10 text-primary" />,
      title: "Vulnerability Intelligence",
      description: "Get notified about new CVEs that affect your monitored technology stack.",
      section: "vulnerability-intelligence"
    }
  ]

  const handleNavigate = (section: string) => {
    const element = document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="features" className="py-16">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold">This is your last chance, <span className="gradient-text">Neo</span></h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-3xl mx-auto">
            After this, there is no turning back. You take the blue pill - the story ends, you wake up in your bed and believe whatever you want to believe. You take the red pill - you stay in Wonderland and I show you how deep the rabbit hole goes.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <button
              key={index}
              className="feature-button group"
              onClick={() => handleNavigate(feature.section)}
              id={`feature-${feature.section}`}
            >
              <div className="p-4">
                <div className="mb-4">{feature.icon}</div>
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">
                  {feature.description}
                </p>
                <div className="mt-4 text-primary text-xs font-mono opacity-0 group-hover:opacity-100 transition-opacity">
                  &gt; follow_the_white_rabbit.exe --target={feature.section}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  )
}
