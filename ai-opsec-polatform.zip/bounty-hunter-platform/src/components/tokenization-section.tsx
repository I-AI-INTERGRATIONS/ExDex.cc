"use client"

import { Button } from "@/components/ui/button"
import { LockKeyhole, Key, Shield, Zap, Layers, ArrowRight } from "lucide-react"
import MatrixCode from "@/components/matrix-code"

interface TokenizationSectionProps {
  userPath?: 'blue' | 'red' | null
}

export default function TokenizationSection({ userPath = 'red' }: TokenizationSectionProps) {
  const isClient = userPath === 'blue';

  return (
    <section id="tokenization" className="py-16 bg-black/30 backdrop-blur-md relative overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-20">
        <MatrixCode density={25} speed={1.0} />
      </div>
      <div className="container relative z-10">
        <div className="mb-12">
          <h2 className="text-3xl md:text-4xl font-bold">
            NEXUS <span className="gradient-text">Security Keys</span> System
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-3xl">
            {isClient
              ? "Our advanced security key system protects your digital assets with next-generation encryption and access control."
              : "Within the NEXUS, security keys unlock virtual vaults and exclusive rewards. Find them before others do."
            }
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="vr-panel p-6">
            <h3 className="text-2xl font-bold vr-heading text-blue-400 mb-4">// SECURITY_PROTOCOL</h3>
            <p className="text-muted-foreground mb-6">
              For organizations seeking protection. Our security protocol prevents breaches
              and protects sensitive data against virtual threats.
            </p>

            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-blue-900/30 border border-blue-500/50 flex items-center justify-center text-blue-400">
                  <Shield className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-semibold font-mono text-blue-400">Threat Detection</h4>
                  <p className="text-sm text-muted-foreground">
                    Submit your systems for comprehensive testing by our network of elite hunters
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-blue-900/30 border border-blue-500/50 flex items-center justify-center text-blue-400">
                  <LockKeyhole className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-semibold font-mono text-blue-400">Secure Key Generation</h4>
                  <p className="text-sm text-muted-foreground">
                    Industry-standard security keys to protect sensitive data and digital assets
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-blue-900/30 border border-blue-500/50 flex items-center justify-center text-blue-400">
                  <Layers className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-semibold font-mono text-blue-400">Compliance Shield</h4>
                  <p className="text-sm text-muted-foreground">
                    Automated compliance with PCI-DSS, GDPR, HIPAA and other regulatory standards
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-8">
              <Button className="vr-button w-full">
                {isClient ? 'Access Security Protocol' : 'View Protocol Details'} <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="vr-panel p-6">
            <h3 className="text-2xl font-bold vr-heading mb-4">// HUNTER_PROTOCOL</h3>
            <p className="text-muted-foreground mb-6">
              For elite hunters seeking virtual quests. Track down vulnerabilities in the NEXUS
              and claim your bounties ahead of other players.
            </p>

            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/10 border border-primary/50 flex items-center justify-center text-primary">
                  <Key className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-semibold font-mono">API Access Keys</h4>
                  <p className="text-sm text-muted-foreground">
                    Secure access to advanced platform APIs and vulnerability scanning tools
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/10 border border-primary/50 flex items-center justify-center text-primary">
                  <Zap className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-semibold font-mono">Virtual Authentication</h4>
                  <p className="text-sm text-muted-foreground">
                    JWT and OAuth2 integration for seamless access to bounty missions
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/10 border border-primary/50 flex items-center justify-center text-primary">
                  <Layers className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-semibold font-mono">Digital Reward System</h4>
                  <p className="text-sm text-muted-foreground">
                    Earn credits based on severity and impact of discovered vulnerabilities
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-8">
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground w-full">
                {!isClient ? 'Access Hunter Mode' : 'View Hunter Details'} <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="mt-12 vr-panel p-6">
          <h3 className="text-2xl font-bold vr-heading mb-4">// SECURITY_STANDARDS</h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="border border-primary/20 bg-black/50 p-4 rounded-lg">
              <h4 className="font-semibold font-mono text-primary mb-2">Level 1 Security</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start">
                  <span className="text-primary mr-2">✓</span>
                  <span>FIPS 140-2 compliant encryption</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">✓</span>
                  <span>Basic digital vault architecture</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">✓</span>
                  <span>PCI DSS compliance integration</span>
                </li>
              </ul>
            </div>

            <div className="border border-primary/20 bg-black/50 p-4 rounded-lg">
              <h4 className="font-semibold font-mono text-primary mb-2">Level 2 Security</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start">
                  <span className="text-primary mr-2">✓</span>
                  <span>HSM-backed security system</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">✓</span>
                  <span>Format-preserving encryption</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">✓</span>
                  <span>Cross-platform key validation</span>
                </li>
              </ul>
            </div>

            <div className="border border-primary/20 bg-black/50 p-4 rounded-lg">
              <h4 className="font-semibold font-mono text-primary mb-2">Level 3 Security</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start">
                  <span className="text-primary mr-2">✓</span>
                  <span>Quantum-resistant algorithms</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">✓</span>
                  <span>Zero-knowledge proof validation</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">✓</span>
                  <span>Self-destructing key capabilities</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-6 p-4 border border-primary/20 bg-black/30 rounded-lg font-mono text-sm text-muted-foreground">
            <p>/* All security protocols adhere to the latest NIST guidelines and are regularly audited by independent security researchers. Our systems have achieved SOC2 Type II certification and are GDPR compliant. */</p>
          </div>
        </div>
      </div>
    </section>
  )
}
