"use client"

import Link from "next/link"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"
import { Menu, X, GameController, Key, Shield, User } from "lucide-react"

interface NavbarProps {
  userPath?: 'blue' | 'red' | null
}

export default function Navbar({ userPath = 'red' }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [virtualText, setVirtualText] = useState("")

  useEffect(() => {
    const interval = setInterval(() => {
      // Generate random binary and hex sequence
      let text = "";
      const chars = "0123456789ABCDEF";
      for (let i = 0; i < 8; i++) {
        text += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      setVirtualText(text);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const isClient = userPath === 'blue';

  return (
    <header className="fixed top-0 left-0 z-50 w-full border-b border-primary/30 bg-black/80 backdrop-blur-md">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6">
          <Link href="/" className="flex items-center gap-2">
            <GameController className="h-6 w-6 text-primary" />
            <span className="text-2xl font-bold gradient-text">NEXUS</span>
            <span className="text-xs text-primary opacity-70 font-mono">{virtualText}</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="#features" className="text-sm font-medium text-muted-foreground hover:text-primary hover:opacity-80">
              {isClient ? 'Security Hub' : 'Challenges'}
            </Link>
            <Link href="#cloud-native" className="text-sm font-medium text-muted-foreground hover:text-primary hover:opacity-80">
              {isClient ? 'Architecture' : 'System Map'}
            </Link>
            <Link href="#tokenization" className="text-sm font-medium text-muted-foreground hover:text-primary hover:opacity-80 flex items-center">
              <Key className="h-3 w-3 mr-1" />
              Security Keys
            </Link>
            <Link href="#bounties" className="text-sm font-medium text-muted-foreground hover:text-primary hover:opacity-80">
              {isClient ? 'Security Missions' : 'Virtual Quests'}
            </Link>
            {!isClient && (
              <Link href="#specialists" className="text-sm font-medium text-muted-foreground hover:text-primary hover:opacity-80">
                Elite Hunters
              </Link>
            )}
            <Link href="#pricing" className="text-sm font-medium text-muted-foreground hover:text-primary hover:opacity-80">
              {isClient ? 'Access Levels' : 'Credits'}
            </Link>
          </nav>
        </div>
        <div className="hidden md:flex items-center gap-4">
          <Link href="/choice" className="text-xs text-muted-foreground hover:text-primary">
            Switch Avatar
          </Link>
          <div className="h-4 w-px bg-gray-700"></div>
          <ThemeToggle />
          <Button
            variant="outline"
            size="sm"
            className="vr-button"
          >
            <User className="h-4 w-4 mr-2" />
            {isClient ? 'Security Portal' : 'Hunter Console'}
          </Button>
          <Button
            size="sm"
            className="bg-primary text-primary-foreground hover:bg-primary/90"
          >
            <Shield className="h-4 w-4 mr-2" />
            {isClient ? 'Create Mission' : 'Find Bounty'}
          </Button>
        </div>
        <button
          className="md:hidden"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X size={24} className="text-primary" /> : <Menu size={24} className="text-primary" />}
        </button>
      </div>
      {isOpen && (
        <div className="md:hidden p-4 border-t border-primary/30 bg-background">
          <nav className="flex flex-col gap-4">
            <Link
              href="#features"
              className="text-sm font-medium text-muted-foreground hover:text-primary"
              onClick={() => setIsOpen(false)}
            >
              {isClient ? 'Security Hub' : 'Challenges'}
            </Link>
            <Link
              href="#cloud-native"
              className="text-sm font-medium text-muted-foreground hover:text-primary"
              onClick={() => setIsOpen(false)}
            >
              {isClient ? 'Architecture' : 'System Map'}
            </Link>
            <Link
              href="#tokenization"
              className="text-sm font-medium text-muted-foreground hover:text-primary flex items-center"
              onClick={() => setIsOpen(false)}
            >
              <Key className="h-3 w-3 mr-1" />
              Security Keys
            </Link>
            <Link
              href="#bounties"
              className="text-sm font-medium text-muted-foreground hover:text-primary"
              onClick={() => setIsOpen(false)}
            >
              {isClient ? 'Security Missions' : 'Virtual Quests'}
            </Link>
            {!isClient && (
              <Link
                href="#specialists"
                className="text-sm font-medium text-muted-foreground hover:text-primary"
                onClick={() => setIsOpen(false)}
              >
                Elite Hunters
              </Link>
            )}
            <Link
              href="#pricing"
              className="text-sm font-medium text-muted-foreground hover:text-primary"
              onClick={() => setIsOpen(false)}
            >
              {isClient ? 'Access Levels' : 'Credits'}
            </Link>
            <div className="flex flex-col gap-2 mt-2">
              <Link href="/choice">
                <Button variant="ghost" size="sm" className="w-full justify-start text-muted-foreground">
                  Switch Avatar
                </Button>
              </Link>
              <Button
                variant="outline"
                size="sm"
                className="vr-button w-full"
              >
                <User className="h-4 w-4 mr-2" />
                {isClient ? 'Security Portal' : 'Hunter Console'}
              </Button>
              <Button
                size="sm"
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
              >
                <Shield className="h-4 w-4 mr-2" />
                {isClient ? 'Create Mission' : 'Find Bounty'}
              </Button>
              <div className="flex justify-end mt-2">
                <ThemeToggle />
              </div>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
