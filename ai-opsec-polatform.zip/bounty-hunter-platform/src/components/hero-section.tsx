"use client"

import { useEffect, useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

interface HeroSectionProps {
  userPath?: 'blue' | 'red' | null
}

export default function HeroSection({ userPath = 'red' }: HeroSectionProps) {
  const [text, setText] = useState("");
  const fullText = userPath === 'blue'
    ? "Welcome to the NEXUS, Gunter..."
    : "Ready Player One...";
  const videoRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let i = 0;
    const typing = setInterval(() => {
      if (i < fullText.length) {
        setText(fullText.substring(0, i + 1));
        i++;
      } else {
        clearInterval(typing);
      }
    }, 100);

    return () => clearInterval(typing);
  }, [fullText]);

  useEffect(() => {
    // Virtual data stream effect
    const videoContainer = videoRef.current;
    if (!videoContainer) return;

    const createDataStream = () => {
      const dataChars = "01αβγδεζηθλμνξπρστ";
      const dataLines = 15;

      for (let i = 0; i < dataLines; i++) {
        const line = document.createElement("div");
        line.className = "data-line";
        line.style.left = `${Math.random() * 100}%`;
        line.style.animationDelay = `${Math.random() * 5}s`;
        line.style.animationDuration = `${5 + Math.random() * 10}s`;

        let dataText = "";
        for (let j = 0; j < 20; j++) {
          dataText += dataChars.charAt(Math.floor(Math.random() * dataChars.length));
        }

        line.textContent = dataText;
        videoContainer.appendChild(line);
      }
    };

    createDataStream();

    return () => {
      while (videoContainer.firstChild) {
        videoContainer.removeChild(videoContainer.firstChild);
      }
    };
  }, []);

  const isClient = userPath === 'blue';

  return (
    <section className="pt-24 pb-12">
      <div className="container flex flex-col items-center text-center">
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
          {isClient ? (
            <>
              Welcome to the <span className="gradient-text">NEXUS</span>
              <br />
              Virtual Security Testing Arena
            </>
          ) : (
            <>
              <span className="gradient-text">Ready Player One</span>
              <br />
              Find the Easter Eggs, Win the Bounty
            </>
          )}
        </h1>
        <p className="mt-6 max-w-2xl text-lg text-muted-foreground terminal-text">
          {text}
        </p>
        <p className="mt-6 max-w-2xl text-lg text-muted-foreground">
          {isClient ? (
            "Connect with elite security researchers in our virtual world. Post security testing missions, reward successful hunters, and secure your digital assets."
          ) : (
            "Join other hunters in the NEXUS and prove your skills. Find vulnerabilities, collect bounties, and climb the security leaderboard."
          )}
        </p>
        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <Link href="#bounties">
            <Button
              size="lg"
              className="vr-button"
            >
              {isClient ? 'Post Security Mission' : 'Find Virtual Missions'}
            </Button>
          </Link>
          <Link href="#tokenization">
            <Button
              variant="outline"
              size="lg"
              className="border-primary/50 text-primary hover:bg-primary/20"
            >
              {isClient ? 'Learn About Security' : 'View Leaderboard'}
            </Button>
          </Link>
        </div>
        <div className="mt-16 relative w-full max-w-5xl vr-panel">
          <div className="absolute -inset-0.5 bg-primary/30 opacity-75 blur-xl rounded-lg"></div>
          <div className="relative w-full aspect-[16/9] bg-black/80 backdrop-blur-sm border border-primary/30 rounded-lg overflow-hidden">
            <div className="data-stream" ref={videoRef}></div>
            <div className="flex items-center justify-center h-full">
              <div className="text-center p-4">
                <div className="w-20 h-20 mx-auto rounded-full bg-primary/20 flex items-center justify-center mb-4 border border-primary/40">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polygon points="5 3 19 12 5 21 5 3"></polygon>
                  </svg>
                </div>
                <p className="font-medium text-muted-foreground">
                  {isClient ? 'Watch how NEXUS protects your assets' : 'The hunt begins - watch the demo'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
