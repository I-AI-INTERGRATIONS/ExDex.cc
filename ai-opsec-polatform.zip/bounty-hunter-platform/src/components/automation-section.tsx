"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, Cloud, Code, Database, Server, Workflow } from "lucide-react"

export default function AutomationSection() {
  return (
    <section id="cloud-native" className="py-16">
      <div className="container">
        <div className="mb-12">
          <h2 className="text-3xl md:text-4xl font-bold">
            Plug Into The <span className="gradient-text">Matrix</span> Architecture
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-3xl">
            What you must learn, Neo, is that these rules are no different than the rules of a computer system. Some of them can be bent. Others can be broken.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-bold mb-6">The Evolution of Systems Control</h3>

            <div className="space-y-8">
              <div className="relative pl-8 border-l border-primary/30">
                <div className="absolute -left-3 top-0 h-6 w-6 rounded-full bg-black border border-primary flex items-center justify-center">
                  <span className="text-xs text-primary">01</span>
                </div>
                <h4 className="font-semibold text-lg mb-2">The First Iteration</h4>
                <p className="text-muted-foreground mb-4">
                  Early automation attempts were primitive and limited, like the first Matrix design that was quite similar to paradise.
                </p>
                <div className="bg-black/40 p-3 rounded-md font-mono text-xs text-primary">
                  <code>
                    cat domains.txt | subfinder | httpx | nuclei -t templates/
                  </code>
                </div>
              </div>

              <div className="relative pl-8 border-l border-primary/30">
                <div className="absolute -left-3 top-0 h-6 w-6 rounded-full bg-black border border-primary flex items-center justify-center">
                  <span className="text-xs text-primary">10</span>
                </div>
                <h4 className="font-semibold text-lg mb-2">The Second Paradigm</h4>
                <p className="text-muted-foreground mb-4">
                  The second version introduced structure and order, but humans still rejected the program as they do with structured frameworks.
                </p>
                <div className="bg-black/40 p-3 rounded-md font-mono text-xs text-primary">
                  <code>
                    django-admin subfinder -rootdomain example.com
                  </code>
                </div>
              </div>

              <div className="relative pl-8 border-l border-primary/30">
                <div className="absolute -left-3 top-0 h-6 w-6 rounded-full bg-black border border-primary flex items-center justify-center">
                  <span className="text-xs text-primary">11</span>
                </div>
                <h4 className="font-semibold text-lg mb-2">The Path of Distribution</h4>
                <p className="text-muted-foreground mb-4">
                  The architects created systems of delegation, like RabbitMQ, spreading the workload across many agents, but control remained centralized.
                </p>
              </div>

              <div className="relative pl-8">
                <div className="absolute -left-3 top-0 h-6 w-6 rounded-full bg-primary flex items-center justify-center">
                  <span className="text-xs text-black font-bold">00</span>
                </div>
                <h4 className="font-semibold text-lg mb-2">The Machine City</h4>
                <p className="text-muted-foreground mb-4">
                  The current iteration - a cloud-native architecture where machines spawn and die automatically, resources flowing like electricity through the machine city.
                </p>
              </div>
            </div>
          </div>

          <div>
            <div className="border border-primary/30 bg-black/70 backdrop-blur-sm h-full p-6 rounded-lg overflow-hidden relative">
              <div className="matrix-code"></div>
              <h3 className="text-xl font-semibold mb-6">The System Architecture</h3>
              <p className="text-muted-foreground mb-6 font-mono">
                /* What if I told you, Neo, that everything you're seeing is just code? */
              </p>
              <div className="space-y-6 relative z-10">
                <div className="flex gap-4 group">
                  <Server className="h-12 w-12 text-primary group-hover:animate-pulse" />
                  <div>
                    <h4 className="font-semibold font-mono">&gt; Containerized_Workers</h4>
                    <p className="text-sm text-muted-foreground">
                      Docker containers managed by Fargate/ECS that automatically scale based on queue size
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 group">
                  <Workflow className="h-12 w-12 text-primary group-hover:animate-pulse" />
                  <div>
                    <h4 className="font-semibold font-mono">&gt; Managed_Message_Queues</h4>
                    <p className="text-sm text-muted-foreground">
                      AWS SQS for reliable job distribution with dead letter queues for failure monitoring
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 group">
                  <Database className="h-12 w-12 text-primary group-hover:animate-pulse" />
                  <div>
                    <h4 className="font-semibold font-mono">&gt; Relational_Databases</h4>
                    <p className="text-sm text-muted-foreground">
                      Amazon Aurora or equivalent for storing structured vulnerability data and targets
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 group">
                  <Cloud className="h-12 w-12 text-primary group-hover:animate-pulse" />
                  <div>
                    <h4 className="font-semibold font-mono">&gt; Shared_Resource_Access</h4>
                    <p className="text-sm text-muted-foreground">
                      EFS or similar file systems to share configuration and tools across containers
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 group">
                  <Code className="h-12 w-12 text-primary group-hover:animate-pulse" />
                  <div>
                    <h4 className="font-semibold font-mono">&gt; Flexible_CLI_Tools</h4>
                    <p className="text-sm text-muted-foreground">
                      Interact with your automation infrastructure through powerful CLI tools
                    </p>
                  </div>
                </div>

                <Button className="w-full mt-4 bg-black border border-primary text-primary hover:bg-primary/20">
                  There is no spoon <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
