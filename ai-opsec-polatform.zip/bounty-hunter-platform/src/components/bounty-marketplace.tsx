"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, ShieldAlert, TagIcon, Users, FileCode, ExternalLink, EyeOff } from "lucide-react"
import MatrixCode from "@/components/matrix-code"

interface BountyMarketplaceProps {
  userPath?: 'blue' | 'red' | null
}

export default function BountyMarketplace({ userPath = 'red' }: BountyMarketplaceProps) {
  const bounties = [
    {
      id: 1,
      title: "WordPress Plugin Vulnerability Assessment",
      description: "Looking for skilled operators to assess our WordPress plugin for potential system breaches before release.",
      reward: 1500,
      category: "Web App",
      difficulty: "Medium",
      submissions: 4,
      status: "Open",
      clientName: "WP Innovations Inc."
    },
    {
      id: 2,
      title: "iOS Banking App Penetration Testing",
      description: "Need a team to navigate the defenses of our iOS banking application, focusing on authentication vulnerabilities.",
      reward: 3000,
      category: "Mobile",
      difficulty: "Hard",
      submissions: 2,
      status: "Open",
      clientName: "SecureBank Solutions"
    },
    {
      id: 3,
      title: "E-commerce API Security Audit",
      description: "Seeking elite hackers for our e-commerce platform API endpoints with focus on payment processing security flaws.",
      reward: 2200,
      category: "API",
      difficulty: "Medium",
      submissions: 7,
      status: "Open",
      clientName: "ShopSafe Inc."
    },
    {
      id: 4,
      title: "Smart Contract Audit for DeFi Platform",
      description: "Audit required for our new DeFi platform smart contracts. Only the most skilled operators need apply.",
      reward: 5000,
      category: "Blockchain",
      difficulty: "Expert",
      submissions: 3,
      status: "Open",
      clientName: "CryptoMatrix Fund"
    }
  ]

  return (
    <section className="py-16 bg-black/30 backdrop-blur-md relative overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-20">
        <MatrixCode density={30} />
      </div>
      <div className="container relative z-10">
        <div className="mb-12">
          {userPath === 'red' ? (
            <>
              <h2 className="text-3xl md:text-4xl font-bold">
                Zion <span className="gradient-text">Missions</span> Network
              </h2>
              <p className="mt-4 text-lg text-muted-foreground max-w-3xl">
                The Matrix has you, Neo. But it also has countless systems with vulnerabilities. Join our resistance. Find the flaws. Get paid. Only 2% operator fee.
              </p>
            </>
          ) : (
            <>
              <h2 className="text-3xl md:text-4xl font-bold">
                Security <span className="text-blue-400">Testing</span> Marketplace
              </h2>
              <p className="mt-4 text-lg text-muted-foreground max-w-3xl">
                Post your security testing requirements and connect with skilled security researchers. Our platform ensures quality results with a minimal 2% service fee.
              </p>
            </>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {bounties.map((bounty) => (
            <div
              key={bounty.id}
              className={`border ${userPath === 'blue' ? 'border-blue-500/30 hover:border-blue-500/70' : 'border-primary/30 hover:border-primary/70'} bg-black/70 backdrop-blur-sm rounded-lg overflow-hidden transition-all`}
            >
              <div className="p-6">
                <div className="flex justify-between items-start">
                  <h3 className="text-xl font-semibold font-mono">{bounty.title}</h3>
                  <div className={`flex items-center ${userPath === 'blue' ? 'text-blue-400' : 'text-primary'} font-mono`}>
                    <span className="mr-1">$</span>
                    <span>{bounty.reward}</span>
                  </div>
                </div>
                <p className="mt-2 text-muted-foreground">
                  {bounty.description}
                </p>

                {/* Show client name only to red pill users (developers) */}
                {userPath === 'red' && (
                  <div className="mt-2 flex items-center">
                    <span className="text-xs text-muted-foreground">Posted by: </span>
                    <span className="text-xs ml-1 font-mono text-primary">{bounty.clientName}</span>
                  </div>
                )}

                <div className="flex flex-wrap gap-2 mt-4">
                  <div className={`inline-flex items-center px-3 py-1 rounded-full bg-black/50 border ${userPath === 'blue' ? 'border-blue-500/30 text-blue-400' : 'border-primary/30 text-primary'} text-xs font-mono`}>
                    <TagIcon className="h-3 w-3 mr-1" />
                    {bounty.category}
                  </div>
                  <div className={`inline-flex items-center px-3 py-1 rounded-full bg-black/50 border ${userPath === 'blue' ? 'border-blue-500/30 text-blue-400' : 'border-primary/30 text-primary'} text-xs font-mono`}>
                    <ShieldAlert className="h-3 w-3 mr-1" />
                    {bounty.difficulty}
                  </div>
                  <div className={`inline-flex items-center px-3 py-1 rounded-full bg-black/50 border ${userPath === 'blue' ? 'border-blue-500/30 text-blue-400' : 'border-primary/30 text-primary'} text-xs font-mono`}>
                    <Users className="h-3 w-3 mr-1" />
                    {bounty.submissions} {userPath === 'blue' ? 'testers' : 'ops'}
                  </div>
                  <div className={`inline-flex items-center px-3 py-1 rounded-full ${userPath === 'blue' ? 'bg-blue-900/30 border-blue-500/50 text-blue-400' : 'bg-green-900/30 border-primary/50 text-primary'} text-xs font-mono`}>
                    {bounty.status}
                  </div>
                </div>
                <div className="mt-4">
                  {userPath === 'red' ? (
                    <Button className="w-full" variant="outline">
                      <span className="font-mono">// infiltrate_system</span> <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  ) : (
                    <Button className="w-full border-blue-500/50 text-blue-400 hover:bg-blue-500/20" variant="outline">
                      View Submissions <ExternalLink className="ml-2 h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="flex flex-col md:flex-row gap-8 mt-12 items-center">
          <div className="w-full md:w-1/2">
            {userPath === 'red' ? (
              <>
                <h3 className="text-2xl font-bold mb-4 font-mono">// submit_vulnerability_report</h3>
                <p className="text-muted-foreground mb-6">
                  Found a security flaw? Submit detailed reports through our secure channel to claim your bounty.
                  All submissions are reviewed within 48 hours by our security team.
                </p>
                <Button className="w-full md:w-auto bg-primary text-primary-foreground">
                  <FileCode className="mr-2 h-4 w-4" /> Submit Report
                </Button>
              </>
            ) : (
              <>
                <h3 className="text-2xl font-bold mb-4 font-mono text-blue-400">// post_security_job</h3>
                <p className="text-muted-foreground mb-6">
                  Need security testing for your application? Post a job and get help from our community of security researchers.
                  Our platform charges just 2% on successful completions, significantly lower than industry standards.
                </p>
                <Button className="w-full md:w-auto bg-blue-600 hover:bg-blue-700 text-white">
                  <FileCode className="mr-2 h-4 w-4" /> Post Security Job
                </Button>
              </>
            )}
          </div>
          <div className={`w-full md:w-1/2 p-6 bg-black/50 backdrop-blur-sm border ${userPath === 'blue' ? 'border-blue-500/30' : 'border-primary/30'} rounded-lg`}>
            <h4 className="font-semibold mb-4 font-mono">/* {userPath === 'blue' ? 'client_benefits' : 'system_advantages'} */</h4>
            <ul className="space-y-3 font-mono">
              <li className="flex items-start">
                <div className={`mr-2 h-6 w-6 ${userPath === 'blue' ? 'text-blue-400' : 'text-primary'}`}>✓</div>
                <span>Only 2% {userPath === 'blue' ? 'platform' : 'operator'} fee (vs 15-30% elsewhere)</span>
              </li>
              <li className="flex items-start">
                <div className={`mr-2 h-6 w-6 ${userPath === 'blue' ? 'text-blue-400' : 'text-primary'}`}>✓</div>
                <span>Direct {userPath === 'blue' ? 'communication with security researchers' : 'P2P communication with resistance operators'}</span>
              </li>
              <li className="flex items-start">
                <div className={`mr-2 h-6 w-6 ${userPath === 'blue' ? 'text-blue-400' : 'text-primary'}`}>✓</div>
                <span>Secure escrow protection system for all parties</span>
              </li>
              <li className="flex items-start">
                <div className={`mr-2 h-6 w-6 ${userPath === 'blue' ? 'text-blue-400' : 'text-primary'}`}>✓</div>
                <span>Standardized {userPath === 'blue' ? 'security testing' : 'vulnerability'} reporting {userPath === 'blue' ? 'methodologies' : 'protocols'}</span>
              </li>
              {userPath === 'blue' && (
                <li className="flex items-start">
                  <div className="mr-2 h-6 w-6 text-blue-400">✓</div>
                  <span>Private vulnerability disclosure with NDA protection</span>
                </li>
              )}
              {userPath === 'red' && (
                <li className="flex items-start">
                  <div className="mr-2 h-6 w-6 text-primary">✓</div>
                  <span>Access to specialized training simulations</span>
                </li>
              )}
            </ul>

            {userPath === 'blue' && (
              <div className="mt-4 p-3 bg-blue-900/20 border border-blue-500/30 rounded-md flex items-center text-sm">
                <EyeOff className="h-4 w-4 text-blue-400 mr-2" />
                <span>All client data is encrypted and kept strictly confidential</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
