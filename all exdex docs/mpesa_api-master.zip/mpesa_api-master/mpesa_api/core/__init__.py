default_app_config = "mpesa_api.core.apps.CoreConfig"
