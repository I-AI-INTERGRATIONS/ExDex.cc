export const INITIALIZED = 'Contract instance has already been initialized';
export const ZERO_ADDRESS_NOT_VALID = 'ZERO_ADDRESS_NOT_VALID';
export const CALLER_NOT_DISCOUNT_TOKEN = 'CALLER_NOT_DISCOUNT_TOKEN';
export const CALLER_NOT_A_TOKEN = 'CALLER_NOT_A_TOKEN';
