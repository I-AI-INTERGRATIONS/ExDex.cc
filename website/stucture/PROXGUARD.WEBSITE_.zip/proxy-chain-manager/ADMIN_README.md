# Admin Access for Proxy Chain Manager

## Overview

As the admin of the Proxy Chain Manager application, you have special privileges that allow you to bypass the payment verification system. This guide explains how to activate and use the admin access feature.

## Admin Credentials

The application is configured with your admin email:

- Admin Email: `finesseandcounterfits816@protonmail.com`

This email is hardcoded into the application and allows you to access the system without making payments.

## How to Access Admin Mode

### Using the Admin Bubble

The application features a discreet admin access bubble in the bottom-right corner of the payment screen:

1. When the payment screen appears, look for a small blue circular "A" icon in the bottom-right corner
2. Click on this icon to open the admin login panel
3. Enter your admin email: `finesseandcounterfits816@protonmail.com`
4. Click "Login"
5. The application will refresh with admin access enabled

### Using the Browser Console (Alternative Method)

If you prefer to use the browser console:

1. Open your browser's developer console (F12 or right-click > Inspect > Console)
2. Enter the following code:
   ```javascript
   // Set admin access directly
   localStorage.setItem('admin-access-granted', 'true');

   // Set up admin subscription
   const userId = 'admin-' + Date.now();
   localStorage.setItem('userId', userId);
   localStorage.setItem(`payment_verified_${userId}`, 'true');

   // Set subscription end date (100 years)
   const endDate = new Date();
   endDate.setFullYear(endDate.getFullYear() + 100);
   localStorage.setItem(`subscription_end_${userId}`, endDate.toISOString());
   localStorage.setItem('activeSubscription', 'true');

   // Reload to apply changes
   window.location.reload();
   ```

3. Press Enter to execute the code
4. The page will reload with admin access enabled

## Admin vs. Owner Access

The application has two special access modes:

1. **Admin Access**: Uses your email and shows a blue Admin Mode indicator
2. **Owner Access**: Uses an owner key and shows a green Owner Mode indicator

Both modes bypass payment verification, but they are visually distinct. As the admin, you'll see the blue Admin Mode indicator in the top-right corner of the screen and in the footer.

## How to Check Admin Status

To check if you currently have admin access:

1. Look for the blue "Admin Mode" indicator in the top-right corner of the screen
2. Check for "Admin Mode Active" text in the footer
3. Or check the localStorage value in the browser console:
   ```javascript
   console.log('Admin access active:', localStorage.getItem('admin-access-granted') === 'true');
   ```

## How to Remove Admin Access

If you want to test the application as a regular user:

1. Open the browser console
2. Enter:
   ```javascript
   localStorage.removeItem('admin-access-granted');
   window.location.reload();
   ```

## Security Considerations

- The admin email is hardcoded in the application for simplicity
- Admin access is stored in browser localStorage
- For added security in a production environment, consider implementing server-side verification

## Distribution

When distributing this application to users:

1. They will be required to make payment to use the application
2. You, as the admin, can use your email to bypass this requirement
3. The payment system will work as designed for all other users

Remember to keep your admin email confidential to maintain the security of the payment system.
