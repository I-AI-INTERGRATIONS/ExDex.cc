/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        background: "#000000", // Changed to pure black
        foreground: "hsl(var(--foreground))",
        'accent': '#10B981', // Emerald-500
        'accent-darker': '#059669', // Emerald-600
        'primary': '#6366F1', // Indigo-500
        'primary-dark': '#4F46E5', // Indigo-600
        'primary-darker': '#4338CA', // Indigo-700
        'secondary': '#A855F7', // Purple-500
        'secondary-darker': '#9333EA', // Purple-600
        'warning-yellow': '#FCD34D', // Amber-300
        'error-red': '#EF4444', // Red-500
        'card': '#000000', // Changed to pure black
        'muted-foreground': '#94A3B8', // Slate-400
        'matrix-green': '#00FF00', // Matrix green for cyberpunk theme
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        display: ['Space Grotesk', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      animation: {
        'pulse-glow': 'pulse-glow 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'terminal-scan': 'terminal-scan 2s ease-in-out infinite',
        'glitch': 'glitch 1s linear infinite',
        'matrix-rain': 'matrix-rain 10s linear infinite',
        'border-flow': 'border-flow 2s linear infinite',
        'qr-active': 'qr-active 3s ease-in-out infinite',
      },
      keyframes: {
        'pulse-glow': {
          '0%, 100%': {
            opacity: '1',
            filter: 'brightness(1) drop-shadow(0 0 0.5rem rgba(16, 185, 129, 0.2))'
          },
          '50%': {
            opacity: '0.8',
            filter: 'brightness(1.2) drop-shadow(0 0 0.75rem rgba(16, 185, 129, 0.5))'
          },
        },
        'terminal-scan': {
          '0%': {
            transform: 'translateY(0%)',
            opacity: '0.5'
          },
          '50%': {
            opacity: '1'
          },
          '100%': {
            transform: 'translateY(100%)',
            opacity: '0.5'
          }
        },
        'glitch': {
          '0%': {
            transform: 'translate(0)'
          },
          '1%': {
            transform: 'translate(-2px, 2px)'
          },
          '2%': {
            transform: 'translate(-2px, -2px)'
          },
          '3%': {
            transform: 'translate(0)'
          },
          '10%': {
            transform: 'translate(0)'
          },
          '11%': {
            transform: 'translate(2px, 2px)'
          },
          '12%': {
            transform: 'translate(-2px, 2px)'
          },
          '13%': {
            transform: 'translate(0)'
          },
          '100%': {
            transform: 'translate(0)'
          }
        },
        'matrix-rain': {
          '0%': {
            backgroundPosition: '0% 0%',
            opacity: '0.2'
          },
          '50%': {
            opacity: '0.3'
          },
          '100%': {
            backgroundPosition: '0% 100%',
            opacity: '0.2'
          }
        },
        'border-flow': {
          '0%': {
            borderColor: '#00FF00',
            boxShadow: '0 0 5px #00FF00'
          },
          '50%': {
            borderColor: '#00FFAA',
            boxShadow: '0 0 20px #00FFAA'
          },
          '100%': {
            borderColor: '#00FF00',
            boxShadow: '0 0 5px #00FF00'
          }
        },
        'qr-active': {
          '0%': {
            boxShadow: '0 0 5px #00FF00, inset 0 0 5px #00FF00'
          },
          '50%': {
            boxShadow: '0 0 15px #00FF00, inset 0 0 10px #00FF00'
          },
          '100%': {
            boxShadow: '0 0 5px #00FF00, inset 0 0 5px #00FF00'
          }
        }
      },
    },
  },
  darkMode: 'class',
  plugins: [],
}
