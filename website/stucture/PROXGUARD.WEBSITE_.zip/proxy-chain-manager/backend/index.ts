import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import speakeasy from 'speakeasy';
import CryptoJS from 'crypto-js';

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'secureVPN_jwt_secret_key_for_development';

// Middleware
app.use(cors());
app.use(express.json());

// Mock database for development purposes
const mockDB = {
  users: [
    {
      id: '1',
      email: 'user@example.com',
      password: 'hashed_password',
      name: 'Demo User',
      subscriptionStatus: 'free',
      subscriptionExpiry: null,
      mfaEnabled: false,
      mfaSecret: null,
      recoveryKeys: [],
    },
    {
      id: '2',
      email: 'premium@example.com',
      password: 'hashed_password',
      name: 'Premium User',
      subscriptionStatus: 'premium',
      subscriptionExpiry: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      mfaEnabled: true,
      mfaSecret: 'KA7OQJZ7OIVOQVIN5DJVLU6Q5RFQBFVZ',
      recoveryKeys: ['a1b2-c3d4-e5f6-g7h8'],
    },
  ],
  // Mock transaction data
  transactions: [],
  // Mock crypto addresses
  cryptoAddresses: {
    btc: ['bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh', 'bc1qwbvfcl9q62zt78mnwlvlr9zsvs2e435srt76yq'],
    eth: ['0x71C7656EC7ab88b098defB751B7401B5f6d8976F', '0x8ba1f109551bD432803012645Ac136ddd64DBA72'],
    usdt: ['0xdAC17F958D2ee523a2206206994597C13D831ec7', '0x4FE83213D56308330EC302a8BD641f1d0113A4Cc'],
    sol: ['5YNmS1R9nNSCDzb5a7mMJ1dwK9uHeAAQmx5tdCie1qJ3', '9W8ggKLiqrJ4abVfprUJqDwTzRdvMRaLxzRMEyJTHCEj'],
    xmr: ['44AFFq5kSiGBoZ4NMDwYtN18obc8AemS33DBLWs3H7otXft3XjrpDtQGv7SqSsaBYBb98uNbr2VBBEt7f2wfn3RVGQBEP3A'],
  },
};

// Helper functions
const generateToken = (userId: string) => {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: '24h' });
};

const verifyToken = (token: string) => {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
    return decoded;
  } catch (error) {
    return null;
  }
};

const authenticateMiddleware = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: No token provided' });
  }

  const token = authHeader.split(' ')[1];
  const decodedToken = verifyToken(token);

  if (!decodedToken) {
    return res.status(401).json({ error: 'Unauthorized: Invalid token' });
  }

  // @ts-ignore
  req.userId = decodedToken.userId;
  next();
};

// Hash password for storage
const hashPassword = (password: string): string => {
  return CryptoJS.SHA256(password).toString();
};

// API Routes

// User authentication
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  const user = mockDB.users.find(u => u.email === email);

  if (!user || hashPassword(password) !== user.password) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  // If MFA is enabled, require a token
  if (user.mfaEnabled) {
    return res.status(200).json({
      requiresMFA: true,
      userId: user.id,
      message: 'MFA verification required'
    });
  }

  // Generate JWT
  const token = generateToken(user.id);

  // Return user info (excluding sensitive data)
  const { password: _, mfaSecret: __, recoveryKeys: ___, ...userWithoutSensitiveData } = user;

  return res.status(200).json({
    token,
    user: userWithoutSensitiveData
  });
});

// MFA verification
app.post('/api/auth/verify-mfa', (req, res) => {
  const { userId, token } = req.body;

  if (!userId || !token) {
    return res.status(400).json({ error: 'User ID and token are required' });
  }

  const user = mockDB.users.find(u => u.id === userId);

  if (!user || !user.mfaEnabled || !user.mfaSecret) {
    return res.status(401).json({ error: 'Invalid user or MFA not enabled' });
  }

  // Verify MFA token
  const verified = speakeasy.totp.verify({
    secret: user.mfaSecret,
    encoding: 'base32',
    token: token
  });

  if (!verified) {
    return res.status(401).json({ error: 'Invalid MFA token' });
  }

  // Generate JWT
  const jwtToken = generateToken(user.id);

  // Return user info (excluding sensitive data)
  const { password: _, mfaSecret: __, recoveryKeys: ___, ...userWithoutSensitiveData } = user;

  return res.status(200).json({
    token: jwtToken,
    user: userWithoutSensitiveData
  });
});

// Setup MFA
app.post('/api/auth/setup-mfa', authenticateMiddleware, (req, res) => {
  // @ts-ignore
  const userId = req.userId;

  const userIndex = mockDB.users.findIndex(u => u.id === userId);

  if (userIndex === -1) {
    return res.status(404).json({ error: 'User not found' });
  }

  // Generate new MFA secret
  const secret = speakeasy.generateSecret({ length: 20 });

  // Generate recovery keys
  const recoveryKeys = Array(8).fill(0).map(() => {
    return `${Math.random().toString(36).substr(2, 4)}-${Math.random().toString(36).substr(2, 4)}-${Math.random().toString(36).substr(2, 4)}-${Math.random().toString(36).substr(2, 4)}`;
  });

  // Update user with new secret (not enabled yet)
  mockDB.users[userIndex] = {
    ...mockDB.users[userIndex],
    mfaSecret: secret.base32,
    recoveryKeys
  };

  return res.status(200).json({
    secret: secret.base32,
    otpAuthUrl: secret.otpauth_url,
    recoveryKeys
  });
});

// Verify and enable MFA
app.post('/api/auth/enable-mfa', authenticateMiddleware, (req, res) => {
  const { token } = req.body;
  // @ts-ignore
  const userId = req.userId;

  if (!token) {
    return res.status(400).json({ error: 'Token is required' });
  }

  const userIndex = mockDB.users.findIndex(u => u.id === userId);

  if (userIndex === -1 || !mockDB.users[userIndex].mfaSecret) {
    return res.status(404).json({ error: 'User not found or MFA not set up' });
  }

  // Verify MFA token
  const verified = speakeasy.totp.verify({
    secret: mockDB.users[userIndex].mfaSecret!,
    encoding: 'base32',
    token
  });

  if (!verified) {
    return res.status(401).json({ error: 'Invalid MFA token' });
  }

  // Enable MFA
  mockDB.users[userIndex].mfaEnabled = true;

  return res.status(200).json({
    message: 'MFA enabled successfully',
    mfaEnabled: true
  });
});

// Disable MFA
app.post('/api/auth/disable-mfa', authenticateMiddleware, (req, res) => {
  // @ts-ignore
  const userId = req.userId;

  const userIndex = mockDB.users.findIndex(u => u.id === userId);

  if (userIndex === -1) {
    return res.status(404).json({ error: 'User not found' });
  }

  // Disable MFA
  mockDB.users[userIndex].mfaEnabled = false;

  return res.status(200).json({
    message: 'MFA disabled successfully',
    mfaEnabled: false
  });
});

// Get user profile
app.get('/api/user/profile', authenticateMiddleware, (req, res) => {
  // @ts-ignore
  const userId = req.userId;

  const user = mockDB.users.find(u => u.id === userId);

  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  // Return user info (excluding sensitive data)
  const { password: _, mfaSecret: __, recoveryKeys: ___, ...userWithoutSensitiveData } = user;

  return res.status(200).json(userWithoutSensitiveData);
});

// Crypto payment verification
app.post('/api/payment/verify', authenticateMiddleware, (req, res) => {
  const { paymentMethod, amount, txHash, planId } = req.body;
  // @ts-ignore
  const userId = req.userId;

  if (!paymentMethod || !amount || !txHash || !planId) {
    return res.status(400).json({ error: 'Payment method, amount, transaction hash, and plan ID are required' });
  }

  // In a real app, this would verify the transaction on the blockchain
  // For demo purposes, we'll simulate a verification process

  // Get duration based on plan ID
  let durationDays = 0;
  switch(planId) {
    case 'daily':
      durationDays = 1;
      break;
    case 'monthly':
      durationDays = 30;
      break;
    case 'yearly':
      durationDays = 365;
      break;
    default:
      return res.status(400).json({ error: 'Invalid plan ID' });
  }

  // Calculate expiry date
  const expiryDate = new Date();
  expiryDate.setDate(expiryDate.getDate() + durationDays);

  // Update user subscription status
  const userIndex = mockDB.users.findIndex(u => u.id === userId);

  if (userIndex !== -1) {
    mockDB.users[userIndex].subscriptionStatus = 'premium';
    mockDB.users[userIndex].subscriptionExpiry = expiryDate.toISOString();
  }

  // Add transaction to mock DB
  mockDB.transactions.push({
    userId,
    paymentMethod,
    amount,
    txHash,
    planId,
    timestamp: new Date().toISOString(),
    status: 'confirmed'
  });

  return res.status(200).json({
    success: true,
    message: 'Payment verified successfully',
    subscriptionStatus: 'premium',
    subscriptionExpiry: expiryDate.toISOString()
  });
});

// IP and DNS verification endpoints
app.get('/api/verify/ip', (req, res) => {
  // In a real app, this would perform actual IP verification
  // For demo, we'll return mock data

  const ip = req.ip || '198.51.100.42'; // Example IP

  return res.status(200).json({
    ip,
    country: 'Switzerland',
    isp: 'Private VPN Service',
    proxy: true,
    tor: false,
    vpn: true,
    leaked: false
  });
});

app.get('/api/verify/dns', (req, res) => {
  // In a real app, this would perform actual DNS leak tests
  // For demo, we'll return mock data

  return res.status(200).json({
    dnsServers: [
      {
        server: '1.1.1.1',
        provider: 'Cloudflare',
        secure: true
      },
      {
        server: '9.9.9.9',
        provider: 'Quad9',
        secure: true
      }
    ],
    leakDetected: false,
    encrypted: true
  });
});

app.get('/api/verify/webrtc', (req, res) => {
  // In a real app, this would perform actual WebRTC leak tests
  // For demo, we'll return mock data

  return res.status(200).json({
    localIPs: ['192.168.1.1'],
    publicIP: null, // null means no leak detected
    leakDetected: false
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Backend server running on port ${PORT}`);
});
