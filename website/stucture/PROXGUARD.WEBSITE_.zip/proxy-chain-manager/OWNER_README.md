# Owner Access Guide

## Overview

As the owner of the Proxy Chain Manager repository, you have special privileges that allow you to bypass the payment verification system. This guide explains how to activate and use these privileges.

## Your Owner Keys

You have two owner keys that can be used to unlock owner access:

- Primary Key: `pcm-owner-21f35e92`
- Backup Key: `pcm-owner-auth-token`

Keep these keys secure and do not share them with anyone else.

## How to Activate Owner Access

### Method 1: Using the Payment Screen

If you encounter the payment screen:

1. Scroll down to the bottom of the payment modal
2. Look for the "Owner key" input field
3. Enter your owner key (`pcm-owner-21f35e92`)
4. Click "Verify"
5. The application will refresh with owner access enabled

### Method 2: Using the Browser Console (Recommended)

1. Open your browser's developer console
   - Chrome/Edge: Press F12 or right-click and select "Inspect" > "Console"
   - Firefox: Press F12 or right-click and select "Inspect Element" > "Console"
   - Safari: Enable developer tools in preferences, then right-click and select "Inspect Element"

2. Copy and paste the following code into the console:
   ```javascript
   // First, set up a function to load a module from the application
   function loadModule(path) {
     return import(window.location.origin + path).catch(e => {
       console.error('Failed to load module:', e);
       return null;
     });
   }

   // Then use it to load the owner access module
   loadModule('/src/utils/ownerAccess.js').then(module => {
     if (module) {
       module.grantOwnerAccess('pcm-owner-21f35e92');
     }
   });
   ```

3. Press Enter to execute the code
4. You should see a green success message
5. The page will automatically refresh with owner access enabled

## How to Check Owner Access Status

To check if you currently have owner access:

1. Open the developer console
2. Enter this code:
   ```javascript
   loadModule('/src/utils/ownerAccess.js').then(module => {
     if (module) {
       console.log('Owner access status:', module.checkOwnerAccess());
     }
   });
   ```

## How to Remove Owner Access

If you want to test the application as a regular user:

1. Open the developer console
2. Enter this code:
   ```javascript
   loadModule('/src/utils/ownerAccess.js').then(module => {
     if (module) {
       module.removeOwnerAccess();
     }
   });
   ```

3. The page will refresh with owner access disabled

## Technical Details

- Owner access is stored in your browser's localStorage
- It persists across browser sessions until you clear your browser data
- The owner verification happens client-side for simplicity
- In a production environment, you might want to implement server-side verification

## Distribution

When distributing this application to users:

1. They will be required to make payment to use the application
2. You, as the owner, can use your owner key to bypass this requirement
3. The payment system will work as designed for all other users

## Support

If you have any issues with the owner access system:

1. Check the browser console for any error messages
2. Verify that you are using the correct owner key
3. Try clearing your browser cache and trying again
4. The backup key can be used if the primary key doesn't work

Remember to keep your owner keys confidential to maintain the security of the payment system.
