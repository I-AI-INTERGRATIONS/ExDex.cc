const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files
app.use(express.static(path.join(__dirname)));

// All requests that don't match static files should serve index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
  console.log(`Visit: http://localhost:${PORT}`);
  console.log('Payment System is active');
});

// Log startup info
console.log('===========================');
console.log('PROXY CHAIN MANAGER SERVER');
console.log('===========================');
console.log('Version: 1.0.0');
console.log('Mode: Production');
console.log('Payment Required: Yes');
console.log('Crypto Addresses:');
console.log('- BTC: bc1q8nvdka59fah5tc2vydx7n0c500a5rp764ckvnqdqltw9ztq9wsgssy9jcr');
console.log('- ETH: 0x45fD9ba0c6a35a197dB8C8413b631C53386dC43D');
console.log('===========================');
