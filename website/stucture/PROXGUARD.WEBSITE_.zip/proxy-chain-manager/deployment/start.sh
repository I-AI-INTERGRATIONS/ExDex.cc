#!/bin/bash\necho \"Starting Proxy Chain Manager...\"\nnode server.js
