import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App.tsx";
// Import payment check system
import './lib/paymentCheck';

// Developer console message for bypassing payment
if (import.meta.env.DEV) {
  console.log(
    '%c 🔑 DEVELOPER MODE - PAYMENT BYPASS AVAILABLE 🔑',
    'background: #000; color: #00FF00; font-size: 14px; padding: 5px; font-weight: bold;'
  );
  console.log(
    '%c Run this in console to bypass payment: %c window.bypassPayment = () => { const userId = localStorage.getItem("userId") || "dev-" + Date.now(); localStorage.setItem("userId", userId); localStorage.setItem(`payment_verified_${userId}`, "true"); const endDate = new Date(); endDate.setFullYear(endDate.getFullYear() + 1); localStorage.setItem(`subscription_end_${userId}`, endDate.toISOString()); localStorage.setItem("activeSubscription", "true"); location.reload(); }',
    'color: #00FF00;',
    'color: #FFF; background: #333; padding: 3px;'
  );
  console.log('%c Then call: %c window.bypassPayment() ', 'color: #00FF00;', 'background: #00FF00; color: #000; font-weight: bold;');
}

const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Failed to find root element");
}

createRoot(rootElement).render(<App />);
