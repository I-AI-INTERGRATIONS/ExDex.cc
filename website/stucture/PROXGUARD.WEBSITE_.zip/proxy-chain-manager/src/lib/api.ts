// API client for the backend

const API_URL = 'http://localhost:4000/api';

// Helper to handle fetch responses
const handleResponse = async (response: Response) => {
  if (!response.ok) {
    const errorText = await response.text();
    try {
      const errorJson = JSON.parse(errorText);
      throw new Error(errorJson.error || 'An error occurred');
    } catch (e) {
      throw new Error(errorText || 'An error occurred');
    }
  }
  return response.json();
};

// Authentication APIs
export const loginUser = async (email: string, password: string) => {
  const response = await fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  return handleResponse(response);
};

export const verifyMFA = async (userId: string, token: string) => {
  const response = await fetch(`${API_URL}/auth/verify-mfa`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId, token }),
  });
  return handleResponse(response);
};

export const setupMFA = async (token: string) => {
  const response = await fetch(`${API_URL}/auth/setup-mfa`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
  });
  return handleResponse(response);
};

export const enableMFA = async (token: string, otpToken: string) => {
  const response = await fetch(`${API_URL}/auth/enable-mfa`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ token: otpToken }),
  });
  return handleResponse(response);
};

export const disableMFA = async (token: string) => {
  const response = await fetch(`${API_URL}/auth/disable-mfa`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
  });
  return handleResponse(response);
};

// User APIs
export const getUserProfile = async (token: string) => {
  const response = await fetch(`${API_URL}/user/profile`, {
    headers: {
      'Authorization': `Bearer ${token}`
    },
  });
  return handleResponse(response);
};

// Payment APIs
export const verifyPayment = async (token: string, paymentData: {
  paymentMethod: string;
  amount: string;
  txHash: string;
  planId: string;
}) => {
  const response = await fetch(`${API_URL}/payment/verify`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify(paymentData),
  });
  return handleResponse(response);
};

// Verification APIs
export const verifyIP = async () => {
  const response = await fetch(`${API_URL}/verify/ip`);
  return handleResponse(response);
};

export const verifyDNS = async () => {
  const response = await fetch(`${API_URL}/verify/dns`);
  return handleResponse(response);
};

export const verifyWebRTC = async () => {
  const response = await fetch(`${API_URL}/verify/webrtc`);
  return handleResponse(response);
};
