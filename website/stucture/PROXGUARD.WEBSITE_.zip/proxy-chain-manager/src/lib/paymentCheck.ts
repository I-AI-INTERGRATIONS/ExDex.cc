// Payment verification check
// This script runs on application initialization to verify if the user has a valid subscription

// Set this to true to bypass payment verification (FOR DEVELOPMENT ONLY)
export const BYPASS_PAYMENT = false;

// Admin credentials for bypassing payment
const ADMIN_EMAIL = 'finesseandcounterfits816@protonmail.com';
const ADMIN_ACCESS_KEY = 'admin-access-granted';

// Secret owner keys that will bypass payment requirement
const OWNER_KEYS = [
  'pcm-owner-21f35e92', // Your personal owner key
  'pcm-owner-auth-token' // Backup key
];

// Check if the current user is the owner or admin
export const isOwner = (): boolean => {
  try {
    // Check if admin access is granted
    if (localStorage.getItem(ADMIN_ACCESS_KEY) === 'true') {
      return true;
    }

    // Check if any owner key exists in localStorage
    return OWNER_KEYS.some(key => localStorage.getItem(key) === 'true');
  } catch (error) {
    return false;
  }
};

// Authenticate owner with a key
export const authenticateOwner = (key: string): boolean => {
  if (OWNER_KEYS.includes(key)) {
    localStorage.setItem(key, 'true');
    console.log('%c OWNER ACCESS GRANTED ', 'background: #00FF00; color: #000; font-weight: bold; padding: 2px 5px;');
    // Set owner subscription to 10 years by default
    const userId = localStorage.getItem('userId') || 'owner-' + Date.now();
    localStorage.setItem('userId', userId);
    localStorage.setItem(`payment_verified_${userId}`, 'true');

    // Set a very long subscription (10 years)
    const endDate = new Date();
    endDate.setFullYear(endDate.getFullYear() + 10);
    localStorage.setItem(`subscription_end_${userId}`, endDate.toISOString());
    localStorage.setItem('activeSubscription', 'true');

    return true;
  }
  return false;
};

// Authenticate using admin email
export const authenticateAdmin = (email: string): boolean => {
  if (email === ADMIN_EMAIL) {
    localStorage.setItem(ADMIN_ACCESS_KEY, 'true');
    console.log('%c ADMIN ACCESS GRANTED ', 'background: #0088FF; color: #FFF; font-weight: bold; padding: 2px 5px;');

    // Set admin subscription
    const userId = localStorage.getItem('userId') || 'admin-' + Date.now();
    localStorage.setItem('userId', userId);
    localStorage.setItem(`payment_verified_${userId}`, 'true');

    // Set a permanent subscription
    const endDate = new Date();
    endDate.setFullYear(endDate.getFullYear() + 100); // 100 years should be enough
    localStorage.setItem(`subscription_end_${userId}`, endDate.toISOString());
    localStorage.setItem('activeSubscription', 'true');

    return true;
  }
  return false;
};

// Check if user has an active subscription
export const checkActiveSubscription = (): boolean => {
  // If owner is authenticated, always return true
  if (isOwner()) {
    console.log('%c ADMIN/OWNER ACCESS: Payment verification bypassed ', 'background: #00AAFF; color: #000; font-weight: bold; padding: 2px 5px;');
    return true;
  }

  // If bypass is enabled, always return true (skip payment verification)
  if (BYPASS_PAYMENT) {
    console.log('DEVELOPMENT MODE: Payment verification bypassed');
    return true;
  }

  try {
    // Get user ID or generate anonymous ID
    const userId = localStorage.getItem('userId') || '';
    if (!userId) return false;

    // Check if payment is verified
    const paymentVerified = localStorage.getItem(`payment_verified_${userId}`);
    if (paymentVerified !== 'true') return false;

    // Check subscription end date
    const subscriptionEndStr = localStorage.getItem(`subscription_end_${userId}`);
    if (!subscriptionEndStr) return false;

    // Verify the subscription is not expired
    const subscriptionEnd = new Date(subscriptionEndStr);
    const now = new Date();

    if (subscriptionEnd <= now) {
      // Subscription has expired
      localStorage.removeItem(`payment_verified_${userId}`);
      localStorage.removeItem('activeSubscription');
      console.log('Subscription expired. Payment required to continue using the application.');
      return false;
    }

    // Subscription is active
    return true;
  } catch (error) {
    console.error('Error checking subscription status:', error);
    return false;
  }
};

// Redirect to payment page if subscription is not active
export const enforcePaymentRequirement = (): void => {
  const isSubscriptionActive = checkActiveSubscription();

  if (!isSubscriptionActive) {
    // In a real application, redirect to payment page
    console.log('No active subscription found. Redirecting to payment page...');

    // Create admin login bubble that floats at the bottom right
    const adminBubble = document.createElement('div');
    adminBubble.className = 'admin-login-bubble';
    adminBubble.innerHTML = `
      <div class="admin-bubble-icon">A</div>
      <div class="admin-login-panel">
        <h3>Admin Access</h3>
        <input type="email" id="admin-email" placeholder="Admin Email" class="admin-input" />
        <button id="admin-login-btn">Login</button>
      </div>
    `;
    document.body.appendChild(adminBubble);

    // Add styling for the admin bubble
    const adminStyle = document.createElement('style');
    adminStyle.textContent = `
      .admin-login-bubble {
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 10000;
      }

      .admin-bubble-icon {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background-color: #003366;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        cursor: pointer;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        transition: all 0.3s ease;
      }

      .admin-bubble-icon:hover {
        background-color: #0055aa;
        transform: scale(1.1);
      }

      .admin-login-panel {
        position: absolute;
        bottom: 50px;
        right: 0;
        width: 220px;
        background-color: #1a1a1a;
        border: 1px solid #0088FF;
        border-radius: 8px;
        padding: 15px;
        display: none;
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
      }

      .admin-login-panel h3 {
        margin-top: 0;
        margin-bottom: 10px;
        color: #0088FF;
        font-size: 14px;
      }

      .admin-input {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
        background-color: #222;
        border: 1px solid #444;
        border-radius: 4px;
        color: white;
        font-size: 12px;
      }

      .admin-login-panel button {
        width: 100%;
        padding: 8px;
        background-color: #0088FF;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-weight: bold;
      }

      .admin-login-panel button:hover {
        background-color: #0099FF;
      }
    `;
    document.head.appendChild(adminStyle);

    // Fix TypeScript errors in the admin panel code
    setTimeout(() => {
      const bubbleIcon = document.querySelector('.admin-bubble-icon');
      const loginPanel = document.querySelector('.admin-login-panel') as HTMLElement;

      bubbleIcon?.addEventListener('click', () => {
        if (loginPanel) {
          loginPanel.style.display = loginPanel.style.display === 'block' ? 'none' : 'block';
        }
      });

      document.getElementById('admin-login-btn')?.addEventListener('click', () => {
        const emailInput = document.getElementById('admin-email') as HTMLInputElement;
        if (emailInput && authenticateAdmin(emailInput.value)) {
          // Hide admin panel
          if (loginPanel) loginPanel.style.display = 'none';

          // Refresh the page to apply admin access
          window.location.reload();
        } else {
          // Invalid email
          alert('Invalid admin credentials.');
        }
      });
    }, 100);

    // For now, we'll just display a payment required modal
    const paymentRequired = document.createElement('div');
    paymentRequired.className = 'payment-required-overlay';
    paymentRequired.innerHTML = `
      <div class="payment-required-modal">
        <h2>Payment Required</h2>
        <p>Your subscription has expired or you haven't subscribed yet.</p>
        <p>Please make a payment to continue using the application.</p>
        <button id="goto-payment-btn">Subscribe Now</button>
      </div>
    `;

    document.body.appendChild(paymentRequired);

    // Add styling
    const style = document.createElement('style');
    style.textContent = `
      .payment-required-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
      }

      .payment-required-modal {
        background-color: #1a1a1a;
        border: 2px solid #00FF00;
        padding: 2rem;
        border-radius: 0.5rem;
        max-width: 400px;
        text-align: center;
        color: #00FF00;
        box-shadow: 0 0 20px rgba(0, 255, 0, 0.5);
      }

      .payment-required-modal h2 {
        margin-top: 0;
        font-family: 'JetBrains Mono', monospace;
      }

      .payment-required-modal button {
        background-color: #00FF00;
        color: black;
        border: none;
        padding: 0.75rem 1.5rem;
        margin-top: 1rem;
        border-radius: 0.25rem;
        cursor: pointer;
        font-weight: bold;
        transition: all 0.2s;
      }

      .payment-required-modal button:hover {
        background-color: #00CC00;
        box-shadow: 0 0 10px rgba(0, 255, 0, 0.7);
      }
    `;

    document.head.appendChild(style);

    // Add event listener to the button
    document.getElementById('goto-payment-btn')?.addEventListener('click', () => {
      // In a real app, this would redirect to your payment page
      // For now, just hide the modal
      paymentRequired.style.display = 'none';
    });
  }
};

// Auto-run payment check when imported
export const initPaymentCheck = (): void => {
  // Run on page load
  if (typeof window !== 'undefined') {
    window.addEventListener('DOMContentLoaded', () => {
      enforcePaymentRequirement();
    });
  }
};

// Initialize payment check
initPaymentCheck();
