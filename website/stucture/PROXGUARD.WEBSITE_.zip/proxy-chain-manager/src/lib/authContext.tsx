import type React from 'react';
import { createContext, useContext, useState, useEffect, type ReactNode } from 'react'

interface User {
  id: string;
  email: string;
  name: string;
  subscriptionStatus: 'free' | 'premium' | 'trial';
  subscriptionExpiry?: Date;
  lastLogin: Date;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  error: string | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  resetError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user data for development
const MOCK_USERS = [
  {
    id: '1',
    email: 'demo@example.com',
    password: 'password123',
    name: 'Demo User',
    subscriptionStatus: 'free' as const,
    lastLogin: new Date(),
  },
  {
    id: '2',
    email: 'premium@example.com',
    password: 'password123',
    name: 'Premium User',
    subscriptionStatus: 'premium' as const,
    subscriptionExpiry: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
    lastLogin: new Date(),
  },
];

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Check for saved auth state in localStorage
    const savedUser = localStorage.getItem('proxyChainUser');
    if (savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser);
        setUser(parsedUser);
      } catch (e) {
        console.error('Failed to parse saved user:', e);
        localStorage.removeItem('proxyChainUser');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    setError(null);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // In a real app, this would be an API call
      const matchedUser = MOCK_USERS.find(
        u => u.email.toLowerCase() === email.toLowerCase() && u.password === password
      );

      if (!matchedUser) {
        throw new Error('Invalid email or password');
      }

      // Remove password field before storing user
      const { password: _, ...userWithoutPassword } = matchedUser;
      const authenticatedUser = {
        ...userWithoutPassword,
        lastLogin: new Date(),
      };

      setUser(authenticatedUser as User);
      localStorage.setItem('proxyChainUser', JSON.stringify(authenticatedUser));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (name: string, email: string, password: string) => {
    setIsLoading(true);
    setError(null);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Check if user already exists
      const existingUser = MOCK_USERS.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (existingUser) {
        throw new Error('An account with this email already exists');
      }

      // In a real app, this would create a new user via API
      const newUser = {
        id: String(MOCK_USERS.length + 1),
        email,
        name,
        subscriptionStatus: 'free' as const,
        lastLogin: new Date(),
      };

      setUser(newUser);
      localStorage.setItem('proxyChainUser', JSON.stringify(newUser));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('proxyChainUser');
  };

  const resetError = () => {
    setError(null);
  };

  const value = {
    user,
    isLoading,
    error,
    isAuthenticated: !!user,
    login,
    register,
    logout,
    resetError,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
