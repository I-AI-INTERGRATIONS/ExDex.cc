import React, { useState, useEffect } from 'react';
import { useAuth } from '../../lib/authContext';
import { useNotifications } from '../../lib/notificationContext';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import QRCode from '../ui/QRCode';

export const MFASetup = () => {
  const { user, isAuthenticated } = useAuth();
  const { addNotification } = useNotifications();
  const [setupStep, setSetupStep] = useState<'idle' | 'qrcode' | 'verification'>('idle');
  const [mfaEnabled, setMfaEnabled] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');
  const [recoveryKeys, setRecoveryKeys] = useState<string[]>([]);

  // Mock secret key - in a real application, this would be generated securely server-side
  const secretKey = 'KA7OQJZ7OIVOQVIN5DJVLU6Q5RFQBFVZ';

  // Format the QR code data for TOTP
  const qrCodeData = `otpauth://totp/ProxyChainManager:${user?.email}?secret=${secretKey}&issuer=ProxyChainManager`;

  const generateRecoveryKeys = () => {
    // In a real app, these would be randomly generated and stored securely
    const keys = [];
    for (let i = 0; i < 8; i++) {
      keys.push(`${Math.random().toString(36).substr(2, 4)}-${Math.random().toString(36).substr(2, 4)}-${Math.random().toString(36).substr(2, 4)}-${Math.random().toString(36).substr(2, 4)}`);
    }
    return keys;
  };

  const startMFASetup = () => {
    setSetupStep('qrcode');
    setRecoveryKeys(generateRecoveryKeys());
  };

  const verifyAndEnable = () => {
    // In a real app, we would verify the code against the secret key
    if (verificationCode.length === 6 && /^\d+$/.test(verificationCode)) {
      setMfaEnabled(true);
      setSetupStep('idle');
      addNotification({
        type: 'success',
        title: 'MFA Enabled',
        message: 'Multi-factor authentication has been successfully enabled for your account.',
      });
    } else {
      addNotification({
        type: 'error',
        title: 'Invalid Code',
        message: 'The verification code you entered is invalid. Please try again.',
      });
    }
  };

  const disableMFA = () => {
    // In a real app, we would require password confirmation here
    setMfaEnabled(false);
    addNotification({
      type: 'success',
      title: 'MFA Disabled',
      message: 'Multi-factor authentication has been disabled for your account.',
    });
  };

  if (!isAuthenticated) {
    return (
      <div className="rounded-lg border border-primary-darker bg-background p-6">
        <p className="text-center text-muted-foreground">
          You need to be logged in to manage multi-factor authentication.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-primary-darker bg-background p-6">
      <h2 className="mb-4 text-xl font-bold text-foreground">Multi-Factor Authentication</h2>

      {setupStep === 'idle' && (
        <div>
          <p className="mb-4 text-muted-foreground">
            {mfaEnabled
              ? 'Multi-factor authentication is enabled for your account. This adds an extra layer of security.'
              : 'Add an extra layer of security to your account by enabling multi-factor authentication. You\'ll need an authenticator app on your phone.'}
          </p>

          {mfaEnabled ? (
            <Button variant="danger" onClick={disableMFA}>
              Disable MFA
            </Button>
          ) : (
            <Button variant="primary" onClick={startMFASetup}>
              Set Up MFA
            </Button>
          )}
        </div>
      )}

      {setupStep === 'qrcode' && (
        <div>
          <p className="mb-4 text-muted-foreground">
            Scan this QR code with your authenticator app (like Google Authenticator, Authy, or Microsoft Authenticator).
          </p>

          <div className="mb-6 flex justify-center">
            <QRCode
              value={qrCodeData}
              size={200}
              className="rounded-md p-3 bg-white"
              level="H"
              includeMargin={true}
            />
          </div>

          <div className="mb-6">
            <p className="mb-2 text-sm font-medium text-foreground">Manual Entry Code:</p>
            <code className="block w-full select-all rounded-md bg-primary-darker/20 p-3 font-mono text-foreground">
              {secretKey}
            </code>
            <p className="mt-2 text-xs text-muted-foreground">
              If you can't scan the QR code, you can manually enter this code into your authenticator app.
            </p>
          </div>

          <div className="mb-6">
            <h3 className="mb-2 text-md font-medium text-foreground">Recovery Keys</h3>
            <p className="mb-3 text-sm text-muted-foreground">
              Save these recovery keys in a secure place. They can be used to regain access to your account if you lose your authenticator device.
            </p>
            <div className="mb-4 grid grid-cols-2 gap-2">
              {recoveryKeys.map((key, index) => (
                <code key={`recovery-${index}`} className="select-all rounded-md bg-primary-darker/20 p-2 font-mono text-xs text-foreground">
                  {key}
                </code>
              ))}
            </div>
            <p className="text-xs text-error-red">
              Important: These recovery keys will only be shown once. Make sure you save them now.
            </p>
          </div>

          <div className="flex space-x-3">
            <Button variant="primary" onClick={() => setSetupStep('verification')}>
              Continue
            </Button>
            <Button variant="secondary" onClick={() => setSetupStep('idle')}>
              Cancel
            </Button>
          </div>
        </div>
      )}

      {setupStep === 'verification' && (
        <div>
          <p className="mb-4 text-muted-foreground">
            Enter the verification code from your authenticator app to complete the setup.
          </p>

          <div className="mb-6">
            <Input
              label="Verification Code"
              placeholder="Enter 6-digit code"
              value={verificationCode}
              onChange={(e) => setVerificationCode(e.target.value.trim())}
              maxLength={6}
              className="font-mono text-lg tracking-widest"
            />
          </div>

          <div className="flex space-x-3">
            <Button
              variant="primary"
              onClick={verifyAndEnable}
              disabled={verificationCode.length !== 6}
            >
              Verify and Enable
            </Button>
            <Button variant="secondary" onClick={() => setSetupStep('qrcode')}>
              Back
            </Button>
            <Button variant="ghost" onClick={() => setSetupStep('idle')}>
              Cancel
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};
