import type React from 'react';
import { useState } from 'react';
import { useAuth } from '../../lib/authContext';
import { LockIcon } from '../icons/Icons';

interface RegisterFormProps {
  onSuccess?: () => void;
  onLoginClick?: () => void;
}

export const RegisterForm = ({ onSuccess, onLoginClick }: RegisterFormProps) => {
  const { register, isLoading, error, resetError } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Reset errors
    setPasswordError('');

    // Validate passwords match
    if (password !== confirmPassword) {
      setPasswordError('Passwords do not match');
      return;
    }

    try {
      await register(name, email, password);
      if (onSuccess) onSuccess();
    } catch (error) {
      console.error('Registration failed:', error);
    }
  };

  return (
    <div className="mx-auto w-full max-w-md rounded-lg border border-primary-darker bg-background p-6">
      <div className="mb-6 flex items-center justify-center">
        <div className="mr-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary/20">
          <LockIcon size={20} className="text-primary" />
        </div>
        <h2 className="text-xl font-bold text-foreground">Create Account</h2>
      </div>

      {error && (
        <div className="mb-4 rounded-md bg-error-red/10 p-3 text-sm text-error-red">
          <p>{error}</p>
          <button
            onClick={resetError}
            className="mt-1 text-xs underline"
          >
            Dismiss
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="name" className="mb-1 block text-sm font-medium text-foreground">
            Full Name
          </label>
          <input
            id="name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="input w-full"
            placeholder="John Doe"
            required
          />
        </div>

        <div className="mb-4">
          <label htmlFor="email" className="mb-1 block text-sm font-medium text-foreground">
            Email
          </label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="input w-full"
            placeholder="your@email.com"
            required
          />
        </div>

        <div className="mb-4">
          <label htmlFor="password" className="mb-1 block text-sm font-medium text-foreground">
            Password
          </label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className={`input w-full ${passwordError ? 'border-error-red' : ''}`}
            placeholder="••••••••"
            required
            minLength={8}
          />
        </div>

        <div className="mb-6">
          <label htmlFor="confirmPassword" className="mb-1 block text-sm font-medium text-foreground">
            Confirm Password
          </label>
          <input
            id="confirmPassword"
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className={`input w-full ${passwordError ? 'border-error-red' : ''}`}
            placeholder="••••••••"
            required
          />
          {passwordError && (
            <div className="mt-1 text-xs text-error-red">{passwordError}</div>
          )}
        </div>

        <button
          type="submit"
          className="btn btn-primary w-full"
          disabled={isLoading}
        >
          {isLoading ? 'Creating account...' : 'Create Account'}
        </button>
      </form>

      <div className="mt-6 text-center text-sm">
        <p className="text-muted-foreground">
          Already have an account?{' '}
          <button
            onClick={onLoginClick}
            className="text-primary hover:underline"
          >
            Sign in
          </button>
        </p>
      </div>
    </div>
  );
};
