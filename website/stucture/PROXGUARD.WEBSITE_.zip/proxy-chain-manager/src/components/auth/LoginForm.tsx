import type React from 'react';
import { useState } from 'react';
import { useAuth } from '../../lib/authContext';
import { LockIcon } from '../icons/Icons';

interface LoginFormProps {
  onSuccess?: () => void;
  onRegisterClick?: () => void;
}

export const LoginForm = ({ onSuccess, onRegisterClick }: LoginFormProps) => {
  const { login, isLoading, error, resetError } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      await login(email, password);
      if (onSuccess) onSuccess();
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  return (
    <div className="mx-auto w-full max-w-md rounded-lg border border-primary-darker bg-background p-6">
      <div className="mb-6 flex items-center justify-center">
        <div className="mr-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary/20">
          <LockIcon size={20} className="text-primary" />
        </div>
        <h2 className="text-xl font-bold text-foreground">Sign In</h2>
      </div>

      {error && (
        <div className="mb-4 rounded-md bg-error-red/10 p-3 text-sm text-error-red">
          <p>{error}</p>
          <button
            onClick={resetError}
            className="mt-1 text-xs underline"
          >
            Dismiss
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="email" className="mb-1 block text-sm font-medium text-foreground">
            Email
          </label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="input w-full"
            placeholder="your@email.com"
            required
          />
        </div>

        <div className="mb-6">
          <label htmlFor="password" className="mb-1 block text-sm font-medium text-foreground">
            Password
          </label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input w-full"
            placeholder="••••••••"
            required
          />
          <div className="mt-1 text-right">
            <button
              type="button"
              className="text-xs text-primary hover:underline"
            >
              Forgot password?
            </button>
          </div>
        </div>

        <button
          type="submit"
          className="btn btn-primary w-full"
          disabled={isLoading}
        >
          {isLoading ? 'Signing in...' : 'Sign In'}
        </button>
      </form>

      <div className="mt-6 text-center text-sm">
        <p className="text-muted-foreground">
          Don't have an account?{' '}
          <button
            onClick={onRegisterClick}
            className="text-primary hover:underline"
          >
            Sign up
          </button>
        </p>
      </div>

      <div className="mt-6 border-t border-primary-darker pt-6">
        <p className="mb-2 text-center text-xs text-muted-foreground">
          Demo accounts:
        </p>
        <div className="flex flex-col gap-2 text-xs">
          <button
            type="button"
            onClick={() => {
              setEmail('demo@example.com');
              setPassword('password123');
            }}
            className="rounded-md border border-primary-darker px-3 py-2 text-left hover:border-primary"
          >
            <div className="font-medium">Free Account</div>
            <div className="text-muted-foreground">demo@example.com / password123</div>
          </button>
          <button
            type="button"
            onClick={() => {
              setEmail('premium@example.com');
              setPassword('password123');
            }}
            className="rounded-md border border-primary-darker px-3 py-2 text-left hover:border-primary"
          >
            <div className="font-medium">Premium Account</div>
            <div className="text-muted-foreground">premium@example.com / password123</div>
          </button>
        </div>
      </div>
    </div>
  );
};
