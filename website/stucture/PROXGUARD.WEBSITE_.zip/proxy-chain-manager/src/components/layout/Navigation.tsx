import type React from 'react';
import { useState } from 'react';
import { useAuth } from '../../lib/authContext';
import {
  ProxyChainIcon,
  DNSChangerIcon,
  SystemStatusIcon,
  PrivacyFeatureIcon,
  WalletIcon,
  LockIcon,
  SecureLinkIcon
} from '../icons/Icons';
import { ThemeToggle } from '../ui/ThemeToggle';

type NavItem = {
  title: string;
  icon: React.ReactNode;
  path: string;
  requiresAuth?: boolean;
  requiresPremium?: boolean;
};

type NavigationProps = {
  currentPage?: string;
  // Make the navigate prop accept any function that takes a string
  navigate?: (path: any) => void;
};

export const Navigation = ({ currentPage = 'dashboard', navigate }: NavigationProps) => {
  const { isAuthenticated, user, logout } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const navItems: NavItem[] = [
    {
      title: 'Dashboard',
      icon: <SystemStatusIcon size={20} />,
      path: 'dashboard',
    },
    {
      title: 'Proxy Config',
      icon: <ProxyChainIcon size={20} />,
      path: 'proxy',
      requiresAuth: true,
    },
    {
      title: 'Security Suite',
      icon: <SecureLinkIcon size={20} />,
      path: 'privacy',
      requiresAuth: true,
    },
    {
      title: 'IP & DNS Verifier',
      icon: <DNSChangerIcon size={20} />,
      path: 'verifier',
    },
    {
      title: 'Analytics',
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="20"
          height="20"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M3 3v18h18" />
          <path d="M18 9l-6-6-7 7" />
          <path d="M18 4v5h-5" />
        </svg>
      ),
      path: 'analytics',
      requiresAuth: true,
      requiresPremium: true,
    },
    {
      title: 'Account',
      icon: <WalletIcon size={20} />,
      path: 'account',
      requiresAuth: true,
    },
    {
      title: 'Subscription',
      icon: <LockIcon size={20} />,
      path: 'subscription',
      requiresAuth: true,
    },
  ];

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const navigateTo = (path: string) => {
    if (navigate) {
      navigate(path);
    } else {
      // In a real app, we would use router navigation here
      console.log(`Navigating to: ${path}`);
    }
    setIsOpen(false);
  };

  return (
    <nav className="border-b border-primary-darker/60 bg-card/30 backdrop-blur-md">
      <div className="container mx-auto px-4">
        <div className="relative flex h-14 items-center justify-between">
          {/* Mobile menu button */}
          <button
            onClick={toggleMenu}
            className="inline-flex items-center justify-center rounded-md p-2 text-foreground hover:bg-primary/10 hover:text-primary focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary md:hidden"
          >
            <span className="sr-only">Open main menu</span>
            <div className="space-y-1.5">
              <span className={`block h-0.5 w-6 rounded-sm bg-primary transition-transform ${isOpen ? 'translate-y-2 rotate-45' : ''}`} />
              <span className={`block h-0.5 w-6 rounded-sm bg-primary transition-opacity ${isOpen ? 'opacity-0' : ''}`} />
              <span className={`block h-0.5 w-6 rounded-sm bg-primary transition-transform ${isOpen ? '-translate-y-2 -rotate-45' : ''}`} />
            </div>
          </button>

          {/* Desktop navigation */}
          <div className="hidden md:block">
            <div className="flex space-x-4">
              {navItems.map((item) => {
                // Skip items that require authentication if user is not authenticated
                if (item.requiresAuth && !isAuthenticated) return null;

                // Skip premium items if user doesn't have premium
                if (item.requiresPremium && user?.subscriptionStatus !== 'premium') return null;

                const isActive = currentPage === item.path;

                return (
                  <button
                    key={item.path}
                    onClick={() => navigateTo(item.path)}
                    className={`flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium
                      ${isActive
                        ? 'bg-primary/10 text-primary'
                        : 'text-foreground hover:bg-primary/5 hover:text-primary'}`}
                  >
                    <span className={isActive ? 'text-primary' : 'text-muted-foreground'}>{item.icon}</span>
                    {item.title}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Authentication buttons and theme toggle */}
          <div className="flex items-center gap-2">
            <ThemeToggle />

            {isAuthenticated ? (
              <div className="flex items-center gap-3">
                <span className="hidden text-sm text-foreground md:block">
                  Hello, {user?.name}
                </span>
                <span className={`hidden rounded-full px-2 py-1 text-xs font-medium md:block ${
                  user?.subscriptionStatus === 'premium'
                    ? 'bg-gradient-to-r from-primary to-secondary text-white'
                    : 'bg-primary-darker/80 text-foreground'
                }`}>
                  {user?.subscriptionStatus === 'premium' ? 'PREMIUM' : 'FREE'}
                </span>
                <button
                  onClick={logout}
                  className="rounded-md border border-primary-darker/80 bg-card/50 px-3 py-1 text-sm text-foreground hover:border-primary hover:bg-primary/5 hover:text-primary"
                >
                  Sign Out
                </button>
              </div>
            ) : (
              <div className="flex gap-2">
                <button
                  onClick={() => navigateTo('login')}
                  className="rounded-md border border-primary-darker/80 bg-card/50 px-3 py-1 text-sm text-foreground hover:border-primary hover:bg-primary/10 hover:text-primary"
                >
                  Sign In
                </button>
                <button
                  onClick={() => navigateTo('register')}
                  className="rounded-md bg-gradient-to-r from-primary to-secondary px-3 py-1 text-sm text-white shadow hover:opacity-90"
                >
                  Sign Up
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden">
          <div className="space-y-1 px-2 pb-3 pt-2">
            {navItems.map((item) => {
              // Skip items that require authentication if user is not authenticated
              if (item.requiresAuth && !isAuthenticated) return null;

              // Skip premium items if user doesn't have premium
              if (item.requiresPremium && user?.subscriptionStatus !== 'premium') return null;

              const isActive = currentPage === item.path;

              return (
                <button
                  key={item.path}
                  onClick={() => navigateTo(item.path)}
                  className={`flex w-full items-center gap-2 rounded-md px-3 py-2 text-base font-medium
                    ${isActive
                      ? 'bg-primary/10 text-primary'
                      : 'text-foreground hover:bg-primary/5 hover:text-primary'}`}
                >
                  <span className={isActive ? 'text-primary' : 'text-muted-foreground'}>{item.icon}</span>
                  {item.title}
                </button>
              );
            })}

            {isAuthenticated && (
              <div className="mt-4 border-t border-primary-darker/50 pt-4">
                <div className="px-3 py-2">
                  <p className="text-sm text-foreground">Signed in as:</p>
                  <p className="font-medium text-primary">{user?.email}</p>
                  <div className="mt-2 flex items-center gap-2">
                    <span className={`rounded-full px-2 py-1 text-xs font-medium ${
                      user?.subscriptionStatus === 'premium'
                        ? 'bg-gradient-to-r from-primary to-secondary text-white'
                        : 'bg-primary-darker/80 text-foreground'
                    }`}>
                      {user?.subscriptionStatus === 'premium' ? 'PREMIUM' : 'FREE'}
                    </span>
                    {user?.subscriptionStatus !== 'premium' && (
                      <button
                        onClick={() => navigateTo('subscription')}
                        className="text-xs text-primary hover:underline"
                      >
                        Upgrade
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};
