import React, { useState } from 'react';
import { ProxyChainIcon, SecureLinkIcon } from '../icons/Icons';
import { useTheme } from '../../lib/themeContext';

export const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const { theme } = useTheme();

  return (
    <header className="sticky top-0 z-10 border-b border-primary-darker bg-background/90 backdrop-blur-md">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-3">
          <div className="flex items-center">
            <ProxyChainIcon size={30} className="text-primary" />
            <div className="ml-1 h-6 w-[2px] bg-secondary/70"></div>
            <SecureLinkIcon size={20} className="ml-1 text-accent animate-pulse-glow" />
          </div>
          <div>
            <h1 className="font-display text-xl font-bold text-foreground md:text-2xl">
              <span className="text-primary">Prox</span>
              <span className="text-secondary">Guard</span>
              <span className="text-muted-foreground font-normal"> v1.0</span>
            </h1>
            <p className="text-xs text-green-400">OPSEC PRE-RELEASE OF EXDEX</p>
          </div>
        </div>

        {/* Desktop status badges */}
        <div className="hidden items-center gap-4 md:flex">
          <div className="rounded-md border border-primary-darker/60 bg-card/70 px-3 py-1 text-sm">
            <span className="mr-2 text-muted-foreground">PROXY:</span>
            <span className="text-foreground font-medium">
              <span className="inline-block h-2 w-2 rounded-full bg-green-500 mr-1"></span>
              ACTIVE
            </span>
          </div>
          <div className="rounded-md border border-primary-darker/60 bg-card/70 px-3 py-1 text-sm">
            <span className="mr-2 text-muted-foreground">SECURITY:</span>
            <span className="text-foreground font-medium">
              <span className="inline-block h-2 w-2 rounded-full bg-green-500 mr-1"></span>
              ENHANCED
            </span>
          </div>
        </div>

        {/* Mobile menu button */}
        <button
          className="flex h-10 w-10 items-center justify-center rounded-md border border-primary-darker bg-card/80 md:hidden"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <div className="space-y-1.5">
            <span className={`block h-0.5 w-6 rounded-sm bg-primary transition-transform ${menuOpen ? 'translate-y-2 rotate-45' : ''}`} />
            <span className={`block h-0.5 w-6 rounded-sm bg-primary transition-opacity ${menuOpen ? 'opacity-0' : ''}`} />
            <span className={`block h-0.5 w-6 rounded-sm bg-primary transition-transform ${menuOpen ? '-translate-y-2 -rotate-45' : ''}`} />
          </div>
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="border-b border-primary-darker bg-card/90 py-4 md:hidden">
          <div className="container mx-auto flex flex-col space-y-3 px-4">
            <div className="rounded-md border border-primary-darker/60 bg-background/60 px-3 py-2">
              <span className="mr-2 text-muted-foreground">PROXY STATUS:</span>
              <span className="text-foreground">
                <span className="inline-block h-2 w-2 rounded-full bg-green-500 mr-1"></span>
                ACTIVE
              </span>
            </div>
            <div className="rounded-md border border-primary-darker/60 bg-background/60 px-3 py-2">
              <span className="mr-2 text-muted-foreground">SECURITY STATUS:</span>
              <span className="text-foreground">
                <span className="inline-block h-2 w-2 rounded-full bg-green-500 mr-1"></span>
                ENHANCED
              </span>
            </div>
            <div className="rounded-md border border-primary-darker/60 bg-background/60 px-3 py-2">
              <span className="mr-2 text-muted-foreground">NODES:</span>
              <span className="text-foreground">
                <span className="inline-block h-2 w-2 rounded-full bg-accent mr-1"></span>
                4 (4 ACTIVE)
              </span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
