import React, { type ReactNode } from 'react';
import { Header } from './Header';

interface DashboardProps {
  children: ReactNode;
}

export const Dashboard = ({ children }: DashboardProps) => {
  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      <Header />
      <main className="container mx-auto flex-1 p-2 sm:p-4">
        {children}
      </main>
      <footer className="border-t border-primary-darker bg-background/80 py-3 text-center text-xs sm:py-4 sm:text-sm text-muted-foreground backdrop-blur-md">
        <div className="container mx-auto px-4">
          <p>© {new Date().getFullYear()} Proxy Chain Manager | All Rights Reserved</p>
          <p className="mt-1 text-xs">Version 1.1.0</p>
        </div>
      </footer>
    </div>
  );
};
