import React, { useState, useEffect } from 'react';
import { useAuth } from '../../lib/authContext';

// For a real implementation, we would use a charting library like Chart.js or Recharts
// This is a simplified version for demonstration purposes

type DataPoint = {
  timestamp: string;
  value: number;
};

type ProxyStats = {
  uptime: string;
  connectedClients: number;
  totalTraffic: string;
  avgLatency: string;
  successRate: number;
  bandwidthUsage: DataPoint[];
  latencyData: DataPoint[];
  serverLoad: DataPoint[];
  connectionTypes: {
    http: number;
    https: number;
    socks: number;
  };
  topDestinations: {
    domain: string;
    count: number;
    percentage: number;
  }[];
};

export const AnalyticsDashboard = () => {
  const { user, isAuthenticated } = useAuth();
  const [stats, setStats] = useState<ProxyStats | null>(null);
  const [timeRange, setTimeRange] = useState<'24h' | '7d' | '30d' | '90d'>('24h');
  const [isLoading, setIsLoading] = useState(true);

  // Mock data generation for demonstration
  useEffect(() => {
    const generateMockData = () => {
      // Generate 24 data points for the charts (hourly data for 24h)
      const hours = timeRange === '24h' ? 24 : timeRange === '7d' ? 168 : timeRange === '30d' ? 720 : 2160;
      const interval = timeRange === '24h' ? 1 : timeRange === '7d' ? 6 : timeRange === '30d' ? 24 : 72;

      const bandwidthData: DataPoint[] = [];
      const latencyData: DataPoint[] = [];
      const serverLoadData: DataPoint[] = [];

      const now = new Date();

      for (let i = 0; i < hours; i += interval) {
        const date = new Date(now.getTime() - i * 60 * 60 * 1000);

        // Generate random data points with some "realism"
        bandwidthData.unshift({
          timestamp: date.toISOString(),
          value: Math.floor(Math.random() * 500) + 500, // 500-1000 KB/s
        });

        latencyData.unshift({
          timestamp: date.toISOString(),
          value: Math.floor(Math.random() * 50) + 30, // 30-80ms
        });

        serverLoadData.unshift({
          timestamp: date.toISOString(),
          value: Math.floor(Math.random() * 20) + 10, // 10-30%
        });
      }

      // Generate mock statistics
      const mockStats: ProxyStats = {
        uptime: '99.98%',
        connectedClients: Math.floor(Math.random() * 50) + 10,
        totalTraffic: `${(Math.random() * 100).toFixed(2)} GB`,
        avgLatency: `${Math.floor(Math.random() * 20) + 40}ms`,
        successRate: 99.7 + Math.random() * 0.3,
        bandwidthUsage: bandwidthData,
        latencyData: latencyData,
        serverLoad: serverLoadData,
        connectionTypes: {
          http: Math.floor(Math.random() * 100) + 200,
          https: Math.floor(Math.random() * 300) + 400,
          socks: Math.floor(Math.random() * 50) + 50,
        },
        topDestinations: [
          {
            domain: 'api.example.com',
            count: Math.floor(Math.random() * 1000) + 2000,
            percentage: 28.5,
          },
          {
            domain: 'cdn.provider.net',
            count: Math.floor(Math.random() * 800) + 1500,
            percentage: 21.2,
          },
          {
            domain: 'data.service.org',
            count: Math.floor(Math.random() * 600) + 1000,
            percentage: 15.8,
          },
          {
            domain: 'api.another-service.com',
            count: Math.floor(Math.random() * 400) + 800,
            percentage: 11.3,
          },
          {
            domain: 'images.cdn.com',
            count: Math.floor(Math.random() * 300) + 500,
            percentage: 7.6,
          },
        ],
      };

      return mockStats;
    };

    // Simulate API call
    setIsLoading(true);
    setTimeout(() => {
      setStats(generateMockData());
      setIsLoading(false);
    }, 1000);
  }, [timeRange]);

  // Simple bar chart component
  const BarChart = ({ data, height = 100, color = "#4f46e5" }: { data: DataPoint[], height?: number, color?: string }) => {
    if (!data || data.length === 0) return null;

    // Find the max value for scaling
    const maxValue = Math.max(...data.map(d => d.value));

    return (
      <div className="h-full w-full overflow-hidden">
        <div className="flex h-full items-end space-x-1">
          {data.map((point, index) => {
            const barHeight = (point.value / maxValue) * height;

            return (
              <div
                key={index}
                className="group relative flex flex-1 flex-col items-center"
              >
                <div
                  className="w-full rounded-t transition-all duration-300 group-hover:opacity-80"
                  style={{
                    height: `${barHeight}px`,
                    backgroundColor: color,
                    minWidth: '3px',
                  }}
                />
                <div className="invisible absolute -top-8 left-1/2 -translate-x-1/2 rounded bg-card/90 px-2 py-1 text-xs opacity-0 shadow-md transition-all group-hover:visible group-hover:opacity-100">
                  <p className="whitespace-nowrap">{point.value} {timeRange === '24h' ? new Date(point.timestamp).getHours() + ':00' : new Date(point.timestamp).toLocaleDateString()}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // Line chart component for latency
  const LineChart = ({ data, height = 100, color = "#8b5cf6" }: { data: DataPoint[], height?: number, color?: string }) => {
    if (!data || data.length === 0) return null;

    // Find the max value for scaling
    const maxValue = Math.max(...data.map(d => d.value));
    const minValue = Math.min(...data.map(d => d.value));
    const range = maxValue - minValue;

    // Generate SVG path
    const pathData = data.map((point, index) => {
      const x = (index / (data.length - 1)) * 100;
      const y = 100 - ((point.value - minValue) / range) * 100;
      return `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
    }).join(' ');

    return (
      <div className="relative h-full w-full overflow-hidden">
        <svg
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
          className="h-full w-full"
        >
          <path
            d={pathData}
            fill="none"
            stroke={color}
            strokeWidth="1.5"
            vectorEffect="non-scaling-stroke"
          />
        </svg>
        <div className="absolute bottom-0 left-0 text-xs text-muted-foreground">
          {minValue}ms
        </div>
        <div className="absolute right-0 top-0 text-xs text-muted-foreground">
          {maxValue}ms
        </div>
      </div>
    );
  };

  if (!isAuthenticated) {
    return (
      <div className="rounded-lg border border-primary-darker bg-card/50 p-6 text-center">
        <p className="text-foreground">
          Please log in to view the analytics dashboard.
        </p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="mb-6 flex items-center justify-between">
        <h2 className="font-display text-2xl font-bold text-foreground">
          Proxy Performance Analytics
        </h2>
        <div className="flex items-center space-x-2 rounded-lg border border-primary-darker/60 bg-card/50 p-1">
          {(['24h', '7d', '30d', '90d'] as const).map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`rounded-md px-3 py-1 text-sm font-medium ${
                timeRange === range
                  ? 'bg-primary text-white'
                  : 'text-foreground hover:bg-primary-darker/20'
              }`}
            >
              {range}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="flex h-64 items-center justify-center">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
        </div>
      ) : stats ? (
        <>
          {/* Key metrics */}
          <div className="mb-6 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-lg border border-primary-darker/30 bg-card/30 p-4 shadow-sm">
              <div className="mb-2 text-sm text-muted-foreground">Uptime</div>
              <div className="text-2xl font-bold text-foreground">{stats.uptime}</div>
              <div className="mt-2 text-xs text-accent">+0.02% from last {timeRange}</div>
            </div>
            <div className="rounded-lg border border-primary-darker/30 bg-card/30 p-4 shadow-sm">
              <div className="mb-2 text-sm text-muted-foreground">Connected Clients</div>
              <div className="text-2xl font-bold text-foreground">{stats.connectedClients}</div>
              <div className="mt-2 text-xs text-accent">+{Math.floor(Math.random() * 4) + 2} from last hour</div>
            </div>
            <div className="rounded-lg border border-primary-darker/30 bg-card/30 p-4 shadow-sm">
              <div className="mb-2 text-sm text-muted-foreground">Total Traffic</div>
              <div className="text-2xl font-bold text-foreground">{stats.totalTraffic}</div>
              <div className="mt-2 text-xs text-accent">+{(Math.random() * 5 + 2).toFixed(2)} GB from yesterday</div>
            </div>
            <div className="rounded-lg border border-primary-darker/30 bg-card/30 p-4 shadow-sm">
              <div className="mb-2 text-sm text-muted-foreground">Success Rate</div>
              <div className="text-2xl font-bold text-foreground">{stats.successRate.toFixed(2)}%</div>
              <div className="mt-2 text-xs text-accent">+0.05% from last week</div>
            </div>
          </div>

          {/* Charts */}
          <div className="mb-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
            <div className="rounded-lg border border-primary-darker/30 bg-card/30 p-4 shadow-sm">
              <h3 className="mb-4 text-lg font-medium text-foreground">Bandwidth Usage (KB/s)</h3>
              <div className="h-48">
                <BarChart data={stats.bandwidthUsage} height={180} color="#4f46e5" />
              </div>
            </div>
            <div className="rounded-lg border border-primary-darker/30 bg-card/30 p-4 shadow-sm">
              <h3 className="mb-4 text-lg font-medium text-foreground">Response Latency (ms)</h3>
              <div className="h-48">
                <LineChart data={stats.latencyData} height={180} color="#8b5cf6" />
              </div>
            </div>
          </div>

          {/* Server load and connection types */}
          <div className="mb-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 rounded-lg border border-primary-darker/30 bg-card/30 p-4 shadow-sm">
              <h3 className="mb-4 text-lg font-medium text-foreground">Server Load (%)</h3>
              <div className="h-36">
                <BarChart data={stats.serverLoad} height={120} color="#10b981" />
              </div>
            </div>
            <div className="rounded-lg border border-primary-darker/30 bg-card/30 p-4 shadow-sm">
              <h3 className="mb-4 text-lg font-medium text-foreground">Connection Types</h3>
              <div className="space-y-4">
                <div>
                  <div className="mb-1 flex items-center justify-between">
                    <span className="text-sm text-foreground">HTTP</span>
                    <span className="text-sm text-muted-foreground">{stats.connectionTypes.http}</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-primary-darker/20">
                    <div
                      className="h-full rounded-full bg-primary"
                      style={{
                        width: `${(stats.connectionTypes.http / (stats.connectionTypes.http + stats.connectionTypes.https + stats.connectionTypes.socks)) * 100}%`
                      }}
                    />
                  </div>
                </div>
                <div>
                  <div className="mb-1 flex items-center justify-between">
                    <span className="text-sm text-foreground">HTTPS</span>
                    <span className="text-sm text-muted-foreground">{stats.connectionTypes.https}</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-primary-darker/20">
                    <div
                      className="h-full rounded-full bg-secondary"
                      style={{
                        width: `${(stats.connectionTypes.https / (stats.connectionTypes.http + stats.connectionTypes.https + stats.connectionTypes.socks)) * 100}%`
                      }}
                    />
                  </div>
                </div>
                <div>
                  <div className="mb-1 flex items-center justify-between">
                    <span className="text-sm text-foreground">SOCKS</span>
                    <span className="text-sm text-muted-foreground">{stats.connectionTypes.socks}</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-primary-darker/20">
                    <div
                      className="h-full rounded-full bg-accent"
                      style={{
                        width: `${(stats.connectionTypes.socks / (stats.connectionTypes.http + stats.connectionTypes.https + stats.connectionTypes.socks)) * 100}%`
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Top destinations */}
          <div className="rounded-lg border border-primary-darker/30 bg-card/30 p-4 shadow-sm">
            <h3 className="mb-4 text-lg font-medium text-foreground">Top Destinations</h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr>
                    <th className="pb-2 text-left text-sm font-medium text-muted-foreground">Domain</th>
                    <th className="pb-2 text-right text-sm font-medium text-muted-foreground">Requests</th>
                    <th className="pb-2 text-right text-sm font-medium text-muted-foreground">Percentage</th>
                    <th className="pb-2 text-left text-sm font-medium text-muted-foreground">Distribution</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.topDestinations.map((destination, index) => (
                    <tr key={index} className="border-t border-primary-darker/10">
                      <td className="py-2 text-sm font-medium text-foreground">{destination.domain}</td>
                      <td className="py-2 text-right text-sm text-muted-foreground">{destination.count.toLocaleString()}</td>
                      <td className="py-2 text-right text-sm text-muted-foreground">{destination.percentage.toFixed(1)}%</td>
                      <td className="py-2 pl-4">
                        <div className="h-2 w-full overflow-hidden rounded-full bg-primary-darker/20">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-primary to-secondary"
                            style={{ width: `${destination.percentage * 2}%` }}
                          />
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-6 rounded-md bg-primary-darker/10 p-3 text-sm text-muted-foreground">
            <p className="mb-1 font-medium text-foreground">Notes:</p>
            <ul className="list-inside list-disc space-y-1">
              <li>Data is updated every 5 minutes. Last update: {new Date().toLocaleTimeString()}</li>
              <li>Latency is measured as average response time from proxy server to destination</li>
              <li>Bandwidth usage includes both inbound and outbound traffic</li>
              {user?.subscriptionStatus !== 'premium' && (
                <li className="text-warning-yellow">Upgrade to Premium for real-time data and more detailed analytics</li>
              )}
            </ul>
          </div>
        </>
      ) : (
        <div className="rounded-lg border border-primary-darker bg-card/50 p-6 text-center">
          <p className="text-foreground">
            No data available. Please check your connection or try again later.
          </p>
        </div>
      )}
    </div>
  );
};
