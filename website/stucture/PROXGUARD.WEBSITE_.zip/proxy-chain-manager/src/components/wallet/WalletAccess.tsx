import React from 'react';
import { Card } from '../ui/Card';
import { WalletIcon, LockIcon } from '../icons/Icons';
import { Button } from '../ui/Button';

interface WalletAccessProps {
  isLoggedIn?: boolean;
}

export const WalletAccess = ({ isLoggedIn = false }: WalletAccessProps) => {
  return (
    <div className="my-6">
      <Card>
        <div className="flex items-start gap-3">
          {isLoggedIn ? (
            <WalletIcon size={24} className="text-primary mt-1" />
          ) : (
            <LockIcon size={24} className="text-primary mt-1" />
          )}

          <div className="flex-1">
            <h3 className="text-lg font-medium text-purple-400">
              {isLoggedIn ? 'Wallet Access' : 'Wallet Access Restricted'}
            </h3>

            {isLoggedIn ? (
              <div className="mt-2">
                <p className="text-sm text-purple-300">
                  You're currently logged in. You can manage your wallet and payment methods.
                </p>
              </div>
            ) : (
              <div>
                <p className="mt-2 text-sm text-purple-300">
                  Please login or register to access wallet features
                </p>

                <div className="mt-4 flex gap-3">
                  <Button variant="primary" className="flex-1">
                    Login
                  </Button>
                  <Button variant="secondary" className="flex-1">
                    Register
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
};
