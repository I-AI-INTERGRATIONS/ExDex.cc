import React, { useState, useEffect } from 'react';
import { useAuth } from '../../lib/authContext';
import { DNSChangerIcon, RefreshIcon, SystemStatusIcon, InfoIcon } from '../icons/Icons';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';

// Check if user is admin by looking for admin-access-granted in localStorage
const isAdminUser = () => {
  try {
    return localStorage.getItem('admin-access-granted') === 'true';
  } catch (error) {
    return false;
  }
};

interface VerificationResult {
  status: 'success' | 'warning' | 'error' | 'checking';
  message: string;
  details?: string[];
}

export const IPDNSVerifier = () => {
  const { user, isAuthenticated } = useAuth();
  const [isPremium, setIsPremium] = useState(false);

  useEffect(() => {
    // If admin, automatically set premium access
    if (isAdminUser()) {
      setIsPremium(true);
    } else {
      setIsPremium(isAuthenticated && user?.subscriptionStatus === 'premium');
    }
  }, [isAuthenticated, user]);

  // Auto-run tests when component mounts if admin
  useEffect(() => {
    if (isAdminUser()) {
      // Use a slight delay to ensure UI is ready
      setTimeout(() => {
        runAllTests();
      }, 1000);
    }
  }, []);

  const [ipInfo, setIpInfo] = useState<any>(null);
  const [isCheckingIp, setIsCheckingIp] = useState(false);
  const [ipLeakResult, setIpLeakResult] = useState<VerificationResult>({
    status: 'checking',
    message: 'Not checked yet',
  });

  const [dnsLeakResult, setDnsLeakResult] = useState<VerificationResult>({
    status: 'checking',
    message: 'Not checked yet',
  });

  const [webRTCLeakResult, setWebRTCLeakResult] = useState<VerificationResult>({
    status: 'checking',
    message: 'Not checked yet',
  });

  const checkIPAddress = async () => {
    setIsCheckingIp(true);
    setIpLeakResult({
      status: 'checking',
      message: 'Checking your IP address...',
    });

    try {
      // In a real app, you would use a more reliable IP checking service
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();

      // Get additional IP info (mocked for demo)
      setTimeout(() => {
        setIpInfo({
          ip: data.ip,
          country: 'United States',
          region: 'California',
          city: 'San Francisco',
          isp: 'Example ISP',
          proxy: false,
          vpn: false,
          tor: false,
        });

        setIpLeakResult({
          status: 'success',
          message: 'Your IP address is properly masked',
          details: [
            'No IP leaks detected',
            'Your traffic appears to be routed through your proxy chain',
          ],
        });

        setIsCheckingIp(false);
      }, 1500);
    } catch (error) {
      setIpLeakResult({
        status: 'error',
        message: 'Failed to check IP address',
        details: ['Could not connect to IP verification service'],
      });
      setIsCheckingIp(false);
    }
  };

  const checkDNSLeaks = () => {
    setDnsLeakResult({
      status: 'checking',
      message: 'Checking for DNS leaks...',
    });

    // Simulated DNS leak test
    setTimeout(() => {
      if (Math.random() > 0.5) {
        setDnsLeakResult({
          status: 'success',
          message: 'No DNS leaks detected',
          details: [
            'Your DNS queries are properly encrypted',
            'No DNS requests are being leaked outside your proxy chain',
          ],
        });
      } else {
        setDnsLeakResult({
          status: 'warning',
          message: 'Potential DNS leaks detected',
          details: [
            'Your DNS queries may be leaking outside your proxy chain',
            'Consider enabling DNS Changer feature',
          ],
        });
      }
    }, 2000);
  };

  const checkWebRTCLeaks = () => {
    setWebRTCLeakResult({
      status: 'checking',
      message: 'Checking for WebRTC leaks...',
    });

    // Simulated WebRTC leak test
    setTimeout(() => {
      const randomResult = Math.random();
      if (randomResult > 0.7) {
        setWebRTCLeakResult({
          status: 'error',
          message: 'WebRTC leaks detected',
          details: [
            'Your real IP address may be exposed through WebRTC',
            'Enable WebRTC blocking in your browser settings',
          ],
        });
      } else if (randomResult > 0.3) {
        setWebRTCLeakResult({
          status: 'warning',
          message: 'Potential WebRTC issue',
          details: [
            'WebRTC is enabled in your browser',
            'This could potentially leak your real IP address',
          ],
        });
      } else {
        setWebRTCLeakResult({
          status: 'success',
          message: 'No WebRTC leaks detected',
          details: [
            'WebRTC is properly configured',
            'Your real IP address is not exposed',
          ],
        });
      }
    }, 2500);
  };

  const runAllTests = () => {
    checkIPAddress();
    checkDNSLeaks();
    checkWebRTCLeaks();
  };

  // Status indicator component
  const StatusIndicator = ({ status }: { status: VerificationResult['status'] }) => {
    if (status === 'checking') {
      return <div className="h-3 w-3 animate-pulse rounded-full bg-primary-darker" />;
    }
    if (status === 'success') {
      return <div className="h-3 w-3 rounded-full bg-primary" />;
    }
    if (status === 'warning') {
      return <div className="h-3 w-3 rounded-full bg-warning-yellow" />;
    }
    return <div className="h-3 w-3 rounded-full bg-error-red" />;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 text-center">
        <h1 className="mb-2 text-3xl font-bold text-pink-400">IP & DNS Verification</h1>
        <p className="text-pink-300">
          Verify your connection is secure and anonymous
        </p>
      </div>

      <div className="mb-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="col-span-1 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center">
              <SystemStatusIcon size={24} className="mr-2 text-primary" />
              <h2 className="text-xl font-bold text-teal-400">Connection Status</h2>
            </div>
            <Button
              onClick={runAllTests}
              className="flex items-center gap-2"
              variant="secondary"
              disabled={isCheckingIp}
            >
              <RefreshIcon size={16} className={isCheckingIp ? 'animate-spin' : ''} />
              {isCheckingIp ? 'Checking...' : 'Check All'}
            </Button>
          </div>

          <div className="mb-6 grid grid-cols-1 gap-4 md:grid-cols-3">
            <div className="rounded-lg border border-primary-darker bg-background p-4">
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <StatusIndicator status={ipLeakResult.status} />
                  <h3 className="font-medium text-orange-300">IP Leak Test</h3>
                </div>
                <Button
                  onClick={checkIPAddress}
                  size="sm"
                  variant="ghost"
                  className="h-8 w-8 p-0"
                  disabled={isCheckingIp || ipLeakResult.status === 'checking'}
                >
                  <RefreshIcon size={16} className={ipLeakResult.status === 'checking' ? 'animate-spin' : ''} />
                </Button>
              </div>
              <p className="text-sm text-orange-200">{ipLeakResult.message}</p>
              {ipLeakResult.details && ipLeakResult.status !== 'checking' && (
                <ul className="mt-2 space-y-1">
                  {ipLeakResult.details.map((detail, i) => (
                    <li key={`ip-detail-${i}`} className="flex items-start text-xs text-orange-200">
                      <span className="mr-1 text-primary">•</span>
                      {detail}
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="rounded-lg border border-primary-darker bg-background p-4">
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <StatusIndicator status={dnsLeakResult.status} />
                  <h3 className="font-medium text-lime-300">DNS Leak Test</h3>
                </div>
                <Button
                  onClick={checkDNSLeaks}
                  size="sm"
                  variant="ghost"
                  className="h-8 w-8 p-0"
                  disabled={dnsLeakResult.status === 'checking'}
                >
                  <RefreshIcon size={16} className={dnsLeakResult.status === 'checking' ? 'animate-spin' : ''} />
                </Button>
              </div>
              <p className="text-sm text-lime-200">{dnsLeakResult.message}</p>
              {dnsLeakResult.details && dnsLeakResult.status !== 'checking' && (
                <ul className="mt-2 space-y-1">
                  {dnsLeakResult.details.map((detail, i) => (
                    <li key={`dns-detail-${i}`} className="flex items-start text-xs text-lime-200">
                      <span className="mr-1 text-primary">•</span>
                      {detail}
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="rounded-lg border border-primary-darker bg-background p-4">
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <StatusIndicator status={webRTCLeakResult.status} />
                  <h3 className="font-medium text-cyan-300">WebRTC Leak Test</h3>
                </div>
                <Button
                  onClick={checkWebRTCLeaks}
                  size="sm"
                  variant="ghost"
                  className="h-8 w-8 p-0"
                  disabled={webRTCLeakResult.status === 'checking'}
                >
                  <RefreshIcon size={16} className={webRTCLeakResult.status === 'checking' ? 'animate-spin' : ''} />
                </Button>
              </div>
              <p className="text-sm text-cyan-200">{webRTCLeakResult.message}</p>
              {webRTCLeakResult.details && webRTCLeakResult.status !== 'checking' && (
                <ul className="mt-2 space-y-1">
                  {webRTCLeakResult.details.map((detail, i) => (
                    <li key={`webrtc-detail-${i}`} className="flex items-start text-xs text-cyan-200">
                      <span className="mr-1 text-primary">•</span>
                      {detail}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {ipInfo && (
            <div className="rounded-lg border border-primary-darker bg-background p-4">
              <h3 className="mb-3 font-medium text-indigo-300">Detected IP Information</h3>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
                <div>
                  <p className="text-xs text-indigo-200">IP Address</p>
                  <p className="font-mono text-sm text-white">{ipInfo.ip}</p>
                </div>
                <div>
                  <p className="text-xs text-indigo-200">Country</p>
                  <p className="text-sm text-white">{ipInfo.country}</p>
                </div>
                <div>
                  <p className="text-xs text-indigo-200">City</p>
                  <p className="text-sm text-white">{ipInfo.city}</p>
                </div>
                <div>
                  <p className="text-xs text-indigo-200">ISP</p>
                  <p className="text-sm text-white">{ipInfo.isp}</p>
                </div>
              </div>
            </div>
          )}
        </Card>

        <Card>
          <div className="mb-4 flex items-center">
            <DNSChangerIcon size={24} className="mr-2 text-primary" />
            <h2 className="text-xl font-bold text-rose-400">Advanced Checks</h2>
          </div>

          <div className="space-y-4">
            <div className={`rounded-lg border ${isPremium ? 'border-primary-darker' : 'border-dashed border-primary-darker/50'} bg-background p-4`}>
              <div className="mb-2 flex items-center justify-between">
                <h3 className="font-medium text-yellow-300">Browser Fingerprint Analysis</h3>
                {!isPremium && (
                  <span className="rounded-full bg-primary-darker px-2 py-0.5 text-xs font-medium">PREMIUM</span>
                )}
              </div>
              <p className="text-sm text-yellow-200">
                {isPremium
                  ? 'Analyze your browser fingerprint for uniqueness and identifiability'
                  : 'Upgrade to premium to access browser fingerprint analysis'}
              </p>
              {isPremium && (
                <Button
                  className="mt-3 w-full"
                  variant="secondary"
                  size="sm"
                >
                  Run Check
                </Button>
              )}
            </div>

            <div className={`rounded-lg border ${isPremium ? 'border-primary-darker' : 'border-dashed border-primary-darker/50'} bg-background p-4`}>
              <div className="mb-2 flex items-center justify-between">
                <h3 className="font-medium text-green-300">Tracker Detection</h3>
                {!isPremium && (
                  <span className="rounded-full bg-primary-darker px-2 py-0.5 text-xs font-medium">PREMIUM</span>
                )}
              </div>
              <p className="text-sm text-green-200">
                {isPremium
                  ? 'Detect and block trackers that could compromise your privacy'
                  : 'Upgrade to premium to access tracker detection'}
              </p>
              {isPremium && (
                <Button
                  className="mt-3 w-full"
                  variant="secondary"
                  size="sm"
                >
                  Scan for Trackers
                </Button>
              )}
            </div>

            <div className={`rounded-lg border ${isPremium ? 'border-primary-darker' : 'border-dashed border-primary-darker/50'} bg-background p-4`}>
              <div className="mb-2 flex items-center justify-between">
                <h3 className="font-medium text-blue-300">Connection Encryption Audit</h3>
                {!isPremium && (
                  <span className="rounded-full bg-primary-darker px-2 py-0.5 text-xs font-medium">PREMIUM</span>
                )}
              </div>
              <p className="text-sm text-blue-200">
                {isPremium
                  ? 'Verify the encryption strength of your proxy chain connections'
                  : 'Upgrade to premium to access encryption auditing'}
              </p>
              {isPremium && (
                <Button
                  className="mt-3 w-full"
                  variant="secondary"
                  size="sm"
                >
                  Audit Encryption
                </Button>
              )}
            </div>
          </div>

          {!isPremium && (
            <div className="mt-6 rounded-lg bg-primary/10 p-4 text-center">
              <InfoIcon size={24} className="mx-auto mb-2 text-primary" />
              <h3 className="mb-1 font-medium text-violet-300">Upgrade for Advanced Features</h3>
              <p className="mb-3 text-sm text-violet-200">
                Get access to all premium verification tools and enhanced security checks.
              </p>
              <Button
                className="w-full"
                variant="primary"
                onClick={() => console.log('Navigate to subscription')}
              >
                Upgrade Now
              </Button>
            </div>
          )}
        </Card>
      </div>

      <Card>
        <div className="mb-4 flex items-center">
          <InfoIcon size={24} className="mr-2 text-primary" />
          <h2 className="text-xl font-bold text-purple-400">About IP & DNS Verification</h2>
        </div>
        <div className="space-y-4 text-sm text-purple-200">
          <p>
            Our verification tools check if your internet connection is properly secured and
            anonymized through our proxy chain system. Regular verification is recommended to ensure
            your privacy is maintained.
          </p>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div>
              <h3 className="mb-1 font-medium text-orange-300">IP Leak Test</h3>
              <p className="text-orange-200">
                Verifies that your real IP address is hidden and checks for any potential leaks that
                could expose your actual location or identity.
              </p>
            </div>
            <div>
              <h3 className="mb-1 font-medium text-lime-300">DNS Leak Test</h3>
              <p className="text-lime-200">
                Ensures your DNS requests are properly routed through the proxy chain and not leaking
                to your ISP, which could reveal your browsing activity.
              </p>
            </div>
            <div>
              <h3 className="mb-1 font-medium text-cyan-300">WebRTC Leak Test</h3>
              <p className="text-cyan-200">
                Checks if WebRTC is exposing your real IP address, which can happen even when using
                proxies if your browser's WebRTC implementation is not properly configured.
              </p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};
