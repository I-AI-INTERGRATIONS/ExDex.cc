import React, { useState, useEffect } from 'react';
import {
  ProxyChainIcon,
  DNSChangerIcon,
  MacAddressIcon,
  PatternRandomizerIcon,
  SystemStatusIcon,
  RestartIcon
} from '../icons/Icons';
import { ControlCard } from './ControlCard';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import NetworkTestModal from './NetworkTestModal';

// Check if user is admin
const isAdminUser = () => {
  try {
    return localStorage.getItem('admin-access-granted') === 'true';
  } catch (error) {
    return false;
  }
};

export const SystemControls = () => {
  const [proxyChainActive, setProxyChainActive] = useState(true);
  const [dnsChangerActive, setDnsChangerActive] = useState(true);
  const [macRotationActive, setMacRotationActive] = useState(true);
  const [patternRandomizerActive, setPatternRandomizerActive] = useState(true);
  const [systemStatus, setSystemStatus] = useState<'idle' | 'running' | 'error'>('running');
  const [showNetworkTest, setShowNetworkTest] = useState(false);

  // Turn everything on by default for admin users
  useEffect(() => {
    // If user is admin, turn everything on by default
    if (isAdminUser()) {
      setProxyChainActive(true);
      setDnsChangerActive(true);
      setMacRotationActive(true);
      setPatternRandomizerActive(true);
      setSystemStatus('running');
    }
  }, []);

  const toggleProxyChain = (active: boolean) => {
    setProxyChainActive(active);
    if (!active) {
      setSystemStatus('idle');
    } else {
      setSystemStatus('running');
    }
  };

  const handleRestartSystem = () => {
    setSystemStatus('idle');
    setTimeout(() => {
      setSystemStatus(proxyChainActive ? 'running' : 'idle');
    }, 1500);
  };

  const handleTestConnections = () => {
    setShowNetworkTest(true);
  };

  return (
    <div className="my-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-3xl font-bold text-primary uppercase tracking-wider">System Controls</h2>
        <div className="flex gap-2">
          <Button
            variant="secondary"
            className="flex items-center gap-2 text-lg px-6 py-3"
            onClick={handleRestartSystem}
          >
            <RestartIcon size={20} />
            Restart System
          </Button>

          <Button
            variant="primary"
            className="flex items-center gap-2 text-lg px-6 py-3"
            onClick={handleTestConnections}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path>
              <polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon>
            </svg>
            Test Connections
          </Button>
        </div>
      </div>

      {/* Status Summary Banner */}
      <div className="mb-6 p-4 rounded-lg bg-gradient-to-r from-black to-gray-900 border-2 border-green-500">
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-2xl font-bold text-green-400">SYSTEM ACTIVE</span>
            <div className="flex items-center mt-1">
              <div className="h-3 w-3 rounded-full bg-green-500 mr-2 animate-pulse"></div>
              <span className="text-green-300">All subsystems operational</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-x-6 gap-y-2">
            <div className="flex items-center">
              <div className="h-3 w-3 rounded-full bg-green-500 mr-2"></div>
              <span className="text-green-300">Chain Active</span>
            </div>
            <div className="flex items-center">
              <div className="h-3 w-3 rounded-full bg-green-500 mr-2"></div>
              <span className="text-green-300">DNS Changer Active</span>
            </div>
            <div className="flex items-center">
              <div className="h-3 w-3 rounded-full bg-green-500 mr-2"></div>
              <span className="text-green-300">MAC Rotation Active</span>
            </div>
            <div className="flex items-center">
              <div className="h-3 w-3 rounded-full bg-green-500 mr-2"></div>
              <span className="text-green-300">Pattern Randomizer Active</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        <ControlCard
          title="Proxy Chain"
          description="Enable or disable the proxy chain routing system"
          icon={<ProxyChainIcon size={24} />}
          isActive={proxyChainActive}
          onToggle={toggleProxyChain}
        />
        <ControlCard
          title="DNS Changer"
          description="Enable or disable automatic DNS server rotation"
          icon={<DNSChangerIcon size={24} />}
          isActive={dnsChangerActive}
          onToggle={setDnsChangerActive}
          disabled={!proxyChainActive}
        />
        <ControlCard
          title="MAC Address Rotation"
          description="Enable or disable automatic MAC address rotation"
          icon={<MacAddressIcon size={24} />}
          isActive={macRotationActive}
          onToggle={setMacRotationActive}
          disabled={!proxyChainActive}
        />
        <ControlCard
          title="Pattern Randomizer"
          description="Enable or disable traffic pattern randomization"
          icon={<PatternRandomizerIcon size={24} />}
          isActive={patternRandomizerActive}
          onToggle={setPatternRandomizerActive}
          disabled={!proxyChainActive}
        />
      </div>

      <div className="mt-6">
        <Card className="bg-gradient-to-r from-black to-gray-900 backdrop-blur-sm overflow-hidden border-2 border-primary-darker/50 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <SystemStatusIcon size={28} className={`
                ${systemStatus === 'idle' ? 'text-yellow-400' : ''}
                ${systemStatus === 'running' ? 'text-green-500' : ''}
                ${systemStatus === 'error' ? 'text-error-red' : ''}
              `} />
              <div className="font-mono">
                <span className="text-slate-400 mr-2 text-sm uppercase">System Status:</span>
                <span className={`font-mono text-xl font-bold
                  ${systemStatus === 'idle' ? 'text-yellow-400' : ''}
                  ${systemStatus === 'running' ? 'text-green-500' : ''}
                  ${systemStatus === 'error' ? 'text-error-red' : ''}
                `}>
                  {systemStatus.toUpperCase()}
                </span>
                <div className="mt-2 flex items-center">
                  <div className="h-2 w-2 rounded-full mr-1.5 bg-primary animate-pulse" />
                  <span className="text-sm text-slate-300">
                    {systemStatus === 'idle' ? 'System in standby mode. Ready to initiate connection.' : ''}
                    {systemStatus === 'running' ? 'System active. All modules functioning normally.' : ''}
                    {systemStatus === 'error' ? 'System error detected. Restart recommended.' : ''}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-lg text-green-400 font-mono font-bold border border-green-500 bg-green-500/10 px-3 py-1 rounded">AUTOMATIC MODE: ENABLED</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Network Test Modal */}
      <NetworkTestModal
        isOpen={showNetworkTest}
        onClose={() => setShowNetworkTest(false)}
      />
    </div>
  );
};
