import type React from 'react';
import { Card } from '../ui/Card';
import { Toggle } from '../ui/Toggle';

interface ControlCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  isActive?: boolean;
  onToggle?: (active: boolean) => void;
  disabled?: boolean;
}

export const ControlCard = ({
  title,
  description,
  icon,
  isActive = false,
  onToggle,
  disabled = false,
}: ControlCardProps) => {
  return (
    <Card className={`h-full overflow-hidden ${isActive ? 'border-green-500 border-2' : ''} ${isActive ? 'bg-gradient-to-br from-black to-gray-900' : ''}`}>
      {/* Active indicator bar */}
      {isActive && (
        <div className="h-1 w-full bg-green-500 absolute top-0 left-0"></div>
      )}

      <div className="flex items-start justify-between">
        <div className="flex items-start gap-3">
          <div className={`mt-0.5 ${isActive ? 'text-green-400' : 'text-muted-foreground'}`}>{icon}</div>
          <div>
            <h3 className={`text-xl font-bold ${isActive ? 'text-green-400' : 'text-yellow-500'}`}>{title}</h3>
            <p className="text-sm text-amber-300/90">{description}</p>
          </div>
        </div>
        <Toggle isActive={isActive} onChange={onToggle} disabled={disabled} />
      </div>

      <div className="mt-4 font-mono text-sm">
        <div className="flex items-center">
          <span className={`text-lg font-bold ${isActive ? 'text-green-400' : 'text-gray-400'}`}>
            {isActive ? 'ACTIVE' : 'INACTIVE'}
          </span>
          {isActive && (
            <div className="ml-2 flex items-center gap-1">
              <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse"></div>
              <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse delay-75"></div>
              <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse delay-150"></div>
            </div>
          )}
        </div>

        {isActive && (
          <div className="mt-3 flex items-center justify-between">
            <div className="flex items-center">
              <div className="h-3 w-3 rounded-full bg-green-500 mr-2 animate-pulse"></div>
              <span className="text-sm text-green-300">Running</span>
            </div>
            <span className="text-xs px-2 py-1 rounded bg-green-900/50 text-green-300 border border-green-500/50">ENABLED</span>
          </div>
        )}
      </div>
    </Card>
  );
};
