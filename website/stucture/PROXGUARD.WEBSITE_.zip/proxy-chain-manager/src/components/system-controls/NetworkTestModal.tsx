import React, { useState, useEffect } from 'react';
import { Button } from '../ui/Button';

interface NetworkTestModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NetworkTestModal: React.FC<NetworkTestModalProps> = ({ isOpen, onClose }) => {
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState('Initializing tests...');
  const [detail, setDetail] = useState('Please wait while we verify all connections');
  const [testComplete, setTestComplete] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    // Reset state when modal opens
    setProgress(0);
    setStatus('Initializing tests...');
    setDetail('Please wait while we verify all connections');
    setTestComplete(false);

    // Simulate connection tests with delays
    const timers: number[] = [];

    timers.push(setTimeout(() => {
      setProgress(10);
      setStatus("Testing Proxy Chain");
      setDetail("Verifying proxy chain integrity...");
    }, 500));

    timers.push(setTimeout(() => {
      setProgress(20);
      setStatus("Testing Proxy Chain");
      setDetail("All proxies responding normally");
    }, 1500));

    timers.push(setTimeout(() => {
      setProgress(30);
      setStatus("Testing DNS Servers");
      setDetail("Verifying DNS server connections...");
    }, 2500));

    timers.push(setTimeout(() => {
      setProgress(40);
      setStatus("Testing DNS Servers");
      setDetail("All DNS servers accessible and responding");
    }, 3500));

    timers.push(setTimeout(() => {
      setProgress(50);
      setStatus("Testing MAC Address Rotation");
      setDetail("Verifying MAC address rotation functionality...");
    }, 4500));

    timers.push(setTimeout(() => {
      setProgress(65);
      setStatus("Testing MAC Address Rotation");
      setDetail("MAC address rotation functioning normally");
    }, 5500));

    timers.push(setTimeout(() => {
      setProgress(75);
      setStatus("Testing Pattern Randomizer");
      setDetail("Verifying traffic pattern randomization...");
    }, 6500));

    timers.push(setTimeout(() => {
      setProgress(85);
      setStatus("Testing Pattern Randomizer");
      setDetail("Pattern randomization functioning optimally");
    }, 7500));

    timers.push(setTimeout(() => {
      setProgress(95);
      setStatus("Finalizing Tests");
      setDetail("Running final connection verifications...");
    }, 8500));

    // Complete the test
    timers.push(setTimeout(() => {
      setProgress(100);
      setStatus("ALL TESTS COMPLETED");
      setDetail("All systems operational with optimal performance");
      setTestComplete(true);
    }, 10000));

    // Clean up timers if modal closes
    return () => {
      timers.forEach(timer => clearTimeout(timer));
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex flex-col items-center justify-center z-50">
      <div className="max-w-lg w-full bg-gray-900 border-2 border-green-500 rounded-lg p-8">
        <div className="text-3xl font-bold text-green-400 mb-4 text-center">
          {testComplete ? "TESTS COMPLETE" : "TESTING ALL CONNECTIONS"}
        </div>

        <div className="w-full h-6 bg-gray-800 rounded-full overflow-hidden mb-6">
          <div
            className="h-full bg-green-500 transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="text-xl text-green-300 mb-2 text-center font-bold">{status}</div>
        <div className="text-sm text-green-200 mb-8 text-center">{detail}</div>

        {testComplete && (
          <div className="flex justify-center mb-6">
            <div className="text-6xl text-green-500 animate-pulse">
              <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                <polyline points="22 4 12 14.01 9 11.01"></polyline>
              </svg>
            </div>
          </div>
        )}

        {testComplete && (
          <div className="p-4 bg-green-900/30 border border-green-500/30 rounded-md mb-6">
            <div className="font-bold text-green-300 mb-1">Connection Summary:</div>
            <div className="text-sm text-green-200">• Proxy Chain: Optimal (28ms latency)</div>
            <div className="text-sm text-green-200">• DNS Servers: All responding (4/4)</div>
            <div className="text-sm text-green-200">• MAC Address Rotation: Functioning correctly</div>
            <div className="text-sm text-green-200">• Traffic Pattern: Randomization active</div>
            <div className="text-sm text-green-200">• Security Rating: Excellent</div>
          </div>
        )}

        <div className="flex justify-center">
          <Button
            variant="primary"
            onClick={onClose}
            className="px-8 py-2"
          >
            {testComplete ? "Close" : "Cancel Test"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default NetworkTestModal;
