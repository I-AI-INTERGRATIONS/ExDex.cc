import React, { useState, useEffect } from 'react';
import { Card } from '../ui/Card';
import { Toggle } from '../ui/Toggle';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import {
  PrivacyFeatureIcon,
  DNSChangerIcon,
  MacAddressIcon,
  PatternRandomizerIcon,
  AddIcon
} from '../icons/Icons';

interface DNSServer {
  id: string;
  address: string;
}

// Check if user is admin
const isAdminUser = () => {
  try {
    return localStorage.getItem('admin-access-granted') === 'true';
  } catch (error) {
    return false;
  }
};

export const PrivacyFeatures = () => {
  const [privacyEnabled, setPrivacyEnabled] = useState(true); // Enabled by default
  const [dnsChangerEnabled, setDnsChangerEnabled] = useState(true); // Enabled by default
  const [newDNSServer, setNewDNSServer] = useState('');
  const [dnsServers, setDnsServers] = useState<DNSServer[]>([
    { id: 'dns1', address: '1.1.1.1' },
    { id: 'dns2', address: '8.8.8.8' },
    { id: 'dns3', address: '9.9.9.9' },
    { id: 'dns4', address: '208.67.222.222' },
  ]);

  // Make sure features are enabled for admin users
  useEffect(() => {
    if (isAdminUser()) {
      setPrivacyEnabled(true);
      setDnsChangerEnabled(true);
    }
  }, []);

  const handleAddDNSServer = () => {
    if (!newDNSServer) return;

    const id = `dns${Date.now()}`;
    setDnsServers([...dnsServers, { id, address: newDNSServer }]);
    setNewDNSServer('');
  };

  return (
    <div className="my-6">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-2xl font-bold uppercase text-primary">Privacy Features</h2>
        <div className="flex items-center gap-2">
          <Toggle isActive={privacyEnabled} onChange={setPrivacyEnabled} />
          <span className="text-sm font-medium">
            {privacyEnabled ? 'Enabled' : 'Disabled'}
          </span>
        </div>
      </div>

      <Card>
        <div className="flex items-start gap-3">
          <PrivacyFeatureIcon size={24} className="text-primary mt-1" />
          <p className="text-muted-foreground">
            Enhance your anonymity with DNS changing, MAC address rotation, and traffic
            pattern randomization
          </p>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-3">
          <Button
            variant="secondary"
            icon={<DNSChangerIcon size={18} />}
            className="justify-start"
          >
            DNS Changer
          </Button>
          <Button
            variant="secondary"
            icon={<MacAddressIcon size={18} />}
            className="justify-start"
          >
            MAC Rotation
          </Button>
          <Button
            variant="secondary"
            icon={<PatternRandomizerIcon size={18} />}
            className="justify-start"
          >
            Pattern Randomizer
          </Button>
        </div>
      </Card>

      <div className="mt-6">
        <Card className={dnsChangerEnabled ? "border-blue-500 border-2 bg-gradient-to-br from-black to-gray-900" : ""}>
          <div className="flex items-center gap-2 mb-4">
            <DNSChangerIcon size={24} className={dnsChangerEnabled ? "text-blue-400" : "text-muted-foreground"} />
            <h3 className={`text-xl font-bold ${dnsChangerEnabled ? "text-blue-400" : "text-gray-500"}`}>DNS Changer</h3>
            <div className="ml-auto flex items-center gap-3">
              {dnsChangerEnabled && (
                <span className="text-xs px-2 py-1 rounded bg-blue-900/50 text-blue-300 border border-blue-500/50 font-bold">ACTIVE</span>
              )}
              <Toggle isActive={dnsChangerEnabled} onChange={setDnsChangerEnabled} />
            </div>
          </div>

          <p className={`mb-4 text-sm ${dnsChangerEnabled ? "text-blue-300" : "text-gray-500"}`}>
            Change your DNS servers to enhance privacy and bypass certain restrictions.
          </p>

          {dnsChangerEnabled && (
            <div className="mb-4 p-3 rounded-md bg-blue-900/20 border border-blue-500/30">
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-blue-500 animate-pulse"></div>
                <span className="text-blue-300 text-sm">DNS Protection Active - Traffic Encrypted</span>
              </div>
              <div className="mt-2 text-xs text-blue-300/70">All DNS queries are being routed through secure servers</div>
            </div>
          )}

          <div className="grid grid-cols-1 gap-2 md:grid-cols-2">
            {dnsServers.map((server) => (
              <div
                key={server.id}
                className={`rounded-md border ${dnsChangerEnabled ? "border-blue-500/50 bg-blue-900/10" : "border-primary-darker bg-background/50"} p-3`}
              >
                <div className="flex items-center gap-2">
                  <DNSChangerIcon size={16} className={dnsChangerEnabled ? "text-blue-400" : "text-muted-foreground"} />
                  <span className={`font-mono ${dnsChangerEnabled ? "text-blue-300" : "text-foreground"}`}>{server.address}</span>
                  {dnsChangerEnabled && (
                    <span className="ml-auto text-[10px] text-blue-400">ACTIVE</span>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 flex gap-2">
            <Input
              value={newDNSServer}
              onChange={(e) => setNewDNSServer(e.target.value)}
              placeholder="Add DNS Server (e.g., 8.8.4.4)"
              className={`flex-1 ${dnsChangerEnabled ? "border-blue-500/50 bg-blue-900/10 text-blue-300" : ""}`}
            />
            <Button
              variant="secondary"
              icon={<AddIcon size={16} />}
              onClick={handleAddDNSServer}
              disabled={!newDNSServer}
              className={dnsChangerEnabled ? "bg-blue-500 hover:bg-blue-600 text-white border-blue-500" : ""}
            >
              Add
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};
