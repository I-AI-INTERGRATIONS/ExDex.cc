import type React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  fullWidth?: boolean;
  className?: string;
}

export const Input = ({
  label,
  error,
  fullWidth = false,
  className = '',
  ...props
}: InputProps) => {
  return (
    <div className={`mb-4 ${fullWidth ? 'w-full' : ''}`}>
      {label && (
        <label className="mb-1 block text-sm font-medium text-foreground">{label}</label>
      )}
      <input
        className={`
          input ${fullWidth ? 'w-full' : ''}
          ${error ? 'border-error-red' : ''}
          ${className}
        `}
        {...props}
      />
      {error && <p className="mt-1 text-xs text-error-red">{error}</p>}
    </div>
  );
};
