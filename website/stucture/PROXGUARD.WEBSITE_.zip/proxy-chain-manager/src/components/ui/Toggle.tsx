import { useState, useEffect } from 'react';

interface ToggleProps {
  isActive?: boolean;
  onChange?: (active: boolean) => void;
  disabled?: boolean;
}

export const Toggle = ({ isActive = false, onChange, disabled = false }: ToggleProps) => {
  const [active, setActive] = useState(isActive);

  // Update internal state when isActive prop changes
  useEffect(() => {
    setActive(isActive);
  }, [isActive]);

  const handleToggle = () => {
    if (disabled) return;

    const newState = !active;
    setActive(newState);
    onChange?.(newState);
  };

  return (
    <div
      className={`toggle ${active ? 'toggle-active' : ''} ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
      onClick={handleToggle}
      role="switch"
      aria-checked={active}
      tabIndex={disabled ? -1 : 0}
    >
      <div className="toggle-handle" />
    </div>
  );
};
