import type React from 'react';
import { QRCodeSVG } from 'qrcode.react';

interface QRCodeProps {
  value: string;
  size?: number;
  className?: string;
  bgColor?: string;
  fgColor?: string;
  level?: 'L' | 'M' | 'Q' | 'H';
  includeMargin?: boolean;
  logoImage?: string;
  logoSize?: number;
  logoBackgroundColor?: string;
  borderColor?: string;
  animateBorder?: boolean;
  pulsingIndicator?: boolean;
  scanGuide?: boolean;
  withGlitch?: boolean;
}

const QRCode: React.FC<QRCodeProps> = ({
  value,
  size = 200,
  className = '',
  bgColor = '#FFFFFF',
  fgColor = '#000000',
  level = 'H',
  includeMargin = true,
  logoImage,
  logoSize = 48,
  logoBackgroundColor = '#000000',
  borderColor = '#00FF00',
  animateBorder = false,
  pulsingIndicator = false,
  scanGuide = false,
  withGlitch = false
}) => {
  const borderClass = animateBorder
    ? 'ring-2 ring-offset-1 ring-offset-black animate-pulse-glow'
    : 'border-2';

  const matrixGreen = '#00FF00';

  return (
    <div className={`relative flex items-center justify-center ${className}`}>
      {/* QR Code with configurable styling */}
      <div
        className={`relative ${borderClass} rounded-lg overflow-hidden`}
        style={{ borderColor }}
      >
        {/* Glitch animation overlay */}
        {withGlitch && (
          <div className="absolute inset-0 z-10 opacity-20 pointer-events-none">
            <div className="absolute inset-0 bg-gradient-to-tr from-[#00FF00]/10 via-transparent to-[#00FF00]/10 animate-pulse-slow" />
            <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-[#00FF00]/70 to-transparent" />
            <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-[#00FF00]/70 to-transparent" />
          </div>
        )}

        {/* Main QR code */}
        <QRCodeSVG
          value={value}
          size={size}
          bgColor={bgColor}
          fgColor={fgColor}
          level={level}
          includeMargin={includeMargin}
        />

        {/* Logo overlay in center */}
        {logoImage && (
          <div
            className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 rounded-full shadow-lg border-2"
            style={{
              backgroundColor: logoBackgroundColor,
              borderColor,
              width: logoSize,
              height: logoSize
            }}
          >
            <img
              src={logoImage}
              alt="Logo"
              className="w-full h-full p-1 rounded-full object-contain"
            />
          </div>
        )}

        {/* Pulsing indicator for active state */}
        {pulsingIndicator && (
          <div className="absolute top-2 right-2 flex items-center justify-center">
            <div className="absolute w-3 h-3 rounded-full bg-[#00FF00] animate-ping opacity-75" />
            <div className="relative w-2 h-2 rounded-full bg-[#00FF00]" />
          </div>
        )}
      </div>

      {/* Scan guide corners */}
      {scanGuide && (
        <>
          {/* Top-left corner */}
          <div className="absolute top-0 left-0 w-5 h-5 border-t-2 border-l-2 rounded-tl" style={{ borderColor }} />
          {/* Top-right corner */}
          <div className="absolute top-0 right-0 w-5 h-5 border-t-2 border-r-2 rounded-tr" style={{ borderColor }} />
          {/* Bottom-left corner */}
          <div className="absolute bottom-0 left-0 w-5 h-5 border-b-2 border-l-2 rounded-bl" style={{ borderColor }} />
          {/* Bottom-right corner */}
          <div className="absolute bottom-0 right-0 w-5 h-5 border-b-2 border-r-2 rounded-br" style={{ borderColor }} />
        </>
      )}
    </div>
  );
};

export default QRCode;
