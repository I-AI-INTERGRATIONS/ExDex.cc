import React from 'react';
import { useNotifications, type Notification } from '../../lib/notificationContext';

export const Notifications = () => {
  const { notifications, dismissNotification } = useNotifications();

  if (notifications.length === 0) {
    return null;
  }

  return (
    <div className="pointer-events-none fixed inset-0 z-50 flex flex-col items-end p-4 sm:items-start sm:p-6">
      <div className="flex w-full flex-col items-center space-y-4 sm:items-end">
        {notifications.map((notification) => (
          <NotificationToast
            key={notification.id}
            notification={notification}
            onDismiss={dismissNotification}
          />
        ))}
      </div>
    </div>
  );
};

interface NotificationToastProps {
  notification: Notification;
  onDismiss: (id: string) => void;
}

const NotificationToast = ({ notification, onDismiss }: NotificationToastProps) => {
  const { id, type, title, message } = notification;

  let bgClass = '';
  let iconClass = '';
  let Icon = null;

  switch (type) {
    case 'success':
      bgClass = 'bg-primary/10 border-primary';
      iconClass = 'text-primary';
      Icon = SuccessIcon;
      break;
    case 'error':
      bgClass = 'bg-error-red/10 border-error-red';
      iconClass = 'text-error-red';
      Icon = ErrorIcon;
      break;
    case 'warning':
      bgClass = 'bg-warning-yellow/10 border-warning-yellow';
      iconClass = 'text-warning-yellow';
      Icon = WarningIcon;
      break;
    default:
      bgClass = 'bg-primary-darker/20 border-primary-darker';
      iconClass = 'text-primary';
      Icon = InfoIcon;
      break;
  }

  return (
    <div
      className={`pointer-events-auto w-full max-w-sm rounded-lg border p-4 shadow-lg backdrop-blur-sm dark:shadow-primary-darker/10 ${bgClass}`}
    >
      <div className="flex items-start">
        <div className={`mr-3 flex-shrink-0 ${iconClass}`}>
          <Icon />
        </div>
        <div className="flex-1">
          <p className="text-sm font-medium text-foreground">{title}</p>
          <p className="mt-1 text-sm text-muted-foreground">{message}</p>
        </div>
        <button
          type="button"
          className="ml-4 inline-flex flex-shrink-0 rounded-md p-1 text-muted-foreground hover:bg-primary-darker/10 hover:text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
          onClick={() => onDismiss(id)}
        >
          <span className="sr-only">Close</span>
          <CloseIcon />
        </button>
      </div>
    </div>
  );
};

const SuccessIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
    <polyline points="22 4 12 14.01 9 11.01" />
  </svg>
);

const ErrorIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="12" r="10" />
    <line x1="15" y1="9" x2="9" y2="15" />
    <line x1="9" y1="9" x2="15" y2="15" />
  </svg>
);

const WarningIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
    <line x1="12" y1="9" x2="12" y2="13" />
    <line x1="12" y1="17" x2="12.01" y2="17" />
  </svg>
);

const InfoIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="12" r="10" />
    <line x1="12" y1="16" x2="12" y2="12" />
    <line x1="12" y1="8" x2="12.01" y2="8" />
  </svg>
);

const CloseIcon = () => (
  <svg
    className="h-5 w-5"
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M6 18L18 6M6 6l12 12"
    />
  </svg>
);
