import type React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: React.ReactNode;
  icon?: React.ReactNode;
  action?: React.ReactNode;
}

export const Card = ({
  children,
  className = '',
  title,
  icon,
  action,
}: CardProps) => {
  return (
    <div className={`card ${className}`}>
      {(title || icon || action) && (
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {icon && <div className="text-primary">{icon}</div>}
            {title && <h3 className="text-lg font-medium text-foreground">{title}</h3>}
          </div>
          {action && <div>{action}</div>}
        </div>
      )}
      {children}
    </div>
  );
};
