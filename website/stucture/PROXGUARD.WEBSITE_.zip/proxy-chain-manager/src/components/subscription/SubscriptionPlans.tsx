import React, { useState } from 'react';
import { useAuth } from '../../lib/authContext';
import { LockIcon, WalletIcon, SecureLinkIcon } from '../icons/Icons';
import PaymentProcessor from './PaymentProcessor'; // Fixed import

type Plan = {
  id: string;
  name: string;
  price: string;
  cryptoPrice: {
    btc: string;
    eth: string;
    usdt: string;
    sol: string;
    xmr: string;
  };
  interval: 'daily' | 'monthly' | 'yearly';
  features: string[];
  recommended?: boolean;
};

export const SubscriptionPlans = () => {
  const { user, isAuthenticated } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [showPayment, setShowPayment] = useState(false);

  const plans: Plan[] = [
    {
      id: 'daily',
      name: 'Daily Pass',
      price: '$1',
      cryptoPrice: {
        btc: '0.00001',
        eth: '0.0002',
        usdt: '1.00',
        sol: '0.02',
        xmr: '0.005',
      },
      interval: 'daily',
      features: [
        'Full access for 24 hours',
        'Unlimited proxy chains',
        'Basic IP & DNS verification',
        'Standard support',
      ],
    },
    {
      id: 'monthly',
      name: 'Monthly Pro',
      price: '$10',
      cryptoPrice: {
        btc: '0.0001',
        eth: '0.002',
        usdt: '10.00',
        sol: '0.2',
        xmr: '0.05',
      },
      interval: 'monthly',
      features: [
        'Full access for 30 days',
        'Unlimited proxy chains',
        'Advanced IP & DNS verification',
        'Priority support',
        'Multiple device support',
      ],
      recommended: true,
    },
    {
      id: 'yearly',
      name: 'Annual Premium',
      price: '$50',
      cryptoPrice: {
        btc: '0.0005',
        eth: '0.01',
        usdt: '50.00',
        sol: '1.0',
        xmr: '0.25',
      },
      interval: 'yearly',
      features: [
        'Full access for 365 days',
        'Unlimited proxy chains',
        'Enterprise IP & DNS verification',
        'Dedicated support',
        'Multiple device support',
        'Custom proxy configuration',
        'API access',
      ],
    },
  ];

  const handleSelectPlan = (plan: Plan) => {
    setSelectedPlan(plan);
    setShowPayment(true);
  };

  const handleClosePayment = () => {
    setShowPayment(false);
    setSelectedPlan(null);
  };

  if (!isAuthenticated) {
    return (
      <div className="mx-auto max-w-md rounded-lg border border-primary-darker bg-card/50 p-8 text-center shadow-lg">
        <div className="flex justify-center">
          <div className="relative">
            <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-primary to-secondary opacity-75 blur"></div>
            <div className="relative rounded-full bg-background p-3">
              <LockIcon size={40} className="text-primary" />
            </div>
          </div>
        </div>
        <h2 className="mb-2 mt-4 font-display text-2xl font-bold text-foreground">Authentication Required</h2>
        <p className="mb-6 text-muted-foreground">Please sign in or create an account to view subscription options.</p>
        <div className="flex justify-center gap-4">
          <button
            className="rounded-md border border-primary-darker/80 bg-card/50 px-4 py-2 text-sm font-medium text-foreground hover:border-primary hover:bg-primary/5 hover:text-primary"
            onClick={() => console.log('Navigate to login')}
          >
            Sign In
          </button>
          <button
            className="rounded-md bg-gradient-to-r from-primary to-secondary px-4 py-2 text-sm font-medium text-white shadow hover:opacity-90"
            onClick={() => console.log('Navigate to register')}
          >
            Create Account
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-10 text-center">
        <h1 className="mb-2 font-display text-3xl font-bold text-foreground">
          Choose Your <span className="text-primary">Security</span> Plan
        </h1>
        <p className="text-lg text-muted-foreground">
          Enterprise-grade proxy chain management with advanced security features
        </p>
      </div>

      {user?.subscriptionStatus === 'premium' && (
        <div className="mb-10 rounded-lg border border-primary bg-gradient-to-r from-primary/10 to-secondary/10 p-6 text-center shadow-lg">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r from-primary to-secondary text-white">
            <SecureLinkIcon size={30} />
          </div>
          <h2 className="mb-2 mt-4 font-display text-xl font-bold text-foreground">Premium Subscription Active</h2>
          <p className="mb-4 text-muted-foreground">
            You currently have an active premium subscription. Enjoy all the benefits!
          </p>
          <div className="mb-6 inline-block rounded-full bg-gradient-to-r from-primary to-secondary px-4 py-2 text-sm font-medium text-white">
            Active until: {user.subscriptionExpiry ? new Date(user.subscriptionExpiry).toLocaleDateString() : 'N/A'}
          </div>
          <button className="rounded-md border border-primary-darker bg-card/70 px-4 py-2 text-sm font-medium text-primary hover:border-primary hover:bg-primary hover:text-white transition duration-200">
            Manage Subscription
          </button>
        </div>
      )}

      <div className="grid gap-8 md:grid-cols-3">
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={`relative rounded-lg border ${
              plan.recommended
                ? 'border-primary/50 shadow-xl shadow-primary/10'
                : 'border-primary-darker/50'
            } bg-card/40 p-6 transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-primary/5`}
          >
            {plan.recommended && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-primary to-secondary px-4 py-1 text-center text-xs font-semibold text-white shadow-md">
                RECOMMENDED
              </div>
            )}
            <h3 className="mb-2 font-display text-xl font-bold text-foreground">{plan.name}</h3>
            <div className="mb-4">
              <span className="text-3xl font-bold text-primary">{plan.price}</span>
              <span className="text-muted-foreground">/{plan.interval}</span>
            </div>
            <div className="mb-6 rounded-md bg-primary-darker/20 p-3 text-xs text-muted-foreground">
              <div className="mb-2 flex items-center justify-between">
                <span className="flex items-center">
                  <span className="mr-1 inline-block h-3 w-3 rounded-full bg-secondary/70"></span>
                  BTC:
                </span>
                <span className="font-mono text-sm text-foreground">{plan.cryptoPrice.btc}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center">
                  <span className="mr-1 inline-block h-3 w-3 rounded-full bg-primary/70"></span>
                  ETH:
                </span>
                <span className="font-mono text-sm text-foreground">{plan.cryptoPrice.eth}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center">
                  <span className="mr-1 inline-block h-3 w-3 rounded-full bg-secondary/70"></span>
                  USDT:
                </span>
                <span className="font-mono text-sm text-foreground">{plan.cryptoPrice.usdt}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center">
                  <span className="mr-1 inline-block h-3 w-3 rounded-full bg-primary/70"></span>
                  SOL:
                </span>
                <span className="font-mono text-sm text-foreground">{plan.cryptoPrice.sol}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center">
                  <span className="mr-1 inline-block h-3 w-3 rounded-full bg-secondary/70"></span>
                  XMR:
                </span>
                <span className="font-mono text-sm text-foreground">{plan.cryptoPrice.xmr}</span>
              </div>
            </div>
            <ul className="mb-6 space-y-2">
              {plan.features.map((feature, index) => (
                <li key={index} className="flex items-start">
                  <svg
                    className="mr-2 h-5 w-5 flex-shrink-0 text-accent"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M5 13l4 4L19 7"
                    />
                  </svg>
                  <span className="text-sm text-foreground">{feature}</span>
                </li>
              ))}
            </ul>
            <button
              onClick={() => handleSelectPlan(plan)}
              className={`w-full rounded-md py-2 text-center text-sm font-medium ${
                plan.recommended
                  ? 'bg-gradient-to-r from-primary to-secondary text-white shadow-md hover:opacity-90'
                  : 'border border-primary-darker/80 bg-card/70 text-foreground hover:border-primary hover:bg-primary/10 hover:text-primary'
              }`}
            >
              {user?.subscriptionStatus === 'premium' ? 'Change Plan' : 'Select Plan'}
            </button>
          </div>
        ))}
      </div>

      {showPayment && selectedPlan && (
        <PaymentProcessor
          plan={selectedPlan}
          onClose={handleClosePayment}
        />
      )}
    </div>
  );
};
