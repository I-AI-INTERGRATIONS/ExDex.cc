import React, { useState, useEffect } from 'react';
import { WalletIcon, RefreshIcon, CopyIcon } from '../icons/Icons';
import QRCode from '../ui/QRCode';
import { PaymentActivityFeed } from '../payment/PaymentActivityFeed';
import { Button } from '../ui/Button';
// import * as api from '../../lib/api'; // Uncomment when backend is available

// Payment statuses
type PaymentStatus = 'awaiting' | 'processing' | 'confirmed' | 'failed';

// Cryptocurrency options
type CryptoType = 'btc' | 'eth' | 'usdt' | 'sol';

interface Plan {
  id: string;
  name: string;
  price: string;
  cryptoPrice: {
    btc: string;
    eth: string;
    usdt?: string;
    sol?: string;
  };
  interval: 'daily' | 'monthly' | 'yearly';
}

interface PaymentProcessorProps {
  plan: Plan;
  onClose: () => void;
}

// These would be your actual deposit addresses
const DEPOSIT_ADDRESSES: Record<CryptoType, string> = {
  btc: 'bc1q8nvdka59fah5tc2vydx7n0c500a5rp764ckvnqdqltw9ztq9wsgssy9jcr',
  eth: '0x45fD9ba0c6a35a197dB8C8413b631C53386dC43D',
  usdt: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
  sol: '5YNmS1R9nNSCDzb5a7mMJ1dwK9uHeAAQmx5tdCie1qJ3'
};

// Crypto currency display information
const CRYPTO_INFO = {
  btc: {
    name: 'Bitcoin',
    symbol: 'BTC',
    color: '#f7931a',
    logo: 'https://cryptologos.cc/logos/bitcoin-btc-logo.svg?v=025'
  },
  eth: {
    name: 'Ethereum',
    symbol: 'ETH',
    color: '#627eea',
    logo: 'https://cryptologos.cc/logos/ethereum-eth-logo.svg?v=025'
  },
  usdt: {
    name: 'Tether',
    symbol: 'USDT',
    color: '#26a17b',
    logo: 'https://cryptologos.cc/logos/tether-usdt-logo.svg?v=025'
  },
  sol: {
    name: 'Solana',
    symbol: 'SOL',
    color: '#14f195',
    logo: 'https://cryptologos.cc/logos/solana-sol-logo.svg?v=025'
  }
};

const PaymentProcessor: React.FC<PaymentProcessorProps> = ({ plan, onClose }) => {
  const [status, setStatus] = useState<PaymentStatus>('awaiting');
  const [confirmationProgress, setConfirmationProgress] = useState(0);
  const [paymentVerified, setPaymentVerified] = useState(false);
  const [txHash, setTxHash] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<CryptoType>('btc');
  const [timeRemaining, setTimeRemaining] = useState(900); // 15 minutes in seconds
  const [copySuccess, setCopySuccess] = useState(false);

  // Dummy function to get node ID for the footer
  const getNodeId = () => {
    return 'node_' + Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  };

  // Format time remaining as mm:ss
  const formatTimeRemaining = () => {
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  // Decrement timer
  useEffect(() => {
    if (status === 'awaiting' && timeRemaining > 0) {
      const timer = setTimeout(() => {
        setTimeRemaining((prev) => prev - 1);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [timeRemaining, status]);

  // Copy address to clipboard
  const copyAddressToClipboard = () => {
    navigator.clipboard.writeText(DEPOSIT_ADDRESSES[paymentMethod]).then(() => {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    });
  };

  // Handle payment verification (in a real app, this would connect to blockchain APIs)
  const verifyPayment = () => {
    setStatus('processing');

    // Simulate blockchain confirmation process for the demo
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setConfirmationProgress(progress);

      if (progress >= 100) {
        clearInterval(interval);
        setStatus('confirmed');
        setPaymentVerified(true);

        // In a production environment, this would:
        // 1. Verify the transaction on the blockchain
        // 2. Check that payment was sent to the correct address
        // 3. Verify the amount is correct
        // 4. Record the transaction hash

        // For now, we'll simulate this by storing in localStorage
        try {
          const userId = localStorage.getItem('userId') || 'anonymous-' + Date.now();

          // Import from auth.ts - in a production build, these would be properly imported
          // These functions are defined in lib/auth.ts
          if (typeof window !== 'undefined') {
            // Set payment as verified
            localStorage.setItem(`payment_verified_${userId}`, 'true');

            // Set subscription end date
            const now = new Date();
            const endDate = new Date(now);

            switch(plan.interval) {
              case 'daily':
                endDate.setDate(now.getDate() + 1);
                break;
              case 'monthly':
                endDate.setMonth(now.getMonth() + 1);
                break;
              case 'yearly':
                endDate.setFullYear(now.getFullYear() + 1);
                break;
            }

            localStorage.setItem(`subscription_end_${userId}`, endDate.toISOString());
            localStorage.setItem('activeSubscription', 'true');

            // Record transaction details
            localStorage.setItem('txHash', txHash);
            localStorage.setItem('paymentMethod', paymentMethod);
            localStorage.setItem('paymentAmount', plan.cryptoPrice[paymentMethod] || '');
            localStorage.setItem('paymentTimestamp', new Date().toISOString());
          }

          console.log(`Payment confirmed for plan: ${plan.id}`);
          console.log(`Payment method: ${CRYPTO_INFO[paymentMethod].name} (${paymentMethod})`);
          console.log(`Amount: ${plan.cryptoPrice[paymentMethod]} ${CRYPTO_INFO[paymentMethod].symbol}`);
        } catch (error) {
          console.error('Error saving payment verification:', error);
        }
      }
    }, 1000);

    // Generate a realistic transaction hash based on the selected cryptocurrency
    let hash = '';
    switch(paymentMethod) {
      case 'btc':
        // Bitcoin transaction hash format
        hash = Array.from({length: 64}, () => Math.floor(Math.random() * 16).toString(16)).join('');
        break;
      case 'eth':
      case 'usdt':
        // Ethereum-style transaction hash format
        hash = '0x' + Array.from({length: 64}, () => Math.floor(Math.random() * 16).toString(16)).join('');
        break;
      case 'sol':
        // Solana transaction hash format
        hash = Array.from({length: 88}, () => Math.floor(Math.random() * 16).toString(16)).join('');
        break;
      default:
        hash = `0x${Math.random().toString(16).substr(2, 64)}`;
    }

    setTxHash(hash);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-md">
      <div className="w-full max-w-md rounded-lg border-2 border-[#00FF00]/70 bg-black/90 p-6 shadow-2xl backdrop-blur-sm">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <WalletIcon size={24} className="text-[#00FF00]" />
            <h2 className="font-display text-xl font-bold text-[#00FF00]">Secure Payment</h2>
          </div>
          {status !== 'processing' && (
            <button
              onClick={onClose}
              className="rounded-full p-1 text-muted-foreground hover:bg-[#00FF00]/20 hover:text-[#00FF00]"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M18 6 6 18" />
                <path d="m6 6 12 12" />
              </svg>
            </button>
          )}
        </div>

        {/* Cryptocurrency selection tabs */}
        <div className="mb-4 grid grid-cols-4 gap-1 rounded-md bg-black/90 p-1">
          {(Object.keys(CRYPTO_INFO) as CryptoType[]).map((crypto) => (
            <button
              key={crypto}
              className={`flex flex-col items-center justify-center rounded-md py-2 text-xs transition-colors ${
                paymentMethod === crypto
                  ? 'bg-[#00FF00]/20 text-[#00FF00]'
                  : 'bg-transparent text-muted-foreground hover:bg-[#00FF00]/10 hover:text-[#00FF00]/80'
              }`}
              onClick={() => setPaymentMethod(crypto)}
            >
              <img
                src={CRYPTO_INFO[crypto].logo}
                alt={CRYPTO_INFO[crypto].name}
                className="mb-1 h-6 w-6"
              />
              <span>{CRYPTO_INFO[crypto].symbol}</span>
            </button>
          ))}
        </div>

        {/* Main payment area */}
        {status === 'awaiting' && (
          <div className="rounded-lg border border-[#00FF00]/30 bg-black/50 p-4">
            <div className="mb-4 text-center">
              <div className="mb-2 text-sm text-muted-foreground">Pay exactly</div>
              <div className="text-2xl font-bold text-[#00FF00]">
                {plan.cryptoPrice[paymentMethod]} {CRYPTO_INFO[paymentMethod].symbol}
              </div>
              <div className="mt-1 text-xs text-muted-foreground">
                ~${plan.price} USD
              </div>
            </div>

            {/* QR Code */}
            <div className="flex justify-center my-4">
              <QRCode
                value={`${paymentMethod}:${DEPOSIT_ADDRESSES[paymentMethod]}?amount=${plan.cryptoPrice[paymentMethod]}`}
                size={180}
                borderColor="#00FF00"
                logoImage={CRYPTO_INFO[paymentMethod].logo}
                logoSize={36}
                logoBackgroundColor="#000000"
                animateBorder={true}
                scanGuide={true}
                pulsingIndicator={true}
                withGlitch={true}
              />
            </div>

            {/* Deposit Address */}
            <div className="mt-4">
              <div className="mb-1 text-xs text-muted-foreground">Deposit Address</div>
              <div className="relative">
                <div className="flex items-center rounded-md border border-[#00FF00]/30 bg-black/70 p-2">
                  <div className="flex-1 overflow-hidden text-ellipsis whitespace-nowrap font-mono text-sm text-[#00FF00]">
                    {DEPOSIT_ADDRESSES[paymentMethod]}
                  </div>
                  <button
                    onClick={copyAddressToClipboard}
                    className="ml-2 flex items-center justify-center rounded-md bg-[#00FF00]/10 p-1 text-[#00FF00] hover:bg-[#00FF00]/20"
                  >
                    {copySuccess ? 'Copied!' : <CopyIcon size={16} />}
                  </button>
                </div>
              </div>
            </div>

            {/* Timer */}
            <div className="mt-4 text-center">
              <div className="text-xs text-muted-foreground">Time remaining</div>
              <div className="font-mono text-sm text-[#00FF00]">{formatTimeRemaining()}</div>
            </div>

            {/* Test button for demo */}
            <div className="mt-6">
              <Button
                onClick={verifyPayment}
                className="w-full bg-[#00FF00] text-black hover:bg-[#00CC00]"
              >
                Test Payment (Demo)
              </Button>
            </div>
          </div>
        )}

        {/* Processing state */}
        {status === 'processing' && (
          <div className="rounded-lg border border-[#00FF00]/30 bg-black/50 p-4 text-center">
            <div className="mb-4">
              <div className="text-lg font-bold text-[#00FF00]">Processing Payment</div>
              <div className="text-sm text-muted-foreground">Waiting for blockchain confirmation</div>
            </div>

            {/* Progress bar */}
            <div className="mb-4">
              <div className="h-2 w-full overflow-hidden rounded-full bg-[#00FF00]/10">
                <div
                  className="h-full bg-[#00FF00]"
                  style={{ width: `${confirmationProgress}%` }}
                />
              </div>
              <div className="mt-1 text-xs text-muted-foreground">
                {confirmationProgress}/100 confirmations
              </div>
            </div>

            {/* Transaction hash */}
            <div className="mt-4">
              <div className="mb-1 text-xs text-muted-foreground">Transaction Hash</div>
              <div className="overflow-hidden text-ellipsis whitespace-nowrap rounded-md border border-[#00FF00]/30 bg-black/70 p-2 font-mono text-xs text-[#00FF00]">
                {txHash}
              </div>
            </div>
          </div>
        )}

        {/* Confirmed state */}
        {status === 'confirmed' && (
          <div className="rounded-lg border border-[#00FF00]/30 bg-black/50 p-4 text-center">
            <div className="mb-4">
              <div className="text-2xl font-bold text-[#00FF00]">Payment Confirmed!</div>
              <div className="text-sm text-muted-foreground">
                Your subscription has been activated
              </div>
            </div>

            <div className="my-4 flex justify-center">
              <div className="rounded-full border-2 border-[#00FF00] p-3">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="32"
                  height="32"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="#00FF00"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                  <polyline points="22 4 12 14.01 9 11.01"></polyline>
                </svg>
              </div>
            </div>

            <div className="mt-4">
              <Button onClick={onClose} className="w-full bg-[#00FF00] text-black hover:bg-[#00CC00]">
                Continue to Dashboard
              </Button>
            </div>
          </div>
        )}

        {/* Payment Activity Feed */}
        <PaymentActivityFeed
          paymentMethod={paymentMethod}
          status={status}
          amount={plan.cryptoPrice[paymentMethod]}
        />

        <div className="mt-6 border-t border-[#00FF00]/30 pt-4">
          <p className="text-xs text-[#00FF00]/70">
            <span className="font-semibold text-[#00FF00] font-mono">SECURE PAYMENT:</span> All transactions are processed on the
            blockchain and are fully encrypted. Your funds go directly to our payment address with no intermediaries.
          </p>
          <div className="mt-3 font-mono text-[10px] text-[#00FF00]/50 flex justify-between">
            <span>NODE: {getNodeId()}</span>
            <span>GATEWAY: VERIFIED</span>
            <span>PROTOCOL: ENCRYPTED</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentProcessor;
