import React, { useState, useEffect } from 'react';
import { WalletIcon, RefreshIcon } from '../icons/Icons';
import QRCode from '../ui/QRCode';
import { PaymentActivityFeed } from '../payment/PaymentActivityFeed';
// import * as api from '../../lib/api'; // Uncomment when backend is available

// Payment statuses
type PaymentStatus = 'awaiting' | 'processing' | 'confirmed' | 'failed';

// Cryptocurrency options
type CryptoType = 'btc' | 'eth' | 'usdt' | 'sol';

interface Plan {
  id: string;
  name: string;
  price: string;
  cryptoPrice: {
    btc: string;
    eth: string;
    usdt?: string;
    sol?: string;
  };
  interval: 'daily' | 'monthly' | 'yearly';
}

// These would be your actual deposit addresses
const DEPOSIT_ADDRESSES: Record<CryptoType, string> = {
  btc: 'new_btc_address_here', // Update this line with the new BTC address
  eth: 'new_eth_address_here', // Update this line with the new ETH address
  usdt: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
  sol: '5YNmS1R9nNSCDzb5a7mMJ1dwK9uHeAAQmx5tdCie1qJ3'
};
