import React, { useState, useEffect } from 'react';
import { Button } from './ui/Button';
import { ProxyChainIcon, SecureLinkIcon, LockIcon, ShieldIcon } from './icons/Icons';

const LandingPage: React.FC<{ onGetStarted: () => void }> = ({ onGetStarted }) => {
  const [showContent, setShowContent] = useState(false);
  const [currentFeatureIndex, setCurrentFeatureIndex] = useState(0);

  // Matrix-style text animation
  const MatrixText: React.FC<{ text: string, delay?: number }> = ({ text, delay = 0 }) => {
    const [displayText, setDisplayText] = useState('');

    useEffect(() => {
      const timeout = setTimeout(() => {
        let currentIndex = 0;
        const interval = setInterval(() => {
          if (currentIndex <= text.length) {
            setDisplayText(text.substring(0, currentIndex));
            currentIndex++;
          } else {
            clearInterval(interval);
          }
        }, 30);

        return () => clearInterval(interval);
      }, delay);

      return () => clearTimeout(timeout);
    }, [text, delay]);

    return <span>{displayText}<span className="text-[#00FF00] animate-pulse">_</span></span>;
  };

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setShowContent(true);
    }, 1000);

    // Feature rotation
    const featureInterval = setInterval(() => {
      setCurrentFeatureIndex(prev => (prev + 1) % features.length);
    }, 3000);

    return () => {
      clearTimeout(timer);
      clearInterval(featureInterval);
    };
  }, []);

  const features = [
    {
      icon: <ProxyChainIcon size={24} className="text-[#00FF00]" />,
      title: "Dynamic Proxy Chain",
      description: "Route your traffic through multiple secure nodes for maximum anonymity"
    },
    {
      icon: <ShieldIcon size={24} className="text-[#00FF00]" />,
      title: "DNS Changer",
      description: "Prevent DNS leaks and bypass censorship with automatic DNS rotation"
    },
    {
      icon: <SecureLinkIcon size={24} className="text-[#00FF00]" />,
      title: "MAC Address Rotation",
      description: "Defeat device fingerprinting with automated MAC cycling"
    },
    {
      icon: <LockIcon size={24} className="text-[#00FF00]" />,
      title: "Pattern Randomizer",
      description: "Confuse traffic analysis with deliberate connectivity pattern randomization"
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Hero Section */}
      <div className="relative h-screen flex flex-col items-center justify-center overflow-hidden px-4">
        {/* Background matrix effect */}
        <div className="absolute inset-0 opacity-20 pointer-events-none overflow-hidden">
          <div className="w-full h-full flex">
            {Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="flex-1 flex flex-col">
                {Array.from({ length: 20 }).map((_, j) => (
                  <div
                    key={j}
                    className="text-[#00FF00] text-opacity-50 flex-1 text-sm"
                    style={{
                      animationDelay: `${(i + j) * 0.1}s`,
                      animationDuration: `${2 + Math.random() * 2}s`
                    }}
                  >
                    {Math.random().toString(36).substring(2, 5)}
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>

        {/* Foreground content */}
        <div className="z-10 text-center">
          <div className="flex items-center justify-center mb-6">
            <div className="relative">
              <ProxyChainIcon size={80} className="text-[#00FF00] animate-pulse" />
              <div className="absolute inset-0 rounded-full shadow-lg shadow-[#00FF00]/30 animate-ping opacity-20"></div>
            </div>
          </div>

          <h1 className="text-4xl sm:text-6xl font-bold mb-4 font-mono tracking-tighter">
            <span className="text-[#00FF00]">PROX</span>
            <span className="text-[#A855F7]">GUARD</span>
          </h1>

          <div className="h-16">
            {showContent && (
              <p className="text-lg sm:text-xl text-[#00FF00]/80 font-mono">
                <MatrixText text="OPSEC PRE-RELEASE OF EXDEX" delay={500} />
              </p>
            )}
          </div>

          <p className="max-w-2xl mx-auto mt-4 text-gray-400 font-light">
            Advanced privacy protection that creates an impenetrable shield around your digital presence,
            offering unparalleled anonymity and robust protection against surveillance.
          </p>

          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button
              onClick={onGetStarted}
              className="w-full sm:w-auto px-8 py-3 bg-gradient-to-r from-[#00FF00]/80 to-[#00FFAA]/80 text-black font-bold text-lg hover:from-[#00FF00] hover:to-[#00FFAA] border border-[#00FF00]/50"
            >
              ACCESS SYSTEM
            </Button>

            <a
              href="/proxy-chain-manager-production.zip"
              download
              className="w-full sm:w-auto px-8 py-3 bg-black border-2 border-[#00FF00] text-[#00FF00] font-bold text-lg hover:bg-[#00FF00]/10 transition-colors flex items-center justify-center gap-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
                <line x1="12" y1="15" x2="12" y2="3"></line>
              </svg>
              DOWNLOAD
            </a>

            <div className="mt-4 text-xs text-[#00FF00]/50 font-mono">
              BREACH THE SYSTEM. EVADE THE TRACKERS. REMAIN ANONYMOUS.
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2 animate-bounce">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#00FF00"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M7 13l5 5 5-5M7 6l5 5 5-5"/>
          </svg>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-20 bg-gradient-to-b from-black to-gray-900">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-[#00FF00] mb-16 font-mono">CORE SECURITY SYSTEMS</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className={`bg-black/80 p-6 rounded-lg border-2 transition-all duration-300 ${
                  currentFeatureIndex === index
                    ? 'border-[#00FF00] shadow-lg shadow-[#00FF00]/20'
                    : 'border-gray-800'
                }`}
              >
                <div className="flex items-center mb-4">
                  {feature.icon}
                  <h3 className="font-bold ml-2 text-white">{feature.title}</h3>
                </div>
                <p className="text-gray-400 text-sm">{feature.description}</p>
                {currentFeatureIndex === index && (
                  <div className="mt-4 h-1 w-full bg-gradient-to-r from-[#00FF00] to-transparent rounded-full"></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Warning Section */}
      <div className="py-16 bg-black text-center">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold text-[#FF3333] mb-4">⚠️ WARNING</h2>
            <p className="text-gray-400">
              This software is provided for legitimate privacy protection purposes only.
              The developers take no responsibility for any misuse of this technology.
              Use at your own risk and in compliance with all applicable laws.
            </p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="py-8 bg-black/90 border-t border-[#00FF00]/20">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center mb-4">
            <ProxyChainIcon size={24} className="text-[#00FF00]" />
            <div className="ml-2 h-4 w-px bg-[#00FF00]/30"></div>
            <span className="ml-2 text-[#00FF00] font-mono">PROXGUARD</span>
          </div>
          <p className="text-sm text-gray-500">© 2025 ProxGuard | OPSEC Pre-Release of ExDeX</p>
          <p className="mt-1 text-xs text-gray-600">Secure · Private · Untraceable</p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
