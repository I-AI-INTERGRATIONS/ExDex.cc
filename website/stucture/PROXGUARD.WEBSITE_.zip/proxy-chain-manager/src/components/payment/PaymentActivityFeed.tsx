import React, { useState, useEffect } from 'react';

interface ActivityItem {
  id: string;
  message: string;
  timestamp: Date;
  type: 'info' | 'success' | 'warning' | 'error';
  highlight?: boolean;
}

interface PaymentActivityFeedProps {
  paymentMethod: string;
  status: 'awaiting' | 'processing' | 'confirmed' | 'failed';
  amount?: string;
}

export const PaymentActivityFeed = ({ paymentMethod, status, amount }: PaymentActivityFeedProps) => {
  const [activities, setActivities] = useState<ActivityItem[]>([]);

  // Generate a realistic transaction hash
  const generateHash = (type: string) => {
    if (type === 'eth' || type === 'usdt') {
      return `0x${Array.from({length: 10}, () => Math.floor(Math.random() * 16).toString(16)).join('')}...`;
    }
    if (type === 'btc') {
      return `${Array.from({length: 10}, () => Math.floor(Math.random() * 16).toString(16)).join('')}...`;
    }
    if (type === 'sol') {
      return `${Array.from({length: 10}, () => Math.floor(Math.random() * 16).toString(16)).join('')}...`;
    }
    return `${Array.from({length: 8}, () => Math.floor(Math.random() * 16).toString(16)).join('')}...`;
  };

  // Generate node ID
  const getNodeId = () => {
    return 'node_' + Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  };

  // Get network name based on payment method
  const getNetworkName = (method: string) => {
    switch(method.toLowerCase()) {
      case 'btc': return 'Bitcoin Mainnet';
      case 'eth': return 'Ethereum Mainnet';
      case 'usdt': return 'USDT-TRC20';
      case 'sol': return 'Solana Mainnet';
      default: return 'Blockchain Network';
    }
  };

  // Simulate blockchain network activity
  useEffect(() => {
    // Initial activity
    const initialActivities: ActivityItem[] = [
      {
        id: '1',
        message: `[GATE] Initialized ${paymentMethod.toUpperCase()} payment gateway`,
        timestamp: new Date(),
        type: 'info'
      },
      {
        id: '2',
        message: `[NET] Connected to ${getNetworkName(paymentMethod)} successfully`,
        timestamp: new Date(),
        type: 'info'
      }
    ];

    setActivities(initialActivities);

    // If we're awaiting payment, simulate some network activity
    if (status === 'awaiting') {
      const networkActivityInterval = setInterval(() => {
        const networkActivities = [
          `[SCAN] Checking ${paymentMethod.toUpperCase()} mempool for incoming tx`,
          `[NET] Validating connection to pool.${paymentMethod.toLowerCase()}.gateway.net`,
          `[NODE] ${getNodeId()} connected to payment verification network`,
          `[GATE] Waiting for transaction confirmation (0/3)`,
          `[SYNC] Scanning blockchain for incoming transactions`,
          `[PEER] Active peers: ${Math.floor(Math.random() * 5) + 12}`,
          `[GATE] Listening to ${paymentMethod.toUpperCase()} network...`,
          `[MEM] Mempool size: ${Math.floor(Math.random() * 2000) + 1000} txs`
        ];

        const randomActivity = networkActivities[Math.floor(Math.random() * networkActivities.length)];

        setActivities(prev => [
          ...prev,
          {
            id: Date.now().toString(),
            message: randomActivity,
            timestamp: new Date(),
            type: 'info' as const
          }
        ].slice(-6)); // Keep only the most recent activities
      }, 3500);

      return () => clearInterval(networkActivityInterval);
    }

    // If processing, show verification activities
    if (status === 'processing') {
      const txHash = generateHash(paymentMethod);

      const processingActivities: ActivityItem[] = [
        {
          id: Date.now().toString(),
          message: `[TX] Transaction ${txHash} detected on network`,
          timestamp: new Date(),
          type: 'info',
          highlight: true
        },
        {
          id: (Date.now() + 1).toString(),
          message: `[GATE] Starting verification process...`,
          timestamp: new Date(),
          type: 'info'
        }
      ];

      setActivities(prev => [...prev, ...processingActivities].slice(-6));

      const verificationInterval = setInterval(() => {
        const confirmationCount = Math.floor(Math.random() * 2) + 1;

        const verificationActivities = [
          `[VERIFY] Waiting for block confirmation (${confirmationCount}/3)`,
          `[AMOUNT] Verifying transaction amount = ${amount}`,
          `[GATE] Checking transaction for double-spend risk: NONE`,
          `[BLOCK] Transaction included in latest block ${Math.floor(Math.random() * 90000) + 700000}`,
          `[NODE] ${getNodeId()} confirming transaction validity`,
          `[VERIFY] Received confirmation from node ${getNodeId()}`,
          `[GATE] Signature validation: VALID`,
        ];

        const randomActivity = verificationActivities[Math.floor(Math.random() * verificationActivities.length)];

        setActivities(prev => [
          ...prev,
          {
            id: Date.now().toString(),
            message: randomActivity,
            timestamp: new Date(),
            type: 'info' as const
          }
        ].slice(-6));
      }, 1800);

      return () => clearInterval(verificationInterval);
    }

    // If confirmed, show confirmation activities
    if (status === 'confirmed') {
      const txHash = generateHash(paymentMethod);
      const blockNumber = Math.floor(Math.random() * 90000) + 700000;

      setActivities([
        {
          id: '1',
          message: `[TX] Transaction ${txHash} confirmed by network`,
          timestamp: new Date(),
          type: 'success',
          highlight: true
        },
        {
          id: '2',
          message: `[CONFIRM] Block ${blockNumber}: Payment verified (3/3)`,
          timestamp: new Date(),
          type: 'success'
        },
        {
          id: '3',
          message: `[GATE] Payment successfully processed and account credited`,
          timestamp: new Date(),
          type: 'success'
        },
        {
          id: '4',
          message: `[ACCESS] Subscription activated and access granted`,
          timestamp: new Date(),
          type: 'success'
        }
      ]);
    }

    // If failed, show error activities
    if (status === 'failed') {
      setActivities([
        {
          id: '1',
          message: `[TIMEOUT] Payment session expired after 15 minutes`,
          timestamp: new Date(),
          type: 'error'
        },
        {
          id: '2',
          message: `[GATE] No transaction detected within timeframe`,
          timestamp: new Date(),
          type: 'error'
        },
        {
          id: '3',
          message: `[VERIFY] Payment verification process aborted`,
          timestamp: new Date(),
          type: 'error'
        },
        {
          id: '4',
          message: `[GATE] Gateway connection closed`,
          timestamp: new Date(),
          type: 'error'
        }
      ]);
    }
  }, [paymentMethod, status, amount]);

  const formatTimestamp = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    });
  };

  // Matrix-green #00FF00
  const MATRIX_GREEN = '#00FF00';

  return (
    <div className="mb-4 rounded-md border border-[#00FF00]/40 bg-black backdrop-blur-sm overflow-hidden">
      <div className="border-b border-[#00FF00]/40 bg-black px-3 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className={`h-2.5 w-2.5 rounded-full ${
              status === 'awaiting' ? 'bg-[#00FF00]/70 animate-pulse' :
              status === 'processing' ? 'bg-[#00FF00] animate-pulse' :
              status === 'confirmed' ? 'bg-[#00FF00]' :
              'bg-red-500'
            }`} />
            <h3 className="text-sm font-mono font-medium text-[#00FF00]">PAYMENT GATEWAY</h3>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-xs font-mono text-[#00FF00]">
              {status === 'awaiting' ? 'AWAITING PAYMENT' :
               status === 'processing' ? 'PROCESSING' :
               status === 'confirmed' ? 'CONFIRMED' :
               'FAILED'}
            </span>
          </div>
        </div>
      </div>

      <div className="max-h-48 overflow-y-auto p-2 bg-black scrollbar-thin font-mono">
        {activities.map((activity) => (
          <div
            key={activity.id}
            className={`mb-1.5 px-2 py-1 text-xs ${
              activity.highlight ? 'bg-[#00FF00]/10' : ''
            } ${
              activity.type === 'success' ? 'border-l-2 border-[#00FF00]' :
              activity.type === 'error' ? 'border-l-2 border-red-500' :
              activity.type === 'warning' ? 'border-l-2 border-yellow-400' :
              'border-l-2 border-[#00FF00]/40'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <span className={`font-mono ${
                activity.type === 'success' ? 'text-[#00FF00]' :
                activity.type === 'error' ? 'text-red-400' :
                activity.type === 'warning' ? 'text-yellow-400' :
                'text-[#00FF00]'
              }`}>
                {activity.message}
              </span>
              <span className="whitespace-nowrap text-[10px] text-[#00FF00]/70">
                {formatTimestamp(activity.timestamp)}
              </span>
            </div>
          </div>
        ))}

        {activities.length === 0 && (
          <div className="py-2 text-center text-xs text-[#00FF00]/70">
            No payment activity to display
          </div>
        )}
      </div>

      <div className="flex items-center justify-between border-t border-[#00FF00]/40 bg-black px-3 py-1.5">
        <span className="text-xs font-mono text-[#00FF00]">
          {status === 'awaiting' ? 'Listening for transaction on blockchain...' :
           status === 'processing' ? 'Verifying transaction: signature check in progress...' :
           status === 'confirmed' ? 'Transaction confirmed: 3/3 verifications' :
           'Payment session expired: timeout after 15 min'}
        </span>
        {(status === 'awaiting' || status === 'processing') && (
          <div className="flex items-center">
            <svg className="h-3 w-3 animate-spin text-[#00FF00]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
            <span className="ml-2 text-[10px] font-mono text-[#00FF00]">ACTIVE</span>
          </div>
        )}
      </div>
    </div>
  );
};
