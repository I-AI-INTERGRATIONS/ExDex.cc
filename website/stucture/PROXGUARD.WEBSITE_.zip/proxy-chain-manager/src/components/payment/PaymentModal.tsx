import React, { useState } from 'react';
import { LockIcon } from '../icons/Icons';
import { Button } from '../ui/Button';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PaymentModal = ({ isOpen, onClose }: PaymentModalProps) => {
  const [isQRCodesVisible, setIsQRCodesVisible] = useState(false);

  const toggleQRCodes = () => {
    setIsQRCodesVisible(!isQRCodesVisible);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-lg border border-primary-darker bg-background p-6 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-primary">
            <LockIcon size={20} />
            <h3 className="text-lg font-semibold">Payment Required</h3>
          </div>
          <div className="rounded bg-error-red/90 px-2 py-0.5 text-xs font-semibold text-background">
            ONE-TIME PAYMENT
          </div>
        </div>

        <div className="mt-6 text-center">
          <h2 className="mb-4 text-xl font-bold text-primary uppercase">Premium Access</h2>
          <p className="text-foreground">Unlock all features with a one-time payment of:</p>

          <div className="mt-4 flex justify-center gap-4">
            <Button variant="primary" className="font-mono font-bold">
              0.01 ETH
            </Button>
            <Button variant="primary" className="font-mono font-bold">
              0.0005 BTC
            </Button>
          </div>

          <p className="mt-4 text-xs text-muted-foreground">
            Services will be cut immediately upon expiration
          </p>
        </div>

        {isQRCodesVisible && (
          <div className="mt-6 rounded-md border border-primary-darker bg-background/80 p-4">
            <div className="mb-4">
              <p className="mb-1 text-xs text-muted-foreground">ETH/EVM:</p>
              <p className="break-all font-mono text-xs text-foreground">
                0x45fD9ba0c6a35a197dB8C8413b631C53386dC43D
              </p>
            </div>
            <div>
              <p className="mb-1 text-xs text-muted-foreground">BTC:</p>
              <p className="break-all font-mono text-xs text-foreground">
                bc1q8nvdka59fah5tc2vydx7n0c500a5rp764ckvnqdqltw9ztq9wsgssy9jcr
              </p>
            </div>
          </div>
        )}

        <div className="mt-6 flex gap-3">
          <Button
            variant="secondary"
            fullWidth
            onClick={toggleQRCodes}
          >
            {isQRCodesVisible ? 'Hide Payment QR Codes' : 'Show Payment QR Codes'}
          </Button>
          <Button
            variant="ghost"
            className="border border-primary-darker"
            onClick={onClose}
          >
            Close
          </Button>
        </div>
      </div>
    </div>
  );
};
