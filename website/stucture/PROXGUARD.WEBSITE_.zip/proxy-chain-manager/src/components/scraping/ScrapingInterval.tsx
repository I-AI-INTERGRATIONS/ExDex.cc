import React, { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { InfoIcon, PlayIcon } from '../icons/Icons';

type IntervalOption = {
  id: string;
  value: number;
  label: string;
  description: string;
};

export const ScrapingInterval = () => {
  const intervalOptions: IntervalOption[] = [
    {
      id: 'aggressive',
      value: 2,
      label: '2 seconds (Aggressive)',
      description: 'Fastest data collection, but higher chance of detection',
    },
    {
      id: 'balanced',
      value: 6,
      label: '6 seconds (Balanced)',
      description: 'Good balance between speed and stealth',
    },
    {
      id: 'stealth',
      value: 10,
      label: '10 seconds (Stealth)',
      description: 'Slower data collection with minimal detection risk',
    },
  ];

  const [selectedInterval, setSelectedInterval] = useState<string>('balanced');
  const [isRunning, setIsRunning] = useState(false);

  const handleOptionSelect = (id: string) => {
    setSelectedInterval(id);
  };

  const handleStartScraping = () => {
    setIsRunning(!isRunning);
  };

  return (
    <div className="my-6">
      <Card>
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-medium text-blue-400">Scraping Interval</h3>
              <InfoIcon size={16} className="text-muted-foreground" />
            </div>
            <p className="mt-1 text-sm text-blue-300">
              Configure how frequently the system scrapes data through the proxy chain
            </p>
          </div>
        </div>

        <div className="mt-4 space-y-3">
          {intervalOptions.map((option) => (
            <div
              key={option.id}
              className={`flex items-center rounded-md border p-3 cursor-pointer transition-colors ${
                selectedInterval === option.id
                  ? 'border-primary bg-primary/10'
                  : 'border-primary-darker bg-background'
              }`}
              onClick={() => handleOptionSelect(option.id)}
            >
              <div className="mr-3 flex h-5 w-5 items-center justify-center rounded-full border">
                {selectedInterval === option.id && (
                  <div className="h-3 w-3 rounded-full bg-primary" />
                )}
              </div>
              <div>
                <div className="font-medium">{option.label}</div>
                <div className="text-xs text-muted-foreground">{option.description}</div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 flex gap-3">
          <Button
            variant={isRunning ? 'danger' : 'primary'}
            icon={<PlayIcon size={16} />}
            onClick={handleStartScraping}
            className="flex-1"
          >
            {isRunning ? 'Stop Scraping' : 'Start Scraping'}
          </Button>

          <Button variant="secondary" className="flex-1">
            Save Settings
          </Button>
        </div>
      </Card>
    </div>
  );
};
