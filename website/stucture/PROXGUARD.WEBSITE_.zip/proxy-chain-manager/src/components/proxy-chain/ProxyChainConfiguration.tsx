import React, { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { TrashIcon, AddIcon, SaveIcon } from '../icons/Icons';

interface ProxyItem {
  id: string;
  type: string;
  host: string;
  port: string;
  username?: string;
  password?: string;
}

export const ProxyChainConfiguration = () => {
  // Add more default proxies for better testing
  const [proxies, setProxies] = useState<ProxyItem[]>([
    { id: 'proxy1', type: 'HTTP', host: '192.168.1.1', port: '8080' },
    { id: 'proxy2', type: 'SOCKS5', host: '10.0.0.1', port: '1080' },
    { id: 'proxy3', type: 'HTTP', host: '45.76.123.45', port: '3128', username: 'secure', password: '******' },
    { id: 'proxy4', type: 'SOCKS5', host: '172.16.5.10', port: '1080' },
    { id: 'proxy5', type: 'HTTPS', host: '88.99.153.22', port: '8080' },
  ]);

  const [newProxy, setNewProxy] = useState<Omit<ProxyItem, 'id'>>({
    type: 'HTTP',
    host: '',
    port: '',
    username: '',
    password: '',
  });

  const handleAddProxy = () => {
    if (!newProxy.host || !newProxy.port) return;

    const id = `proxy${Date.now()}`;
    setProxies([...proxies, { ...newProxy, id }]);
    setNewProxy({
      type: 'HTTP',
      host: '',
      port: '',
      username: '',
      password: '',
    });
  };

  const handleRemoveProxy = (id: string) => {
    setProxies(proxies.filter(proxy => proxy.id !== id));
  };

  const handleInputChange = (field: keyof Omit<ProxyItem, 'id'>, value: string) => {
    setNewProxy(prev => ({ ...prev, [field]: value }));
  };

  const handleSelectChange = (value: string) => {
    setNewProxy(prev => ({ ...prev, type: value }));
  };

  return (
    <div className="my-6">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-2xl font-bold uppercase text-primary">Proxy Chain Configuration</h2>
        <Button
          variant="secondary"
          icon={<SaveIcon size={16} />}
          size="sm"
        >
          Save Chain Configuration
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <h3 className="mb-4 text-lg font-medium text-green-400">Current Proxy Chain</h3>

          {proxies.length === 0 ? (
            <p className="text-muted-foreground">No proxies configured. Add a proxy to get started.</p>
          ) : (
            <div className="space-y-2">
              {proxies.map((proxy, index) => (
                <div
                  key={proxy.id}
                  className="flex items-center justify-between rounded-md border border-primary-darker bg-background/50 p-3"
                >
                  <div className="flex items-center gap-2">
                    <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-background text-xs">
                      {index + 1}
                    </div>
                    <div>
                      <span className="font-mono text-sm text-primary">
                        {proxy.type}{' '}
                      </span>
                      <span className="font-mono text-sm">
                        {proxy.host}:{proxy.port}
                      </span>
                      {proxy.username && (
                        <span className="ml-2 text-xs opacity-70">
                          (Auth: {proxy.username})
                        </span>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    icon={<TrashIcon size={16} className="text-error-red" />}
                    onClick={() => handleRemoveProxy(proxy.id)}
                  />
                </div>
              ))}
            </div>
          )}

          <div className="mt-4 p-3 border border-primary-darker/50 rounded-md">
            <h4 className="text-sm font-medium mb-2 text-green-300">Connection Status</h4>
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 bg-green-500 rounded-full"></div>
              <span className="text-xs text-green-200">All proxies connected and responding</span>
            </div>
            <div className="mt-2 text-xs text-green-200">Average latency: 78ms</div>
          </div>
        </Card>

        <Card>
          <h3 className="mb-4 text-lg font-medium text-fuchsia-400">Add New Proxy</h3>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs mb-1 text-fuchsia-300">Type</label>
                <Select
                  value={newProxy.type}
                  onChange={handleSelectChange}
                  options={[
                    { label: 'HTTP', value: 'HTTP' },
                    { label: 'HTTPS', value: 'HTTPS' },
                    { label: 'SOCKS4', value: 'SOCKS4' },
                    { label: 'SOCKS5', value: 'SOCKS5' },
                  ]}
                />
              </div>
              <div>
                <label className="block text-xs mb-1 text-fuchsia-300">Port</label>
                <Input
                  value={newProxy.port}
                  onChange={(e) => handleInputChange('port', e.target.value)}
                  placeholder="8080"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs mb-1 text-fuchsia-300">Host / IP Address</label>
              <Input
                value={newProxy.host}
                onChange={(e) => handleInputChange('host', e.target.value)}
                placeholder="127.0.0.1"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs mb-1 text-fuchsia-300">Username (optional)</label>
                <Input
                  value={newProxy.username}
                  onChange={(e) => handleInputChange('username', e.target.value)}
                  placeholder="Username"
                />
              </div>
              <div>
                <label className="block text-xs mb-1 text-fuchsia-300">Password (optional)</label>
                <Input
                  type="password"
                  value={newProxy.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  placeholder="Password"
                />
              </div>
            </div>

            <Button
              variant="primary"
              icon={<AddIcon size={16} />}
              onClick={handleAddProxy}
              disabled={!newProxy.host || !newProxy.port}
              className="w-full mt-2"
            >
              Add Proxy to Chain
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};
