import React from 'react';
import { Card } from '../ui/Card';
import { NodeIcon, ArrowRightIcon, RefreshIcon } from '../icons/Icons';
import { Button } from '../ui/Button';

interface NodeProps {
  type: 'entry' | 'relay' | 'exit';
  title: string;
  latency: number;
  status: 'active' | 'error' | 'inactive';
  index?: number;
  id: string;
}

const Node = ({ type, title, latency, status, index }: NodeProps) => {
  return (
    <div className="flex flex-col items-center">
      <div className={`relative flex h-14 w-14 items-center justify-center rounded-full ${
        status === 'active' ? 'bg-background border-2 border-primary' :
        status === 'error' ? 'bg-background border-2 border-error-red' :
        'bg-background border-2 border-primary-darker'
      }`}>
        <NodeIcon
          size={32}
          className={
            status === 'active' ? 'text-primary' :
            status === 'error' ? 'text-error-red' :
            'text-muted-foreground'
          }
        />
        {index !== undefined && (
          <div className="absolute -top-2 -right-2 flex h-6 w-6 items-center justify-center rounded-full bg-background border border-primary text-xs text-primary">
            {index}
          </div>
        )}
      </div>
      <div className="mt-2 text-center">
        <div className="text-sm font-medium">{title}</div>
        <div className={`text-xs font-mono ${
          status === 'active' ? 'text-primary' :
          status === 'error' ? 'text-error-red' :
          'text-muted-foreground'
        }`}>
          {latency}ms
        </div>
      </div>
    </div>
  );
};

export const ProxyChainVisualization = () => {
  const nodes: NodeProps[] = [
    { id: 'entry', type: 'entry', title: 'Entry Node', latency: 45, status: 'active' },
    { id: 'relay1', type: 'relay', title: 'Relay 1', latency: 78, status: 'active' },
    { id: 'relay2', type: 'relay', title: 'Relay 2', latency: 120, status: 'error' },
    { id: 'exit', type: 'exit', title: 'Exit Node', latency: 95, status: 'active' },
  ];

  return (
    <div className="my-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-primary uppercase">Proxy Chain Visualization</h2>
        <Button
          variant="secondary"
          icon={<RefreshIcon size={16} />}
          size="sm"
        >
          Refresh
        </Button>
      </div>

      <Card>
        <div className="flex justify-center items-center space-x-2 py-4">
          {nodes.map((node, index) => (
            <React.Fragment key={node.id}>
              <Node {...node} index={index} />
              {index < nodes.length - 1 && (
                <ArrowRightIcon
                  size={32}
                  className={
                    nodes[index].status === 'active' && nodes[index + 1].status === 'active'
                      ? 'text-primary'
                      : nodes[index].status === 'error' || nodes[index + 1].status === 'error'
                      ? 'text-error-red'
                      : 'text-muted-foreground'
                  }
                />
              )}
            </React.Fragment>
          ))}
        </div>

        <div className="mt-6 bg-primary-darker/30 rounded-md p-3">
          <h3 className="text-sm font-mono text-muted-foreground uppercase mb-2">Chain Summary</h3>
          <div className="flex gap-4">
            <div className="rounded-md bg-background/30 px-3 py-1 text-sm">
              <span className="text-foreground">{nodes.length} Nodes</span>
            </div>
            <div className="rounded-md bg-background/30 px-3 py-1 text-sm">
              <span className="text-foreground">{nodes.filter(n => n.status === 'active').length} Active</span>
            </div>
            <div className="rounded-md bg-background/30 px-3 py-1 text-sm">
              <span className="text-foreground">{nodes.filter(n => n.status === 'error').length} Errors</span>
            </div>
            <div className="rounded-md bg-background/30 px-3 py-1 text-sm">
              <span className="text-foreground">{nodes.reduce((acc, node) => acc + node.latency, 0)}ms Total Latency</span>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};
