/**
 * Developer Utility for Bypassing Payment Verification
 *
 * WARNING: FOR DEVELOPMENT PURPOSES ONLY!
 * Do not include this in production builds.
 */

/**
 * Bypass payment verification by setting localStorage values
 * @param durationInDays Number of days to set the subscription for (default: 365)
 * @returns boolean indicating success or failure
 */
export const bypassPaymentVerification = (durationInDays = 365): boolean => {
  try {
    // Generate a user ID if not present
    const userId = localStorage.getItem('userId') || 'dev-' + Date.now();
    localStorage.setItem('userId', userId);

    // Set payment as verified
    localStorage.setItem(`payment_verified_${userId}`, 'true');

    // Set subscription end date
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + durationInDays);
    localStorage.setItem(`subscription_end_${userId}`, endDate.toISOString());

    // Set active subscription flag
    localStorage.setItem('activeSubscription', 'true');

    // Create a fake transaction hash
    localStorage.setItem('txHash', '0x' + Array(64).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join(''));

    // Set other payment details
    localStorage.setItem('paymentMethod', 'btc');
    localStorage.setItem('paymentAmount', '0.01');
    localStorage.setItem('paymentTimestamp', new Date().toISOString());

    console.log('%c PAYMENT BYPASSED ', 'background: #00FF00; color: #000; font-weight: bold; padding: 2px 5px;');
    console.log(`Subscription active until: ${endDate.toLocaleString()}`);

    return true;
  } catch (error) {
    console.error('Error bypassing payment:', error);
    return false;
  }
};

/**
 * Remove payment verification (simulate an expired subscription)
 * @returns boolean indicating success or failure
 */
export const removePaymentVerification = (): boolean => {
  try {
    const userId = localStorage.getItem('userId');
    if (userId) {
      localStorage.removeItem(`payment_verified_${userId}`);
      localStorage.removeItem(`subscription_end_${userId}`);
    }

    localStorage.removeItem('activeSubscription');
    localStorage.removeItem('txHash');
    localStorage.removeItem('paymentMethod');
    localStorage.removeItem('paymentAmount');
    localStorage.removeItem('paymentTimestamp');

    console.log('%c PAYMENT VERIFICATION REMOVED ', 'background: #FF0000; color: #FFF; font-weight: bold; padding: 2px 5px;');

    return true;
  } catch (error) {
    console.error('Error removing payment verification:', error);
    return false;
  }
};

// How to use:
//
// To bypass payment in the browser console:
// 1. Copy and paste this entire file into your browser console
// 2. Run: bypassPaymentVerification()
// 3. Refresh the page
//
// To remove payment verification:
// 1. Run: removePaymentVerification()
// 2. Refresh the page
