/**
 * Owner Access Utilities
 *
 * This file contains functions for owner-only access to the application.
 * As the repository owner, you can use these functions to bypass payment
 * requirements when using the application.
 */

import { authenticateOwner, isOwner } from '../lib/paymentCheck';

/**
 * Grant owner access to the application
 * This function should be called from the browser console
 *
 * @param ownerKey Your owner authentication key
 * @returns boolean indicating if authentication was successful
 */
export const grantOwnerAccess = (ownerKey: string): boolean => {
  try {
    const success = authenticateOwner(ownerKey);

    if (success) {
      console.log('%c OWNER ACCESS GRANTED ', 'background: #00FF00; color: #000; font-weight: bold; padding: 2px 5px;');
      console.log('You now have full access to the application without payment requirements.');
      console.log('This access will persist across browser sessions.');

      // Refresh the page to apply changes
      setTimeout(() => {
        window.location.reload();
      }, 1500);

      return true;
    } else {
      console.error('%c INVALID OWNER KEY ', 'background: #FF0000; color: #FFF; font-weight: bold; padding: 2px 5px;');
      return false;
    }
  } catch (error) {
    console.error('Error granting owner access:', error);
    return false;
  }
};

/**
 * Check if current user has owner access
 * @returns boolean indicating if owner access is active
 */
export const checkOwnerAccess = (): boolean => {
  return isOwner();
};

/**
 * Remove owner access
 * This function should be called from the browser console
 *
 * @returns boolean indicating if removal was successful
 */
export const removeOwnerAccess = (): boolean => {
  try {
    // Keys are defined in paymentCheck.ts
    const ownerKeys = [
      'pcm-owner-21f35e92',
      'pcm-owner-auth-token'
    ];

    // Remove all owner keys
    ownerKeys.forEach(key => {
      localStorage.removeItem(key);
    });

    console.log('%c OWNER ACCESS REMOVED ', 'background: #FF0000; color: #FFF; font-weight: bold; padding: 2px 5px;');
    console.log('You will now be subject to payment requirements like other users.');

    // Refresh the page to apply changes
    setTimeout(() => {
      window.location.reload();
    }, 1500);

    return true;
  } catch (error) {
    console.error('Error removing owner access:', error);
    return false;
  }
};

// Export the owner keys for direct use if needed
export const OWNER_KEY_PRIMARY = 'pcm-owner-21f35e92';
export const OWNER_KEY_BACKUP = 'pcm-owner-auth-token';

// Usage instructions for console
/*
  To grant owner access:
  1. Open browser console (F12 or right-click > Inspect > Console)
  2. Run:
     import { grantOwnerAccess } from './utils/ownerAccess';
     grantOwnerAccess('pcm-owner-21f35e92');

  To check owner access:
  1. import { checkOwnerAccess } from './utils/ownerAccess';
  2. checkOwnerAccess();

  To remove owner access:
  1. import { removeOwnerAccess } from './utils/ownerAccess';
  2. removeOwnerAccess();
*/
