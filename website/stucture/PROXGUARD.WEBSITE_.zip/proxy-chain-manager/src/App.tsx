import { useState, useEffect } from 'react';
import { AuthProvider } from './lib/authContext';
import { ThemeProvider } from './lib/themeContext';
import { NotificationProvider } from './lib/notificationContext';
import { Navigation } from './components/layout/Navigation';
import { Header } from './components/layout/Header';
import { Notifications } from './components/ui/Notifications';
import { SystemControls } from './components/system-controls/SystemControls';
import { ProxyChainVisualization } from './components/proxy-chain/ProxyChainVisualization';
import { ProxyChainConfiguration } from './components/proxy-chain/ProxyChainConfiguration';
import { PrivacyFeatures } from './components/privacy/PrivacyFeatures';
import { ScrapingInterval } from './components/scraping/ScrapingInterval';
import { WalletAccess } from './components/wallet/WalletAccess';
import { PaymentModal } from './components/payment/PaymentModal';
import { LoginForm } from './components/auth/LoginForm';
import { RegisterForm } from './components/auth/RegisterForm';
import { SubscriptionPlans } from './components/subscription/SubscriptionPlans';
import { IPDNSVerifier } from './components/verifier/IPDNSVerifier';
import { ProxyChainIcon, SecureLinkIcon } from './components/icons/Icons';
import { MFASetup } from './components/auth/MFASetup';
import { AnalyticsDashboard } from './components/dashboard/AnalyticsDashboard';
import LandingPage from './components/LandingPage';
// Import the owner access check
import { checkOwnerAccess } from './utils/ownerAccess';
// Import from paymentCheck.ts
import { isOwner } from './lib/paymentCheck';

// Admin access key constant
const ADMIN_ACCESS_KEY = 'admin-access-granted';

type AppPage =
  | 'landing'
  | 'dashboard'
  | 'proxy'
  | 'privacy'
  | 'verifier'
  | 'account'
  | 'subscription'
  | 'login'
  | 'register'
  | 'mfa-setup'
  | 'analytics';

function App() {
  const [currentPage, setCurrentPage] = useState<AppPage>('landing');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isOwnerAccess, setIsOwnerAccess] = useState(false);
  const [isAdminAccess, setIsAdminAccess] = useState(false);

  // Mock navigation without a router
  const navigate = (page: AppPage) => {
    setCurrentPage(page);
  };

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);

    // Check if owner access is active
    setIsOwnerAccess(isOwner());

    // Check specifically for admin access
    setIsAdminAccess(localStorage.getItem(ADMIN_ACCESS_KEY) === 'true');

    return () => clearTimeout(timer);
  }, []);

  // Render different pages based on currentPage
  const renderPage = () => {
    switch (currentPage) {
      case 'landing':
        return <LandingPage onGetStarted={() => navigate('dashboard')} />;
      case 'dashboard':
        return (
          <>
            <SystemControls />

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <ProxyChainVisualization />
              <div>
                <PrivacyFeatures />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <ScrapingInterval />
              <WalletAccess />
            </div>
          </>
        );

      case 'proxy':
        return <ProxyChainConfiguration />;

      case 'privacy':
        return <PrivacyFeatures />;

      case 'verifier':
        return <IPDNSVerifier />;

      case 'subscription':
        return <SubscriptionPlans />;

      case 'mfa-setup':
        return <MFASetup />;

      case 'analytics':
        return <AnalyticsDashboard />;

      case 'login':
        return (
          <div className="py-12">
            <LoginForm
              onSuccess={() => navigate('dashboard')}
              onRegisterClick={() => navigate('register')}
            />
          </div>
        );

      case 'register':
        return (
          <div className="py-12">
            <RegisterForm
              onSuccess={() => navigate('dashboard')}
              onLoginClick={() => navigate('login')}
            />
          </div>
        );

      default:
        return <div>Page not found</div>;
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black dark:bg-black">
        <div className="text-center">
          <div className="flex items-center justify-center mb-6">
            <ProxyChainIcon size={56} className="text-primary animate-pulse" />
            <div className="ml-3 h-12 w-[3px] bg-secondary/70"></div>
            <SecureLinkIcon size={40} className="ml-3 text-accent" />
          </div>
          <h1 className="mb-4 text-3xl font-display font-bold">
            <span className="text-primary">Prox</span>
            <span className="text-secondary">Guard</span>
            <span className="text-muted-foreground font-normal"> v1.0</span>
          </h1>
          <div className="h-2 w-64 overflow-hidden rounded-full bg-primary-darker/40">
            <div className="animate-pulse h-full w-2/3 bg-primary" style={{ animation: 'pulse 1.5s infinite' }} />
          </div>
          <p className="mt-4 text-green-400 text-sm font-bold">OPSEC PRE-RELEASE OF EXDEX</p>
          <p className="mt-2 text-muted-foreground text-xs">Enterprise-Grade Security & Privacy</p>
        </div>
      </div>
    );
  }

  // If on landing page, render it full screen without header/footer
  if (currentPage === 'landing') {
    return (
      <ThemeProvider>
        <AuthProvider>
          <NotificationProvider>
            {renderPage()}
          </NotificationProvider>
        </AuthProvider>
      </ThemeProvider>
    );
  }

  // For all other pages, render with header/footer
  return (
    <ThemeProvider>
      <AuthProvider>
        <NotificationProvider>
          <div className="flex min-h-screen flex-col bg-black text-foreground dark:bg-black dark:text-foreground">
            <Header />
            <Navigation currentPage={currentPage} navigate={navigate} />
            <Notifications />

            {isOwnerAccess && !isAdminAccess && (
              <div className="fixed top-16 right-4 z-50 max-w-xs bg-[#005500] border border-[#00FF00] text-[#00FF00] p-3 rounded-md shadow-lg backdrop-blur-md">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                    <path d="m9 12 2 2 4-4" />
                  </svg>
                  <span className="font-medium">Owner Access Active</span>
                </div>
                <p className="text-xs mt-1">Payment verification bypassed. You have full access to all features.</p>
              </div>
            )}

            {isAdminAccess && (
              <div className="fixed top-16 right-4 z-50 max-w-xs bg-[#00336680] border border-[#0088FF] text-[#0088FF] p-3 rounded-md shadow-lg backdrop-blur-md">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                    <rect width="18" height="18" x="3" y="3" rx="2" />
                    <path d="M7 7h.01" />
                    <path d="M12 7h.01" />
                    <path d="M17 7h.01" />
                    <path d="M7 12h.01" />
                    <path d="M12 12h.01" />
                    <path d="M17 12h.01" />
                    <path d="M7 17h.01" />
                    <path d="M12 17h.01" />
                    <path d="M17 17h.01" />
                  </svg>
                  <span className="font-medium">Admin Mode</span>
                </div>
                <p className="text-xs mt-1">Admin access enabled. Payment requirements bypassed.</p>
              </div>
            )}

            <PaymentModal
              isOpen={showPaymentModal}
              onClose={() => setShowPaymentModal(false)}
            />

            <main className="container mx-auto flex-1 p-2 sm:p-4">
              {renderPage()}
            </main>

            <footer className="border-t border-primary-darker bg-black py-4 text-center text-xs sm:py-5 sm:text-sm text-muted-foreground backdrop-blur-md">
              <div className="container mx-auto px-4">
                <div className="flex items-center justify-center space-x-2 mb-2">
                  <ProxyChainIcon size={20} className="text-primary" />
                  <span className="text-primary-dark font-display">ProxGuard</span>
                </div>
                <p>© {new Date().getFullYear()} ProxGuard | OPSEC Pre-Release of ExDeX</p>
                <p className="mt-1 text-xs">Secure · Private · Untraceable</p>
                {isOwnerAccess && !isAdminAccess && (
                  <p className="mt-2 text-xs text-[#00FF00]">Owner Mode Active</p>
                )}
                {isAdminAccess && (
                  <p className="mt-2 text-xs text-[#0088FF]">Admin Mode Active</p>
                )}
              </div>
            </footer>
          </div>
        </NotificationProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
